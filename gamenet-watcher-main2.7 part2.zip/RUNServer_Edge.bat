@echo off
:: Launch start.bat and Edge.bat elevated (Run as Administrator).
:: If this .bat is itself already running elevated (e.g. via
:: Start.vbs -> Server-Startup.ps1), no extra UAC prompt appears --
:: Windows only prompts when going from non-elevated to elevated.

start "" powershell -NoProfile -Command "Start-Process -FilePath '%~dp0start.bat' -WorkingDirectory '%~dp0' -Verb RunAs"
timeout /t 10 >nul

start "" powershell -NoProfile -Command "Start-Process -FilePath '%~dp0Edge.bat' -WorkingDirectory '%~dp0' -Verb RunAs"
timeout /t 5 >nul

exit
