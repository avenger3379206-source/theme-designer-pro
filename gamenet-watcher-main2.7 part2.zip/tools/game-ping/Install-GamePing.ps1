# Run once as Administrator on each VIP client.
$ErrorActionPreference = 'Stop'
$base = Join-Path $env:ProgramData 'ExirGamePing'
$bin = Join-Path $base 'WinDivert'
New-Item -ItemType Directory -Force -Path $bin | Out-Null
$zip = Join-Path $env:TEMP 'WinDivert-2.2.2-A.zip'
$url = 'https://github.com/basil00/WinDivert/releases/download/v2.2.2/WinDivert-2.2.2-A.zip'
Write-Host 'Downloading WinDivert 2.2.2 from the official release...'
Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
$extract = Join-Path $env:TEMP ('windivert-' + [guid]::NewGuid().ToString('N'))
Expand-Archive -Path $zip -DestinationPath $extract -Force
$dll = Get-ChildItem $extract -Recurse -Filter 'WinDivert.dll' | Where-Object { $_.FullName -match '\\x64\\' } | Select-Object -First 1
$sys = Get-ChildItem $extract -Recurse -Filter 'WinDivert64.sys' | Where-Object { $_.FullName -match '\\x64\\' } | Select-Object -First 1
if (-not $dll -or -not $sys) { throw 'Could not find x64 WinDivert.dll / WinDivert64.sys in the downloaded release.' }
Copy-Item $dll.FullName (Join-Path $bin 'WinDivert.dll') -Force
Copy-Item $sys.FullName (Join-Path $bin 'WinDivert64.sys') -Force
Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $zip -Force -ErrorAction SilentlyContinue
Write-Host "Installed to $bin"
Write-Host 'The Exir client agent must run elevated (Administrator) for WinDivert.'
