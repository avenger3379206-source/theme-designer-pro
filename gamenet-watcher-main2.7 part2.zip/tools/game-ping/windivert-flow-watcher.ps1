param(
  [string]$WinDivertDll = "$env:ProgramData\ExirGamePing\WinDivert\WinDivert.dll"
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $WinDivertDll)) {
  Write-Output (([pscustomobject]@{ok=$false; error='WinDivert is not installed'; code='WINDIVERT_MISSING'}) | ConvertTo-Json -Compress)
  exit 2
}

Set-Location -LiteralPath (Split-Path -Parent $WinDivertDll)

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class ExirWinDivert {
  [StructLayout(LayoutKind.Sequential, Pack=1)]
  public struct FlowData {
    public UInt64 EndpointId;
    public UInt64 ParentEndpointId;
    public UInt32 ProcessId;
    [MarshalAs(UnmanagedType.ByValArray, SizeConst=4)] public UInt32[] LocalAddr;
    [MarshalAs(UnmanagedType.ByValArray, SizeConst=4)] public UInt32[] RemoteAddr;
    public UInt16 LocalPort;
    public UInt16 RemotePort;
    public Byte Protocol;
  }
  [StructLayout(LayoutKind.Explicit, Size=80)]
  public struct Address {
    [FieldOffset(0)] public Int64 Timestamp;
    [FieldOffset(8)] public UInt32 Flags;
    [FieldOffset(12)] public UInt32 Reserved2;
    [FieldOffset(16)] public FlowData Flow;
  }
  [DllImport("WinDivert.dll", CallingConvention=CallingConvention.Cdecl, CharSet=CharSet.Ansi)]
  public static extern IntPtr WinDivertOpen(string filter, int layer, short priority, UInt64 flags);
  [DllImport("WinDivert.dll", CallingConvention=CallingConvention.Cdecl)]
  [return: MarshalAs(UnmanagedType.Bool)]
  public static extern bool WinDivertRecv(IntPtr handle, IntPtr packet, UInt32 packetLen, out UInt32 recvLen, ref Address addr);
  [DllImport("WinDivert.dll", CallingConvention=CallingConvention.Cdecl)]
  public static extern bool WinDivertHelperFormatIPv6Address(
    [In] UInt32[] addr, System.Text.StringBuilder buffer, UInt32 bufferLen);
  [DllImport("WinDivert.dll", CallingConvention=CallingConvention.Cdecl)]
  [return: MarshalAs(UnmanagedType.Bool)]
  public static extern bool WinDivertClose(IntPtr handle);
  [DllImport("kernel32.dll")]
  public static extern UInt32 GetLastError();
}
"@

$INVALID = [IntPtr](-1)
$handle = [ExirWinDivert]::WinDivertOpen('udp', 2, 776, [UInt64]0x0001 -bor [UInt64]0x0004)
if ($handle -eq [IntPtr]::Zero -or $handle -eq $INVALID) {
  Write-Output (([pscustomobject]@{ok=$false; error="WinDivertOpen failed: $([ExirWinDivert]::GetLastError())"; code='WINDIVERT_OPEN_FAILED'}) | ConvertTo-Json -Compress)
  exit 3
}
try {
  while ($true) {
    $addr = New-Object ExirWinDivert+Address
    $addr.Flow = New-Object ExirWinDivert+FlowData
    $recv = 0
    if (-not [ExirWinDivert]::WinDivertRecv($handle, [IntPtr]::Zero, 0, [ref]$recv, [ref]$addr)) { continue }
    # Event is bits 8..15 of the 32-bit flags word.
    $event = ($addr.Flags -shr 8) -band 0xff
    if ($event -ne 1) { continue } # FLOW_ESTABLISHED
    if ($addr.Flow.Protocol -ne 17) { continue } # UDP
    $pid = [int]$addr.Flow.ProcessId
    try { $proc = Get-Process -Id $pid -ErrorAction Stop; $name = $proc.ProcessName.ToLowerInvariant() } catch { continue }
    $remote = $addr.Flow.RemoteAddr
    # WinDivert 2.2 represents IPv4 endpoints as IPv4-mapped IPv6 addresses
    # (::ffff:X.Y.Z.W). Convert the 4 DWORDs exactly as documented.
    $allZero = ($remote[0] -eq 0 -and $remote[1] -eq 0 -and $remote[2] -eq 0 -and $remote[3] -eq 0)
    if ($allZero) { continue }
    $sb = New-Object System.Text.StringBuilder 64
    if (-not [ExirWinDivert]::WinDivertHelperFormatIPv6Address($remote, $sb, 64)) { continue }
    $ip = $sb.ToString()
    if ($ip.StartsWith('::ffff:', [StringComparison]::OrdinalIgnoreCase)) {
      $ip = $ip.Substring(7)
    }
    if ($ip -eq '0.0.0.0' -or $ip -eq '255.255.255.255' -or $ip -like '10.*' -or $ip -like '192.168.*' -or $ip -like '127.*' -or $ip -like '169.254.*' -or $ip -match '^172\.(1[6-9]|2[0-9]|3[0-1])\.' -or $ip -eq '::1' -or $ip -like 'fe80:*' -or $ip -like 'fc*' -or $ip -like 'fd*') { continue }
    [pscustomobject]@{ok=$true; pid=$pid; processName=$name; protocol='udp'; remoteAddress=$ip; remotePort=[int]$addr.Flow.RemotePort; localPort=[int]$addr.Flow.LocalPort; ts=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} | ConvertTo-Json -Compress
  }
}
finally {
  [ExirWinDivert]::WinDivertClose($handle) | Out-Null
}
