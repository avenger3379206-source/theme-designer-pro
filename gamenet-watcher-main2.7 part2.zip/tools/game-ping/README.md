Game Ping integration

- WinDivert FLOW events discover the actual remote UDP endpoint by process ID.
- No hard-coded public websites are used as a substitute for a match server.
- Generic ICMP RTT is only shown when the discovered endpoint answers ICMP; otherwise the dashboard shows —.
- Exact in-game ping for every game cannot be universally inferred from raw UDP flow data; exact netgraph-style values require game-specific telemetry.
- Start the Agent before launching a game so its first UDP flow can be observed.
