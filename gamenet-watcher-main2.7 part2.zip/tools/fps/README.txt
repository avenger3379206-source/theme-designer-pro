REAL FPS MONITOR
================

Uses PresentMon (Windows ETW) to measure actual frame-present events from the
currently foreground application. No DLL injection and no game-specific FPS
fake values.

ONE-TIME CLIENT SETUP (ADMINISTRATOR)
-------------------------------------
Open PowerShell as Administrator in the folder containing exir-client-agent.mjs:

powershell -ExecutionPolicy Bypass -File .\tools\fps\Install-FpsMonitor.ps1

Then restart exir-client-agent.mjs as Administrator.

The dashboard polls:
  http://<VIP-IP>:8766/fps

When a game is active, the endpoint returns:
  fps, processName, pid, source=presentmon

When no game/application presents frames, FPS is shown as —.

The dashboard does NOT use the old fps field from VIPxx.json for the live FPS
display once the live client-agent FPS collector is active.

PresentMon is the official GameTechDev/Intel PresentMon console application.
