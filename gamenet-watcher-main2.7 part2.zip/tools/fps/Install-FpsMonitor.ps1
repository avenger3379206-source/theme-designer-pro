#requires -RunAsAdministrator
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$dest = Join-Path $PSScriptRoot "PresentMon.exe"
$url = "https://github.com/GameTechDev/PresentMon/releases/download/v2.3.1/PresentMon-2.3.1-x64.exe"

Write-Host "Installing PresentMon 2.3.1 x64 from the official GameTechDev release..."
New-Item -ItemType Directory -Force -Path $PSScriptRoot | Out-Null

if (Test-Path $dest) {
  try {
    $v = & $dest --version 2>$null
    if ($LASTEXITCODE -eq 0 -and $v) {
      Write-Host "PresentMon already exists at $dest"
      exit 0
    }
  } catch {}
}

$tmp = Join-Path $env:TEMP "PresentMon-2.3.1-x64.exe"
Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
Move-Item -Force $tmp $dest

if (-not (Test-Path $dest)) {
  throw "PresentMon installation failed."
}

Write-Host "Installed to $dest"
Write-Host "The Exir client agent must run elevated (Administrator) for ETW FPS capture."
