import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { SendMessageForm } from "@/components/monitoring/SendMessageModal";

const searchSchema = z.object({
  machine: z.string().catch(""),
});

export const Route = createFileRoute("/send-message")({
  validateSearch: searchSchema,
  component: SendMessagePage,
});

// This route is meant to be opened via window.open() as its own popup
// window (see the "Send Message" button in ClientDetailModal.tsx), not
// navigated to inside the main dashboard tab. Because it's a real separate
// window — its own document, its own JS execution context — nothing the
// dashboard's background polling does can ever touch its DOM, steal focus,
// or interrupt typing. That's what a React portal/overlay inside the same
// document could never fully guarantee.
function SendMessagePage() {
  const { machine } = Route.useSearch();

  if (!machine) {
    return (
      <div dir="rtl" className="font-fa flex min-h-screen items-center justify-center p-6 text-center text-sm text-muted-foreground">
        این پنجره باید با پارامتر ?machine=NAME باز شود — از دکمه «Send Message» توی داشبورد استفاده کن.
      </div>
    );
  }

  return <SendMessageForm machine={machine} onClose={() => window.close()} />;
}
