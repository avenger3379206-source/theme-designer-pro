import { useEffect, useState } from "react";
import { Keyboard, Mouse, Headphones, Gamepad2, Monitor, HardDrive, Usb, BellOff } from "lucide-react";
import { PERIPHERAL_EVT, hasPeripheralProblem, type PeripheralStatus } from "@/lib/peripheral-monitor";
import { DISK_HEALTH_EVT, diskHasProblem, type DiskHealthStatus } from "@/lib/disk-health";
import { USB_EVT, type UsbSnapshot } from "@/lib/usb-monitor";
import {
  loadClientAlertMutes,
  toggleClientAlertMute,
  CLIENT_ALERT_MUTES_EVT,
  type MutableAlertKind,
} from "@/lib/client-alert-mutes";

interface Props {
  machine: string;
}

function Pill({
  ok,
  icon,
  label,
  informational,
  muted,
  onToggleMute,
}: {
  ok: boolean;
  icon: React.ReactNode;
  label: string;
  informational?: boolean;
  muted: boolean;
  onToggleMute: () => void;
}) {
  const color = muted
    ? "oklch(0.5 0.01 250)"
    : ok
      ? "var(--neon-green)"
      : informational
        ? "oklch(0.58 0.01 250)"
        : "var(--neon-red)";
  return (
    <button
      onClick={onToggleMute}
      dir="ltr"
      title={muted ? `"${label}" alert muted for this client — click to re-enable` : `Click to mute "${label}" alert for this client only`}
      className="flex items-center gap-1.5 rounded-md px-2.5 py-2 text-left transition hover:brightness-125"
      style={{ background: `${color}12` }}
    >
      <span className="shrink-0" style={{ color }}>{icon}</span>
      <span className="truncate text-[13px] font-semibold" style={{ color }}>
        {label}
      </span>
      {muted && <BellOff size={10} style={{ color }} className="ml-auto shrink-0" />}
    </button>
  );
}

/** Peripheral (keyboard/mouse/headset/controller/monitor) + disk-health
 * (SMART) + USB-connect section for the client station detail modal.
 * Compact by design — each pill doubles as a per-client mute toggle. */
export function PeripheralHealthPanel({ machine }: Props) {
  const [peripherals, setPeripherals] = useState<PeripheralStatus | null>(null);
  useEffect(() => {
    const read = () => {
      const map = window.__exirPeripherals;
      setPeripherals(map?.[machine] || null);
    };
    read();
    window.addEventListener(PERIPHERAL_EVT, read);
    return () => window.removeEventListener(PERIPHERAL_EVT, read);
  }, [machine]);

  const [diskHealth, setDiskHealth] = useState<DiskHealthStatus | null>(null);
  useEffect(() => {
    const read = () => {
      const map = window.__exirDiskHealth;
      setDiskHealth(map?.[machine] || null);
    };
    read();
    window.addEventListener(DISK_HEALTH_EVT, read);
    return () => window.removeEventListener(DISK_HEALTH_EVT, read);
  }, [machine]);

  const [usb, setUsb] = useState<UsbSnapshot | null>(null);
  useEffect(() => {
    const read = () => {
      const map = window.__exirUsbDevices;
      setUsb(map?.[machine] || null);
    };
    read();
    window.addEventListener(USB_EVT, read);
    return () => window.removeEventListener(USB_EVT, read);
  }, [machine]);

  const [mutes, setMutes] = useState<MutableAlertKind[]>(() => loadClientAlertMutes()[machine] || []);
  useEffect(() => {
    const refresh = () => setMutes(loadClientAlertMutes()[machine] || []);
    refresh();
    window.addEventListener(CLIENT_ALERT_MUTES_EVT, refresh);
    return () => window.removeEventListener(CLIENT_ALERT_MUTES_EVT, refresh);
  }, [machine]);

  function toggleMute(kind: MutableAlertKind) {
    setMutes(toggleClientAlertMute(machine, kind)[machine] || []);
  }

  if (!peripherals && !diskHealth && !usb) return null;

  const peripheralProblem = peripherals ? hasPeripheralProblem(peripherals) : false;
  const badDisks = diskHealth?.ok ? diskHealth.disks.filter(diskHasProblem) : [];
  const usbFlagged = !!usb?.ok && usb.newDevices.length > 0;

  return (
    <div className="mt-4 rounded-md bg-surface/40 p-3">
      <div className="mb-2.5 flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
          <Keyboard size={12} /> Peripherals &amp; Disk Health
        </div>
        {(peripheralProblem || badDisks.length > 0 || usbFlagged) && (
          <span className="rounded bg-rose-500/20 px-1.5 py-0.5 text-[10px] font-bold text-rose-300" dir="ltr">
            NEEDS ATTENTION
          </span>
        )}
      </div>

      {peripherals?.ok ? (
        <div className="grid grid-cols-2 gap-1 sm:grid-cols-5">
          <Pill
            ok={peripherals.keyboard}
            icon={<Keyboard size={13} />}
            label="Keyboard"
            muted={mutes.includes("keyboard")}
            onToggleMute={() => toggleMute("keyboard")}
          />
          <Pill
            ok={peripherals.mouse}
            icon={<Mouse size={13} />}
            label="Mouse"
            muted={mutes.includes("mouse")}
            onToggleMute={() => toggleMute("mouse")}
          />
          <Pill
            ok={peripherals.monitorCount > 0}
            icon={<Monitor size={13} />}
            label={`Monitor ×${Math.max(0, peripherals.monitorCount)}`}
            muted={mutes.includes("monitor")}
            onToggleMute={() => toggleMute("monitor")}
          />
          <Pill
            ok={peripherals.headset}
            icon={<Headphones size={13} />}
            label="Headset"
            informational
            muted={mutes.includes("headset")}
            onToggleMute={() => toggleMute("headset")}
          />
          <Pill
            ok={peripherals.controller}
            icon={<Gamepad2 size={13} />}
            label="Controller"
            informational
            muted={mutes.includes("controller")}
            onToggleMute={() => toggleMute("controller")}
          />
        </div>
      ) : (
        <p className="text-xs text-muted-foreground" dir="ltr">
          {peripherals?.error || "Waiting for first peripheral check…"}
        </p>
      )}

      {/* USB — flags a NEW device (flash drive, phone, unknown dongle…), not
          just the known peripheral types above. */}
      {usb?.ok && (
        <div className="mt-1.5">
          <Pill
            ok={!usbFlagged}
            icon={<Usb size={13} />}
            label={usbFlagged ? `New USB device (${usb.newDevices.length})` : `USB · ${usb.devices.length} connected`}
            informational={!usbFlagged}
            muted={mutes.includes("usb")}
            onToggleMute={() => toggleMute("usb")}
          />
          {usbFlagged && (
            <div className="mt-1 space-y-0.5 pr-1 text-[11px] text-rose-300" dir="ltr">
              {usb.newDevices.map((d) => (
                <div key={d.id} className="truncate">+ {d.name}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {diskHealth?.ok && diskHealth.disks.length > 0 && (
        <div className="mt-2.5 space-y-1 border-t border-border/30 pt-2">
          {diskHealth.disks.map((d, i) => {
            const bad = diskHasProblem(d);
            const color = bad ? "var(--neon-red)" : "var(--neon-green)";
            return (
              <div
                key={i}
                dir="ltr"
                className="flex flex-wrap items-center justify-between gap-x-3 gap-y-0.5 rounded px-2 py-1.5"
                style={{ background: `${color}0a` }}
              >
                <div className="flex items-center gap-1.5 text-[12px] font-semibold" style={{ color }}>
                  <HardDrive size={12} /> {d.name}
                  <span className="font-normal text-muted-foreground">
                    ({d.mediaType}{d.sizeGB ? ` · ${d.sizeGB}GB` : ""})
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                  <span style={{ color }}>{d.health}</span>
                  {typeof d.temperature === "number" && <span>{d.temperature}°C</span>}
                  {typeof d.wearPercent === "number" && <span>{Math.round(d.wearPercent)}% wear</span>}
                  {typeof d.readErrorsUncorrected === "number" && d.readErrorsUncorrected > 0 && (
                    <span className="text-rose-300">{d.readErrorsUncorrected} read errors</span>
                  )}
                  {typeof d.powerOnHours === "number" && <span>{d.powerOnHours.toLocaleString()}h on</span>}
                </div>
              </div>
            );
          })}
        </div>
      )}
      {diskHealth && !diskHealth.ok && (
        <p className="mt-2 border-t border-border/30 pt-2 text-xs text-muted-foreground" dir="ltr">
          {diskHealth.error || "Waiting for first disk health check…"}
        </p>
      )}
    </div>
  );
}
