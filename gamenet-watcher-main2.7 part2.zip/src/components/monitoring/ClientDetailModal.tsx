import { memo, useEffect, useState } from "react";
import type { ClientStatus } from "@/lib/monitoring-types";
import { PowerControls } from "./PowerControls";
import { GoodSyncPanel } from "./GoodSyncPanel";
import { LiveHardwarePanel } from "./LiveHardwarePanel";
import { AgentSettingsPanel } from "./AgentSettingsPanel";
import { ClientNotifyPanel } from "./ClientNotifyPanel";
import { getMachine, launchVnc, loadVncConfig } from "@/lib/vnc-config";
import { NetworkPanel } from "./NetworkPanel";
import { PeripheralHealthPanel } from "./PeripheralHealthPanel";
import { SendMessageForm } from "./SendMessageModal";

interface Props {
  client: ClientStatus | null;
  onClose: () => void;
}

// Wrapped in React.memo: the dashboard behind this modal polls mock/ping data
// every 1-3s. Without memo, every one of those ticks re-renders this entire
// modal (and the Send Message textarea inside it), which was heavy enough to
// visibly stutter and eat keystrokes while typing a message. `client` and
// `onClose` are stable references while the modal is open (see index.tsx),
// so this component now only re-renders when the selected client actually
// changes or the modal is closed.
export const ClientDetailModal = memo(function ClientDetailModal({ client, onClose }: Props) {
  const [showSendMessage, setShowSendMessage] = useState(false);

  useEffect(() => {
    if (!client) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && !showSendMessage && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [client, onClose, showSendMessage]);


  if (!client) return null;

  const online = client.online !== false;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "oklch(0.05 0.02 260 / 0.55)", backdropFilter: "blur(16px) saturate(140%)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl overflow-hidden rounded-2xl p-6 glass-panel neon-border-cyan"
      >
        <div className="pointer-events-none absolute inset-0 scanline opacity-20" />

        <div className="relative flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span
                className="size-2.5 rounded-full pulse-dot"
                style={{ background: online ? "var(--neon-green)" : "oklch(0.4 0 0)" }}
              />
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">client station</span>
            </div>
            <h2 className="mt-1 font-mono text-4xl font-bold tracking-wider text-glow-cyan">{client.machine}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{client.gpuName}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-md border border-border/60 px-2.5 py-1.5 text-sm text-muted-foreground hover:text-foreground hover:border-foreground/40"
          >
            ESC ✕
          </button>
        </div>

        {online ? (
          <>
            <div className="relative mt-6 flex gap-2">
              <button
                onClick={() => {
                  const cfg = loadVncConfig();
                  const m = getMachine(cfg, client.machine);
                  void launchVnc(cfg, client.machine);
                  if (m) {
                    console.info(`[VNC] launching ${client.machine} → ${m.host}:${m.port}`);
                  }
                }}
                title="Downloads a .bat that launches UltraVNC with the mapped IP:PORT. Configure IPs in Settings."
                className="flex-1 rounded-md py-2.5 font-mono text-sm font-bold uppercase tracking-widest neon-border-cyan hover:brightness-125"
              >
                Connect VNC
              </button>
              <button
                onClick={() => setShowSendMessage(true)}
                className="flex-1 rounded-md py-2.5 font-mono text-sm font-bold uppercase tracking-widest neon-border-magenta hover:brightness-125"
              >
                Send Message
              </button>
            </div>
            <LiveHardwarePanel stats={client.liveStats ?? null} machine={client.machine} />
            <NetworkPanel machine={client.machine} />
            <PeripheralHealthPanel machine={client.machine} />
            <GoodSyncPanel machine={client.machine} />
            <AgentSettingsPanel machine={client.machine} />
            <ClientNotifyPanel machine={client.machine} />
            <PowerControls machine={client.machine} />
          </>
        ) : (
          <div className="relative mt-10 py-8 text-center">
            <div className="font-mono text-2xl uppercase tracking-widest text-muted-foreground">station offline</div>
            <div className="mt-2 font-mono text-xs text-muted-foreground/70">no JSON heartbeat received</div>
            <LiveHardwarePanel stats={null} machine={client.machine} />
            <AgentSettingsPanel machine={client.machine} />
            <ClientNotifyPanel machine={client.machine} />
            <PowerControls machine={client.machine} />
          </div>
        )}
      </div>
      {showSendMessage && (
        <SendMessageForm machine={client.machine} onClose={() => setShowSendMessage(false)} />
      )}
    </div>
  );
});
