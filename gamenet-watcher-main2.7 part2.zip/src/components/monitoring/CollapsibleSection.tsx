import { useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";

const KEY_PREFIX = "exir.settings.section-open.";

function loadOpen(key: string, defaultOpen: boolean): boolean {
  try {
    const raw = localStorage.getItem(KEY_PREFIX + key);
    if (raw === "1") return true;
    if (raw === "0") return false;
  } catch {
    /* ignore */
  }
  return defaultOpen;
}

function saveOpen(key: string, open: boolean) {
  try {
    localStorage.setItem(KEY_PREFIX + key, open ? "1" : "0");
  } catch {
    /* ignore */
  }
}

interface Props {
  /** Unique key for remembering this section's open/closed state. */
  id: string;
  title: string;
  icon?: ReactNode;
  /** Whether this section starts open the very first time someone visits
   * settings (before any localStorage preference has been saved). */
  defaultOpen?: boolean;
  children: ReactNode;
}

/** A clickable, collapsible drawer for one settings section. Wraps any
 * existing section content as-is — no changes needed inside the section
 * itself, so nested headings inside (if any) stay exactly as they were. */
export function CollapsibleSection({ id, title, icon, defaultOpen = true, children }: Props) {
  const [open, setOpen] = useState(() => loadOpen(id, defaultOpen));

  function toggle() {
    setOpen((prev) => {
      const next = !prev;
      saveOpen(id, next);
      return next;
    });
  }

  return (
    <div className="mb-4">
      <button
        type="button"
        onClick={toggle}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-2 rounded-xl border border-border/60 bg-surface/60 p-3.5 text-left transition hover:border-cyan-500/40 hover:bg-surface/80"
      >
        <span className="flex items-center gap-2 font-mono text-sm font-bold uppercase tracking-[0.2em] text-glow-cyan">
          {icon}
          {title}
        </span>
        <ChevronDown
          size={16}
          className="shrink-0 text-muted-foreground transition-transform duration-200"
          style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)" }}
        />
      </button>
      {open && <div className="mt-2">{children}</div>}
    </div>
  );
}
