import { useEffect, useMemo, useRef, useState } from "react";
import { ImagePlus, LayoutTemplate, Loader2, MessageSquareText, Moon, Pencil, Plus, Sun, Timer, Trash2, Volume2, VolumeX, X } from "lucide-react";
import { sendMessage, buildFullMessageHtml } from "@/lib/message";
import type { MessageButtonOpt } from "@/lib/message-template";
import { MESSAGE_PRESETS, addPreset, updatePreset, deletePreset, subscribePresets } from "@/lib/message-presets";

interface Props {
  machine: string;
  onClose: () => void;
}

// Renders as an in-page modal overlay (backdrop + centered card), invoked
// from ClientDetailModal.tsx. Previously this opened in a separate
// window.open() popup specifically to dodge the dashboard's background
// polling interrupting typing — that didn't actually solve the underlying
// complaint (typing still felt like it "refreshed"), so it's back to being
// in-page. The real fix for that: this component's own state (text, image,
// etc.) is entirely local (useState here), and ClientDetailModal only
// mounts this when the user clicks "Send Message" — the client list's
// periodic refresh re-renders ClientDetailModal with new props, but never
// unmounts/remounts *this* component, so React preserves all local state
// across every poll tick. Nothing in here subscribes to the live client
// data at all.
export function SendMessageForm({ machine, onClose }: Props) {
  const [text, setText] = useState("");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [imageDataUrl, setImageDataUrl] = useState<string | undefined>(undefined);
  const [videoFile, setVideoFile] = useState<File | undefined>(undefined);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | undefined>(undefined);
  const [attachError, setAttachError] = useState<string | null>(null);
  const MAX_ATTACH_BYTES = 300 * 1024 * 1024; // 300MB
  const [countdownOn, setCountdownOn] = useState(false);
  const [countdownMin, setCountdownMin] = useState(5);
  const [countdownLabel, setCountdownLabel] = useState("تا خاموش شدن سیستم");
  const [btn1, setBtn1] = useState("باشه");
  const [secondBtnOn, setSecondBtnOn] = useState(true);
  const [btn2, setBtn2] = useState("بعداً یادآوری کن");
  const [soundOn, setSoundOn] = useState(true);
  const [autoCloseOn, setAutoCloseOn] = useState(false);
  const [autoCloseSec, setAutoCloseSec] = useState(10);
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [presets, setPresets] = useState(MESSAGE_PRESETS);

  useEffect(() => subscribePresets(() => setPresets([...MESSAGE_PRESETS])), []);

  function saveCurrentAsPreset() {
    const label = window.prompt("اسم کوتاه برای این قالب:", "");
    if (!label || !label.trim()) return;
    const created = addPreset({
      label: label.trim(),
      text,
      countdownOn,
      countdownMin,
      countdownLabel,
      autoCloseOn,
      autoCloseSec,
      btn1,
      secondBtnOn,
      btn2,
    });
    setActivePreset(created.id);
  }

  function renamePreset(id: string, currentLabel: string) {
    const label = window.prompt("اسم جدید قالب:", currentLabel);
    if (!label || !label.trim() || label === currentLabel) return;
    updatePreset(id, { label: label.trim() });
  }

  function removePreset(id: string) {
    if (!window.confirm("این قالب حذف بشه؟")) return;
    deletePreset(id);
    if (activePreset === id) setActivePreset(null);
  }

  const [previewHtml, setPreviewHtml] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [msgOk, setMsgOk] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const buttons: MessageButtonOpt[] = useMemo(() => {
    const list = [{ label: btn1 || "باشه" }];
    if (secondBtnOn && btn2.trim()) list.push({ label: btn2 });
    return list;
  }, [btn1, secondBtnOn, btn2]);

  // Debounced live preview — regenerates the exact HTML that would be sent.
  // Long debounce (900ms) + only-when-idle so the iframe doesn't rebuild on
  // every keystroke (that was stealing focus / making it feel like the whole
  // panel was refreshing while typing).
  useEffect(() => {
    let cancelled = false;
    const t = setTimeout(() => {
      void buildFullMessageHtml(
        machine,
        {
          text: text || "متن پیام شما اینجا نمایش داده می‌شود…",
          theme,
          imageDataUrl,
          countdownSeconds: countdownOn ? countdownMin * 60 : undefined,
          countdownLabel,
          autoCloseSeconds: autoCloseOn ? autoCloseSec : undefined,
          soundOn,
          buttons,
        },
        videoPreviewUrl,
      ).then((html) => {
        if (!cancelled) setPreviewHtml(html);
      });
    }, 900);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [machine, text, theme, imageDataUrl, videoPreviewUrl, countdownOn, countdownMin, countdownLabel, autoCloseOn, autoCloseSec, soundOn, buttons]);

  function applyPreset(id: string) {
    const p = MESSAGE_PRESETS.find((x) => x.id === id);
    if (!p) return;
    setActivePreset(id);
    setText(p.text);
    setCountdownOn(p.countdownOn);
    setCountdownMin(p.countdownMin);
    setCountdownLabel(p.countdownLabel);
    setAutoCloseOn(p.autoCloseOn);
    setAutoCloseSec(p.autoCloseSec);
    setBtn1(p.btn1);
    setSecondBtnOn(p.secondBtnOn);
    setBtn2(p.btn2);
  }

  async function onPickAttachment(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setAttachError(null);
    if (file.size > MAX_ATTACH_BYTES) {
      setAttachError(`حجم فایل (${(file.size / 1024 / 1024).toFixed(0)}MB) بیشتر از سقف ۳۰۰ مگابایت است`);
      e.target.value = "";
      return;
    }
    if (file.type.startsWith("video/")) {
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
      setImageDataUrl(undefined);
      setVideoFile(file);
      setVideoPreviewUrl(URL.createObjectURL(file));
      return;
    }
    // image (or anything else picked via the image/* accept) — same as before
    if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    setVideoFile(undefined);
    setVideoPreviewUrl(undefined);
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    setImageDataUrl(dataUrl);
  }

  function clearAttachment() {
    if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    setImageDataUrl(undefined);
    setVideoFile(undefined);
    setVideoPreviewUrl(undefined);
    setAttachError(null);
  }

  // Free the blob preview URL when the modal unmounts.
  useEffect(() => {
    return () => {
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function onSend() {
    if (!text.trim() && !imageDataUrl && !videoFile) {
      setMsg("یک متن، تصویر یا ویدیو برای ارسال وارد کن");
      setMsgOk(false);
      return;
    }
    setBusy(true);
    setMsg(videoFile ? "در حال آپلود ویدیو روی کلاینت…" : null);
    const r = await sendMessage(machine, {
      text,
      theme,
      imageDataUrl,
      videoFile,
      countdownSeconds: countdownOn ? countdownMin * 60 : undefined,
      countdownLabel,
      autoCloseSeconds: autoCloseOn ? autoCloseSec : undefined,
      soundOn,
      buttons,
    });
    setBusy(false);
    setMsgOk(!!r.ok);
    if (r.ok) {
      setMsg(`پیام ارسال شد${r.note ? ` (${r.note})` : ""}`);
    } else {
      const err = r.error || "؟";
      const hint = /agent unreachable|Failed to fetch/i.test(err)
        ? " — مطمئن شو ping-agent روی سرور بازه و اگر روی کلاینت هم exir-client-agent نصب کردی، ری‌استارت کن (Files/exir-client-agent/README.txt)."
        : "";
      setMsg(`ارسال ناموفق: ${err}${hint}`);
    }
  }

  return (
    <div
      dir="rtl"
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="grid max-h-[92vh] w-full max-w-5xl grid-cols-1 overflow-hidden rounded-2xl border border-border/60 bg-background shadow-2xl md:grid-cols-2">
      {/* ── Form ─────────────────────────────────────────────────── */}
      <div className="font-fa max-h-[92vh] overflow-y-auto p-6" lang="fa">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquareText size={16} className="text-fuchsia-400" />
            <h2 className="font-fa font-mono text-sm font-bold uppercase tracking-widest text-glow-magenta">
              ارسال پیام به {machine}
            </h2>
          </div>
            <button
              onClick={onClose}
              className="rounded-md border border-border/60 p-1 text-muted-foreground hover:text-foreground hover:border-foreground/40"
            >
              <X size={14} />
            </button>
          </div>

          <div className="mt-5">
            <span className="font-fa flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              <LayoutTemplate size={12} /> قالب‌های آماده
            </span>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {presets.map((p) => (
                <span
                  key={p.id}
                  className="group flex items-center gap-1 rounded-full border pr-1 pl-2.5 py-1 text-[11px] transition-colors"
                  style={{
                    borderColor: activePreset === p.id ? "var(--neon-magenta)" : "var(--border)",
                    color: activePreset === p.id ? "var(--neon-magenta)" : undefined,
                    background: activePreset === p.id ? "var(--neon-magenta)15" : "transparent",
                  }}
                >
                  <button onClick={() => applyPreset(p.id)} className="cursor-pointer">
                    {p.label}
                  </button>
                  <button
                    onClick={() => renamePreset(p.id, p.label)}
                    title="ویرایش نام"
                    className="opacity-40 hover:opacity-100"
                  >
                    <Pencil size={10} />
                  </button>
                  <button
                    onClick={() => removePreset(p.id)}
                    title="حذف قالب"
                    className="opacity-40 hover:opacity-100 hover:text-red-400"
                  >
                    <Trash2 size={10} />
                  </button>
                </span>
              ))}
              <button
                onClick={saveCurrentAsPreset}
                title="ذخیره متن فعلی به‌عنوان قالب جدید"
                className="flex items-center gap-1 rounded-full border border-dashed px-2.5 py-1 text-[11px] text-muted-foreground hover:text-foreground"
                style={{ borderColor: "var(--border)" }}
              >
                <Plus size={11} /> قالب جدید
              </button>
            </div>
          </div>

          <label className="font-fa mt-4 block font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            متن پیام
          </label>
          <textarea
            dir="rtl"
            autoFocus
            rows={4}
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              setActivePreset(null);
            }}
            placeholder="مثلاً: لطفاً تا ۵ دقیقه دیگر سیستم را ذخیره و ترک کنید."
            className="mt-1.5 w-full resize-none rounded-md border border-border bg-background/60 p-2.5 text-sm leading-7 outline-none focus:border-fuchsia-500"
            style={{ fontFamily: "inherit" }}
          />

          {/* Theme */}
          <div className="mt-4 flex items-center gap-2">
            <span className="font-fa font-mono text-[10px] uppercase tracking-widest text-muted-foreground">تم پنجره</span>
            <div className="flex overflow-hidden rounded-md border border-border/60">
              <button
                onClick={() => setTheme("dark")}
                className="flex items-center gap-1 px-3 py-1.5 text-xs"
                style={{
                  background: theme === "dark" ? "var(--neon-magenta)25" : "transparent",
                  color: theme === "dark" ? "var(--neon-magenta)" : undefined,
                }}
              >
                <Moon size={12} /> تیره
              </button>
              <button
                onClick={() => setTheme("light")}
                className="flex items-center gap-1 border-r border-border/60 px-3 py-1.5 text-xs"
                style={{
                  background: theme === "light" ? "var(--neon-magenta)25" : "transparent",
                  color: theme === "light" ? "var(--neon-magenta)" : undefined,
                }}
              >
                <Sun size={12} /> روشن
              </button>
            </div>
            <button
              onClick={() => setSoundOn((s) => !s)}
              title="پخش صدای اعلان هنگام باز شدن پیام"
              className="mr-auto flex items-center gap-1.5 rounded-md border border-border/60 px-2.5 py-1.5 text-xs"
              style={{ color: soundOn ? "var(--neon-magenta)" : undefined }}
            >
              {soundOn ? <Volume2 size={13} /> : <VolumeX size={13} />}
              {soundOn ? "صدای اعلان روشن" : "بی‌صدا"}
            </button>
          </div>

          {/* Attachment: image or video, up to 300MB */}
          <div className="mt-4">
            <span className="font-fa font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              ضمیمه — عکس یا ویدیو (تا ۳۰۰ مگابایت)
            </span>
            <div className="mt-1.5 flex items-center gap-2">
              <button
                onClick={() => fileRef.current?.click()}
                className="flex items-center gap-1.5 rounded-md border border-border/60 px-2.5 py-1.5 text-xs text-muted-foreground hover:text-foreground"
              >
                <ImagePlus size={13} /> انتخاب عکس یا ویدیو
              </button>
              {imageDataUrl && (
                <>
                  <img src={imageDataUrl} alt="" className="h-9 w-9 rounded object-cover" />
                  <button onClick={clearAttachment} className="text-xs text-muted-foreground hover:text-red-400">
                    حذف
                  </button>
                </>
              )}
              {videoFile && (
                <>
                  <video src={videoPreviewUrl} className="h-9 w-16 rounded bg-black object-cover" muted />
                  <span className="font-mono text-[10px] text-muted-foreground">
                    {videoFile.name} · {(videoFile.size / 1024 / 1024).toFixed(1)}MB
                  </span>
                  <button onClick={clearAttachment} className="text-xs text-muted-foreground hover:text-red-400">
                    حذف
                  </button>
                </>
              )}
              <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={onPickAttachment} />
            </div>
            {attachError && <div className="mt-1.5 text-xs" style={{ color: "var(--neon-red)" }}>{attachError}</div>}
            {videoFile && (
              <div className="mt-1.5 font-fa text-[10px] text-muted-foreground">
                ویدیو موقع ارسال روی خود کلاینت آپلود و به‌صورت محلی پخش می‌شود — نیاز به exir-client-agent روی آن سیستم دارد.
              </div>
            )}
          </div>

          {/* Countdown */}
          <div className="mt-4 rounded-md border border-border/60 p-2.5">
            <label className="flex cursor-pointer items-center gap-2 text-xs">
              <input type="checkbox" checked={countdownOn} onChange={(e) => setCountdownOn(e.target.checked)} />
              <Timer size={13} /> نمایش شمارش معکوس
            </label>
            {countdownOn && (
              <div className="mt-2 grid grid-cols-3 gap-2">
                <div className="col-span-1">
                  <span className="font-fa font-mono text-[9px] uppercase text-muted-foreground">دقیقه</span>
                  <input
                    type="number"
                    min={1}
                    max={999}
                    value={countdownMin}
                    onChange={(e) => setCountdownMin(Math.max(1, Number(e.target.value) || 1))}
                    className="mt-1 w-full rounded border border-border bg-background/60 px-2 py-1 text-xs outline-none focus:border-fuchsia-500"
                  />
                </div>
                <div className="col-span-2">
                  <span className="font-fa font-mono text-[9px] uppercase text-muted-foreground">برچسب</span>
                  <input
                    dir="rtl"
                    value={countdownLabel}
                    onChange={(e) => setCountdownLabel(e.target.value)}
                    className="mt-1 w-full rounded border border-border bg-background/60 px-2 py-1 text-xs outline-none focus:border-fuchsia-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Auto-close (toast style, like Discord/Steam notifications) */}
          <div className="mt-3 rounded-md border border-border/60 p-2.5">
            <label className="flex cursor-pointer items-center gap-2 text-xs">
              <input type="checkbox" checked={autoCloseOn} onChange={(e) => setAutoCloseOn(e.target.checked)} />
              بسته شدن خودکار پیام (مثل اعلان‌های دیسکورد/استیم)
            </label>
            {autoCloseOn && (
              <div className="mt-2">
                <span className="font-fa font-mono text-[9px] uppercase text-muted-foreground">ثانیه تا بسته شدن</span>
                <input
                  type="number"
                  min={3}
                  max={120}
                  value={autoCloseSec}
                  onChange={(e) => setAutoCloseSec(Math.max(3, Number(e.target.value) || 3))}
                  className="mt-1 w-full rounded border border-border bg-background/60 px-2 py-1 text-xs outline-none focus:border-fuchsia-500"
                />
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="mt-4">
            <span className="font-fa font-mono text-[10px] uppercase tracking-widest text-muted-foreground">دکمه‌ها</span>
            <div className="mt-1.5 space-y-2">
              <input
                dir="rtl"
                value={btn1}
                onChange={(e) => setBtn1(e.target.value)}
                placeholder="دکمه اول"
                className="w-full rounded border border-border bg-background/60 px-2 py-1.5 text-xs outline-none focus:border-fuchsia-500"
              />
              <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
                <input type="checkbox" checked={secondBtnOn} onChange={(e) => setSecondBtnOn(e.target.checked)} />
                دکمه دوم
              </label>
              {secondBtnOn && (
                <input
                  dir="rtl"
                  value={btn2}
                  onChange={(e) => setBtn2(e.target.value)}
                  placeholder="دکمه دوم"
                  className="w-full rounded border border-border bg-background/60 px-2 py-1.5 text-xs outline-none focus:border-fuchsia-500"
                />
              )}
            </div>
          </div>

          {msg && (
            <div
              className="mt-4 rounded border px-2.5 py-1.5 text-xs"
              style={{
                borderColor: msgOk ? "var(--neon-green)55" : "var(--neon-red)55",
                color: msgOk ? "var(--neon-green)" : "var(--neon-red)",
                background: msgOk ? "var(--neon-green)10" : "var(--neon-red)10",
              }}
            >
              {msg}
            </div>
          )}

          <div className="mt-5 flex gap-2">
            <button
              onClick={onClose}
              className="flex-1 rounded-md border border-border/60 py-2.5 text-xs font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground"
            >
              انصراف
            </button>
            <button
              onClick={onSend}
              disabled={busy}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-md py-2.5 text-xs font-bold uppercase tracking-widest neon-border-magenta hover:brightness-125 disabled:opacity-50"
            >
              {busy ? <Loader2 size={13} className="animate-spin" /> : null}
              {busy ? "در حال ارسال…" : "ارسال پیام"}
            </button>
          </div>
        </div>

        {/* ── Live preview ─────────────────────────────────────────── */}
        <div className="flex items-center justify-center bg-black/30 p-6">
          <div className="w-full">
            <div className="font-fa mb-2 text-center font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              پیش‌نمایش دقیقاً همانی که روی صفحه‌ی کاربر نشان داده می‌شود
            </div>
            <div className="overflow-hidden rounded-xl border border-border/60" style={{ height: 560 }}>
              <iframe title="preview" srcDoc={previewHtml} className="h-full w-full border-0" sandbox="allow-scripts" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
