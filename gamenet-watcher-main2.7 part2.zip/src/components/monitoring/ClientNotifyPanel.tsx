import { useEffect, useState } from "react";
import { ChevronDown, ChevronUp, Bell, BellOff } from "lucide-react";
import {
  MUTABLE_ALERT_KINDS,
  loadClientAlertMutes,
  toggleClientAlertMute,
  CLIENT_ALERT_MUTES_EVT,
  type MutableAlertKind,
} from "@/lib/client-alert-mutes";

interface Props {
  machine: string;
}

/** Per-client notification mutes — silence any single alert type (overheat,
 * offline, peripheral, disk health) just for this station, without touching
 * the global Alerts settings that apply to every client. */
export function ClientNotifyPanel({ machine }: Props) {
  const [open, setOpen] = useState(false);
  const [muted, setMuted] = useState<MutableAlertKind[]>(() => loadClientAlertMutes()[machine] || []);

  useEffect(() => {
    const refresh = () => setMuted(loadClientAlertMutes()[machine] || []);
    refresh();
    window.addEventListener(CLIENT_ALERT_MUTES_EVT, refresh);
    return () => window.removeEventListener(CLIENT_ALERT_MUTES_EVT, refresh);
  }, [machine]);

  const mutedCount = muted.length;

  return (
    <div
      className="mt-4 rounded-lg border p-3"
      style={{ borderColor: "oklch(0.75 0.18 45 / 0.35)", background: "oklch(0.75 0.18 45 / 0.05)" }}
    >
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between font-mono text-[10px] uppercase tracking-widest"
        style={{ color: "oklch(0.75 0.18 45)" }}
      >
        <span className="flex items-center gap-1.5">
          <Bell size={11} /> ▸ notifications · هشدارهای این کلاینت
          {mutedCount > 0 && (
            <span className="rounded-full bg-black/30 px-1.5 py-0.5 font-mono text-[9px] text-foreground/70">
              {mutedCount} سایلنت
            </span>
          )}
        </span>
        {open ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
      </button>

      {open && (
        <div className="mt-3 space-y-1.5">
          <p className="font-fa mb-1 font-mono text-[9px] text-muted-foreground" lang="fa">
            هر کدوم رو سایلنت کنی، فقط برای همین کلاینت (<span dir="ltr">{machine}</span>) خاموش می‌شه — بقیه‌ی
            کلاینت‌ها طبق تنظیمات عمومی هشدار می‌دن.
          </p>
          {MUTABLE_ALERT_KINDS.map((k) => {
            const isMuted = muted.includes(k.key);
            return (
              <div
                key={k.key}
                className="flex items-center justify-between gap-3 rounded border border-border/60 bg-background/30 px-2.5 py-2"
              >
                <span className="font-fa font-mono text-[10px] font-bold text-foreground" lang="fa">
                  {k.label}
                </span>
                <button
                  onClick={() => setMuted(toggleClientAlertMute(machine, k.key)[machine] || [])}
                  className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[9px] font-bold uppercase tracking-wider transition ${
                    isMuted
                      ? "border-border/60 bg-background/40 text-muted-foreground"
                      : "border-green-500/50 bg-green-500/10 text-green-300"
                  }`}
                >
                  {isMuted ? <BellOff size={11} /> : <Bell size={11} />}
                  {isMuted ? "سایلنت" : "فعال"}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
