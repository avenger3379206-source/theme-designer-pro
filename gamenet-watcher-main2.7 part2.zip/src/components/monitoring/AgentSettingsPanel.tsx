import { useState } from "react";
import {
  ChevronDown, ChevronUp, Settings, Server, Save, Check,
  Cpu, Monitor, MemoryStick, HardDrive, Network, CircuitBoard,
  BatteryCharging, Fan as FanIcon, RefreshCw,
} from "lucide-react";

interface Props {
  machine: string;
}

const ALL_METRICS = [
  { key: "cpu", label: "پردازنده", icon: Cpu },
  { key: "gpu", label: "گرافیک", icon: Monitor },
  { key: "ram", label: "رم", icon: MemoryStick },
  { key: "disk", label: "دیسک", icon: HardDrive },
  { key: "network", label: "شبکه", icon: Network },
  { key: "motherboard", label: "مادربرد", icon: CircuitBoard },
  { key: "battery", label: "باتری", icon: BatteryCharging },
  { key: "fans", label: "فن‌ها", icon: FanIcon },
];

const STORAGE_KEY = (m: string) => `exir.agent-settings.${m}`;

interface AgentSettings {
  refreshMs: number;
  enabledMetrics: string[];
  serverSharePath: string;
  useWinRing0: boolean;
  uploadToSupabase: boolean;
  saveLocalJson: boolean;
}

function loadSettings(machine: string): AgentSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY(machine));
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return {
    refreshMs: 1000,
    enabledMetrics: ALL_METRICS.map((m) => m.key),
    serverSharePath: "\\\\192.168.3.100\\GameNet-Monitor\\status\\Info",
    useWinRing0: true,
    uploadToSupabase: true,
    saveLocalJson: true,
  };
}

function saveSettings(machine: string, s: AgentSettings) {
  try {
    localStorage.setItem(STORAGE_KEY(machine), JSON.stringify(s));
    window.dispatchEvent(new Event(`exir:agent-settings-${machine}`));
  } catch { /* ignore */ }
}

export function AgentSettingsPanel({ machine }: Props) {
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useState<AgentSettings>(() => loadSettings(machine));
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  function toggleMetric(key: string) {
    setSettings((s) => ({
      ...s,
      enabledMetrics: s.enabledMetrics.includes(key)
        ? s.enabledMetrics.filter((m) => m !== key)
        : [...s.enabledMetrics, key],
    }));
  }

  function handleSave() {
    setSaving(true);
    saveSettings(machine, settings);
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }, 500);
  }

  return (
    <div className="mt-4 rounded-lg border p-3" style={{ borderColor: "oklch(0.7 0.15 280 / 0.35)", background: "oklch(0.7 0.15 280 / 0.05)" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between font-mono text-[10px] uppercase tracking-widest"
        style={{ color: "oklch(0.7 0.15 280)" }}
      >
        <span className="flex items-center gap-1.5">
          <Settings size={11} /> ▸ agent settings · تنظیمات ایجنت
        </span>
        {open ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
      </button>

      {open && (
        <div className="mt-3 space-y-4">
          {/* Refresh interval */}
          <div>
            <label className="font-fa mb-1 block font-mono text-[9px] text-muted-foreground" lang="fa">
              بازه‌ی به‌روزرسانی ایجنت (میلی‌ثانیه)
            </label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={500}
                max={5000}
                step={500}
                value={settings.refreshMs}
                onChange={(e) => setSettings((s) => ({ ...s, refreshMs: Number(e.target.value) }))}
                className="flex-1 accent-cyan-500"
              />
              <span className="w-16 rounded border border-border/60 bg-background/50 px-2 py-1 text-center font-mono text-[10px] font-bold text-foreground">
                {settings.refreshMs}ms
              </span>
            </div>
          </div>

          {/* Server share path */}
          <div>
            <label className="font-fa mb-1 block font-mono text-[9px] text-muted-foreground" lang="fa">
              مسیر اشتراک سرور (ذخیره‌ی فایل JSON)
            </label>
            <div className="flex items-center gap-2 rounded border border-border/60 bg-background/50 px-2 py-1.5">
              <Server size={12} className="text-muted-foreground" />
              <input
                type="text"
                value={settings.serverSharePath}
                onChange={(e) => setSettings((s) => ({ ...s, serverSharePath: e.target.value }))}
                dir="ltr"
                className="flex-1 bg-transparent font-mono text-[10px] text-foreground outline-none"
              />
            </div>
            <p className="font-fa mt-0.5 font-mono text-[8px] text-muted-foreground" lang="fa">
              فایل به‌صورت <code dir="ltr" className="text-cyan-300">{machine}.json</code> در این مسیر ذخیره می‌شود.
            </p>
          </div>

          {/* Enabled metrics */}
          <div>
            <label className="font-fa mb-1.5 block font-mono text-[9px] text-muted-foreground" lang="fa">
              معیارهای فعال برای جمع‌آوری
            </label>
            <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
              {ALL_METRICS.map((m) => {
                const active = settings.enabledMetrics.includes(m.key);
                const Icon = m.icon;
                return (
                  <button
                    key={m.key}
                    onClick={() => toggleMetric(m.key)}
                    className={`flex items-center gap-1 rounded border px-2 py-1.5 font-mono text-[9px] font-bold transition ${
                      active
                        ? "border-cyan-500/50 bg-cyan-500/15 text-foreground"
                        : "border-border/60 bg-background/30 text-muted-foreground hover:border-border"
                    }`}
                  >
                    <Icon size={11} className={active ? "text-cyan-300" : ""} />
                    <span className="font-fa" lang="fa">{m.label}</span>
                    {active && <Check size={10} className="mr-auto text-green-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-1.5">
            <ToggleRow
              label="استفاده از درایور WinRing0"
              desc="برای خواندن دما و سرعت فن (مثل LiteMonitor)"
              checked={settings.useWinRing0}
              onChange={(v) => setSettings((s) => ({ ...s, useWinRing0: v }))}
            />
            <ToggleRow
              label="ارسال به Supabase (لایو)"
              desc="داده‌ها به‌صورت زنده به داشبورد ارسال می‌شود"
              checked={settings.uploadToSupabase}
              onChange={(v) => setSettings((s) => ({ ...s, uploadToSupabase: v }))}
            />
            <ToggleRow
              label="ذخیره‌ی JSON محلی"
              desc="فایل JSON هم در مسیر اشتراک ذخیره می‌شود"
              checked={settings.saveLocalJson}
              onChange={(v) => setSettings((s) => ({ ...s, saveLocalJson: v }))}
            />
          </div>

          {/* Save */}
          <div className="flex items-center gap-2 border-t border-border/40 pt-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1.5 rounded border border-cyan-500/50 bg-cyan-500/15 px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-widest text-cyan-300 transition hover:bg-cyan-500/25 disabled:opacity-50"
            >
              {saving ? <RefreshCw size={12} className="animate-spin" /> : saved ? <Check size={12} /> : <Save size={12} />}
              {saving ? "saving…" : saved ? "saved" : "save settings"}
            </button>
            <span className="font-fa font-mono text-[8px] text-muted-foreground" lang="fa">
              تنظیمات در <code dir="ltr">agent_settings.json</code> کنار ایجنت ذخیره می‌شود
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

function ToggleRow({
  label, desc, checked, onChange,
}: {
  label: string; desc: string; checked: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded border border-border/60 bg-background/30 px-2.5 py-2">
      <div className="flex flex-col">
        <span className="font-fa font-mono text-[10px] font-bold text-foreground" lang="fa">{label}</span>
        <span className="font-fa font-mono text-[8px] text-muted-foreground" lang="fa">{desc}</span>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${checked ? "bg-cyan-500" : "bg-border"}`}
      >
        <span className={`absolute top-0.5 size-4 rounded-full bg-white shadow transition-all ${checked ? "left-0.5" : "left-4"}`} />
      </button>
    </div>
  );
}
