import { useEffect } from "react";
import type { ServerStatus } from "@/lib/monitoring-types";
import { LiveHardwarePanel } from "./LiveHardwarePanel";

interface Props {
  server: ServerStatus | null;
  onClose: () => void;
}

export function ServerDetailModal({ server, onClose }: Props) {
  useEffect(() => {
    if (!server) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [server, onClose]);

  if (!server) return null;
  const online = server.online !== false;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "oklch(0.05 0.02 260 / 0.55)", backdropFilter: "blur(16px) saturate(140%)" }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-2xl overflow-y-auto rounded-2xl p-6 glass-panel neon-border-magenta"
        style={{ maxHeight: "88vh" }}
      >
        <div className="pointer-events-none absolute inset-0 scanline opacity-20" />

        <div className="relative flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span
                className={online ? "size-2.5 rounded-full pulse-dot" : "size-2.5 rounded-full"}
                style={{ background: online ? "var(--neon-magenta)" : "var(--neon-red)" }}
              />
              <span className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
                main server · {online ? "online" : "offline"}
              </span>
            </div>
            <h2 className="mt-1 font-mono text-4xl font-bold tracking-wider text-glow-magenta">{server.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground" dir="ltr">Uptime: {server.uptime}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-md border border-border/60 px-2.5 py-1.5 text-sm text-muted-foreground hover:text-foreground hover:border-foreground/40"
          >
            ESC ✕
          </button>
        </div>

        <div className="relative">
          <LiveHardwarePanel stats={server.liveStats ?? null} machine={server.name} />
        </div>
      </div>
    </div>
  );
}
