import { useEffect, useRef, useState } from "react";
import { FolderOpen, RefreshCw, Server as ServerIcon } from "lucide-react";
import type { ServerStatus } from "@/lib/monitoring-types";
import {
  ensurePermission,
  isFileSystemAccessSupported,
  loadDirHandle,
  pickStatusDirectory,
  readServer,
} from "@/lib/monitoring-source";
import { LiveHardwarePanel } from "./LiveHardwarePanel";

/**
 * General/overview info card for the main server — hostname, online state,
 * uptime and the full live hardware breakdown (CPU/GPU/RAM/disk/network/
 * motherboard/battery), read straight from EXIR-SERVER.json in the connected
 * status/Info folder. Self-contained: reuses the same directory-handle
 * connection the dashboard uses, so once it's connected once (from either
 * place) it stays connected everywhere.
 */
export function ServerInfoPanel() {
  const [server, setServer] = useState<ServerStatus | null>(null);
  const [connected, setConnected] = useState(false);
  const [folderName, setFolderName] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [supported, setSupported] = useState(false);
  const dirRef = useRef<FileSystemDirectoryHandle | null>(null);

  useEffect(() => {
    setSupported(isFileSystemAccessSupported());
  }, []);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const handle = await loadDirHandle();
      if (cancelled) return;
      if (handle && (await ensurePermission(handle))) {
        dirRef.current = handle;
        setFolderName(handle.name);
        setConnected(true);
      }
      setChecking(false);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!connected) return;
    let cancelled = false;
    async function tick() {
      if (!dirRef.current) return;
      const s = await readServer(dirRef.current);
      if (!cancelled && s) setServer(s);
    }
    tick();
    const id = setInterval(tick, 3000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [connected]);

  async function connect() {
    const handle = await pickStatusDirectory();
    if (!handle) return;
    dirRef.current = handle;
    setFolderName(handle.name);
    setConnected(true);
  }

  const online = server?.online !== false;

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span
            className={connected && server ? (online ? "size-2.5 rounded-full pulse-dot" : "size-2.5 rounded-full") : "size-2.5 rounded-full"}
            style={{
              background: connected && server ? (online ? "var(--neon-green)" : "var(--neon-red)") : "var(--muted-foreground)",
            }}
          />
          <div>
            <div className="font-mono text-base font-bold text-glow-cyan" dir="ltr">
              {server?.name ?? "EXIR-SERVER"}
            </div>
            <div className="font-mono text-[10px] text-muted-foreground" dir="ltr">
              {connected
                ? server
                  ? `${online ? "online" : "offline"} · uptime ${server.uptime}`
                  : "connected · waiting for data…"
                : "not connected"}
            </div>
          </div>
        </div>

        {connected ? (
          <button
            onClick={connect}
            title="click to pick a different folder"
            className="flex items-center gap-1.5 rounded-lg border border-border/60 bg-surface/40 px-2.5 py-1.5 font-mono text-[10px] text-muted-foreground hover:border-cyan-500/50 hover:text-foreground"
            dir="ltr"
          >
            <FolderOpen size={12} /> {folderName ?? "status/Info"} · change
          </button>
        ) : supported ? (
          <button
            onClick={connect}
            className="flex items-center gap-1.5 rounded-lg border border-cyan-500/50 bg-cyan-500/15 px-3 py-1.5 font-mono text-xs font-bold uppercase tracking-wider text-cyan-300 hover:bg-cyan-500/25"
          >
            <FolderOpen size={13} /> connect status folder
          </button>
        ) : null}
      </div>

      {!supported && !connected && (
        <p className="font-fa font-mono text-[11px] text-muted-foreground" lang="fa">
          این مرورگر از انتخاب پوشه پشتیبانی نمی‌کند. برای اتصال پوشه‌ی وضعیت، از داشبورد اصلی استفاده کنید.
        </p>
      )}

      {supported && (
        <p className="font-fa mb-3 font-mono text-[10px] text-muted-foreground" lang="fa">
          موقع انتخاب پوشه، دقیقاً پوشه‌ی <code dir="ltr" className="text-cyan-300">status\Info</code> رو انتخاب کن
          (نه <code dir="ltr">status</code> و نه <code dir="ltr">status\Server</code>) — فایل{" "}
          <code dir="ltr" className="text-cyan-300">EXIR-SERVER.json</code> باید مستقیم داخل همون پوشه باشه.
          اگه قبلاً پوشه‌ی قدیمی رو انتخاب کرده بودی، همین دکمه‌ی بالا رو بزن و دوباره انتخاب کن.
        </p>
      )}

      {checking && !connected && (
        <p className="flex items-center gap-1.5 font-mono text-[11px] text-muted-foreground">
          <RefreshCw size={11} className="animate-spin" /> checking for a previously-connected folder…
        </p>
      )}

      {connected && !server && !checking && (
        <p className="flex items-center gap-1.5 font-mono text-[11px] text-muted-foreground">
          <ServerIcon size={11} /> Waiting for EXIR-SERVER.json …
        </p>
      )}

      {connected && (
        <LiveHardwarePanel stats={server?.liveStats ?? null} machine={server?.name ?? "EXIR-SERVER"} />
      )}
    </div>
  );
}
