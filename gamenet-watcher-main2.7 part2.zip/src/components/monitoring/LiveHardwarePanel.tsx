import { useState } from "react";
import {
  ChevronDown, ChevronUp, Cpu, Monitor, MemoryStick, HardDrive,
  Network, CircuitBoard, BatteryCharging, Gauge, Activity,
} from "lucide-react";
import type { LiveHardwareStats } from "@/lib/monitoring-types";

interface Props {
  stats: LiveHardwareStats | null;
  machine: string;
}

function fmt(n: number | null, digits = 1): string {
  if (n === null || n === undefined) return "—";
  return n.toFixed(digits);
}

/** SVG fan that spins at a speed proportional to RPM. */
function SpinningFan({
  rpm, size = 56, variant = "cpu", label,
}: {
  rpm: number | null;
  size?: number;
  variant?: "cpu" | "gpu" | "case";
  label?: string;
}) {
  const colors = {
    cpu: { ring: "var(--neon-cyan)", blade: "oklch(0.75 0.14 200)", bladeDark: "oklch(0.5 0.12 200)", hub: "oklch(0.22 0.03 220)" },
    gpu: { ring: "var(--neon-magenta)", blade: "oklch(0.75 0.17 320)", bladeDark: "oklch(0.5 0.15 320)", hub: "oklch(0.22 0.04 340)" },
    case: { ring: "var(--neon-green)", blade: "oklch(0.75 0.14 145)", bladeDark: "oklch(0.5 0.12 145)", hub: "oklch(0.22 0.03 150)" },
  }[variant];
  const hasRpm = rpm !== null && rpm !== undefined && rpm > 0;
  const speedClass = !hasRpm ? "fan-idle" : rpm > 2000 ? "fan-spin" : "fan-spin-slow";

  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size} viewBox="0 0 100 100" className={speedClass} style={{ filter: `drop-shadow(0 1px 3px oklch(0 0 0 / 0.4))` }}>
        <circle cx="50" cy="50" r="48" fill="oklch(0.13 0.02 260)" />
        <circle cx="50" cy="50" r="47" fill="none" stroke={colors.ring} strokeWidth="1.5" opacity="0.55" />
        {[0, 60, 120, 180, 240, 300].map((a) => (
          <g key={a} transform={`rotate(${a} 50 50)`}>
            <path
              d="M 50 50 C 46 32 40 20 50 8 C 60 20 54 32 50 50 Z"
              fill={colors.blade}
              stroke={colors.bladeDark}
              strokeWidth="0.6"
            />
          </g>
        ))}
        <circle cx="50" cy="50" r="12" fill={colors.hub} stroke={colors.ring} strokeWidth="1.4" />
        <circle cx="50" cy="50" r="3.5" fill={colors.ring} />
      </svg>
      {label && <span className="text-[10px] text-muted-foreground" dir="ltr">{label}</span>}
      <span className="text-[11px] font-bold" dir="ltr" style={{ color: hasRpm ? "var(--foreground)" : "var(--muted-foreground)" }}>
        {hasRpm ? `${Math.round(rpm!)} RPM` : "OFF"}
      </span>
    </div>
  );
}

/** Small illustrated "photo" for a hardware category — self-contained SVG so
 * it can never 404 like a linked image file would. Sits at the top of each
 * StatBox next to (or instead of) the spinning fan. */
function HardwarePhoto({ kind, accent, size = 64 }: { kind: "cpu" | "gpu" | "ram" | "disk" | "motherboard" | "battery" | "network"; accent: string; size?: number }) {
  const glow = { filter: `drop-shadow(0 0 4px ${accent}99)` };
  switch (kind) {
    case "cpu":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          {[15, 35, 55, 75].map((p) => (
            <g key={p}>
              <line x1={p} y1="4" x2={p} y2="18" stroke={accent} strokeWidth="3" />
              <line x1={p} y1="82" x2={p} y2="96" stroke={accent} strokeWidth="3" />
              <line x1="4" y1={p} x2="18" y2={p} stroke={accent} strokeWidth="3" />
              <line x1="82" y1={p} x2="96" y2={p} stroke={accent} strokeWidth="3" />
            </g>
          ))}
          <rect x="18" y="18" width="64" height="64" rx="4" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          <rect x="30" y="30" width="40" height="40" rx="2" fill="none" stroke={accent} strokeWidth="1.2" opacity="0.6" />
          <text x="50" y="55" textAnchor="middle" fontSize="11" fontFamily="monospace" fill={accent} opacity="0.85">CPU</text>
        </svg>
      );
    case "gpu":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <rect x="10" y="30" width="80" height="42" rx="4" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          <circle cx="30" cy="51" r="12" fill="none" stroke={accent} strokeWidth="2" opacity="0.8" />
          <circle cx="62" cy="51" r="12" fill="none" stroke={accent} strokeWidth="2" opacity="0.8" />
          {[0, 60, 120, 180, 240, 300].map((a) => (
            <line key={a} x1={30 + 6 * Math.cos((a * Math.PI) / 180)} y1={51 + 6 * Math.sin((a * Math.PI) / 180)} x2={30 + 11 * Math.cos((a * Math.PI) / 180)} y2={51 + 11 * Math.sin((a * Math.PI) / 180)} stroke={accent} strokeWidth="1" opacity="0.6" />
          ))}
          <rect x="14" y="72" width="10" height="8" fill={accent} opacity="0.7" />
          <rect x="76" y="72" width="10" height="8" fill={accent} opacity="0.7" />
        </svg>
      );
    case "ram":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <rect x="14" y="20" width="72" height="56" rx="3" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          {[24, 36, 48, 60, 72].map((x) => (
            <rect key={x} x={x} y="26" width="6" height="16" fill={accent} opacity="0.75" />
          ))}
          <path d="M 14 76 L 22 88 L 78 88 L 86 76 Z" fill="none" stroke={accent} strokeWidth="2" opacity="0.7" />
        </svg>
      );
    case "disk":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <ellipse cx="50" cy="50" rx="42" ry="42" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          <ellipse cx="50" cy="50" rx="28" ry="28" fill="none" stroke={accent} strokeWidth="1" opacity="0.5" />
          <circle cx="50" cy="50" r="7" fill={accent} opacity="0.85" />
          <line x1="50" y1="50" x2="82" y2="24" stroke={accent} strokeWidth="3" strokeLinecap="round" opacity="0.8" />
        </svg>
      );
    case "motherboard":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <rect x="8" y="8" width="84" height="84" rx="4" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          <rect x="18" y="18" width="26" height="26" rx="2" fill="none" stroke={accent} strokeWidth="1.4" opacity="0.75" />
          {[54, 64, 74].map((x) => (
            <rect key={x} x={x} y="18" width="6" height="22" fill={accent} opacity="0.65" />
          ))}
          {[54, 64, 74].map((y) => (
            <rect key={y} x="18" y={y} width="22" height="6" fill={accent} opacity="0.5" />
          ))}
          <circle cx="78" cy="78" r="6" fill="none" stroke={accent} strokeWidth="1.4" opacity="0.7" />
        </svg>
      );
    case "battery":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <rect x="14" y="28" width="64" height="44" rx="6" fill="oklch(0.16 0.02 260)" stroke={accent} strokeWidth="2.5" />
          <rect x="80" y="42" width="8" height="16" rx="2" fill={accent} opacity="0.8" />
          <path d="M 48 34 L 34 54 L 46 54 L 40 66 L 58 46 L 46 46 Z" fill={accent} opacity="0.85" />
        </svg>
      );
    case "network":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" style={glow}>
          <circle cx="50" cy="68" r="6" fill={accent} opacity="0.85" />
          <path d="M 30 60 A 28 28 0 0 1 70 60" fill="none" stroke={accent} strokeWidth="3" opacity="0.75" />
          <path d="M 16 46 A 48 48 0 0 1 84 46" fill="none" stroke={accent} strokeWidth="3" opacity="0.45" />
        </svg>
      );
  }
}

function MetricRow({
  label, value, unit, bar, barColor = "var(--neon-cyan)",
}: {
  label: string; value: string | null; unit?: string; bar?: number | null; barColor?: string;
}) {
  const hasBar = bar !== null && bar !== undefined;
  const pct = Math.min(100, Math.max(0, bar ?? 0));
  return (
    <div dir="ltr">
      <div className="mb-0.5 flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="truncate font-bold text-foreground">
          {value ?? "—"}{unit && value ? <span className="text-muted-foreground"> {unit}</span> : null}
        </span>
      </div>
      {hasBar && (
        <div className="h-1 w-full overflow-hidden rounded-full bg-border/40">
          <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: barColor, boxShadow: `0 0 5px ${barColor}80` }} />
        </div>
      )}
    </div>
  );
}

function StatBox({
  title, icon, accent, children,
}: {
  title: string; icon: React.ReactNode; accent: string; children: React.ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-lg bg-surface/40">
      <div className="h-[2px] w-full" style={{ background: accent }} />
      <div className="p-2.5">
        <div className="mb-2 flex items-center gap-1.5">
          <span style={{ color: accent }}>{icon}</span>
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: accent }} dir="ltr">{title}</span>
        </div>
        <div className="space-y-1.5">{children}</div>
      </div>
    </div>
  );
}

export function LiveHardwarePanel({ stats, machine }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <div className="mt-4 rounded-lg p-3" style={{ background: "oklch(0.7 0.15 200 / 0.06)" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between text-xs font-bold uppercase tracking-widest"
        style={{ color: "var(--neon-cyan)" }}
        dir="ltr"
      >
        <span className="flex items-center gap-1.5">
          <Activity size={13} className={open ? "pulse-dot" : ""} /> ▸ Live Hardware
          {stats && (
            <span className="ml-1 rounded-full px-1.5 py-[1px] text-[10px] font-bold" style={{ background: "var(--neon-green)", color: "black" }}>
              LIVE
            </span>
          )}
        </span>
        {open ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
      </button>

      {open && (
        <>
          {!stats ? (
            <div className="mt-3 py-6 text-center text-xs text-muted-foreground" dir="ltr">
              No live data received — the hardware agent isn't installed or running on {machine}.
              <br />
              Run <code dir="ltr">GameNetAgent.exe</code> on this machine.
            </div>
          ) : (
            <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
              {/* CPU */}
              <StatBox title="CPU" icon={<Cpu size={13} />} accent="var(--neon-cyan)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="cpu" accent="var(--neon-cyan)" size={44} />
                  <SpinningFan rpm={stats.cpu.fan_rpm} size={52} variant="cpu" label="CPU fan" />
                </div>
                <MetricRow label="Model" value={stats.cpu.name || "—"} />
                <MetricRow label="Load" value={fmt(stats.cpu.usage_percent)} unit="%" bar={stats.cpu.usage_percent} />
                <MetricRow label="Temp" value={fmt(stats.cpu.temp_c)} unit="°C" bar={stats.cpu.temp_c ? (stats.cpu.temp_c / 90) * 100 : null} barColor="var(--neon-amber)" />
                <MetricRow label="Clock" value={stats.cpu.frequency_mhz ? fmt(stats.cpu.frequency_mhz, 0) : "—"} unit="MHz" />
                <MetricRow label="Power" value={fmt(stats.cpu.power_w)} unit="W" />
                <MetricRow label="Cores" value={stats.cpu.cores ? String(stats.cpu.cores) : "—"} />
              </StatBox>

              {/* GPU */}
              <StatBox title="GPU" icon={<Monitor size={13} />} accent="var(--neon-magenta)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="gpu" accent="var(--neon-magenta)" size={44} />
                  <SpinningFan rpm={stats.gpu.fan_rpm} size={52} variant="gpu" label="GPU fan" />
                </div>
                <MetricRow label="Model" value={stats.gpu.name || "—"} />
                <MetricRow label="Load" value={fmt(stats.gpu.usage_percent)} unit="%" bar={stats.gpu.usage_percent} barColor="var(--neon-magenta)" />
                <MetricRow label="Temp" value={fmt(stats.gpu.temp_c)} unit="°C" bar={stats.gpu.temp_c ? (stats.gpu.temp_c / 90) * 100 : null} barColor="var(--neon-amber)" />
                <MetricRow
                  label="Memory"
                  value={stats.gpu.memory_used_mb !== null && stats.gpu.memory_total_mb !== null ? `${fmt(stats.gpu.memory_used_mb, 0)} / ${fmt(stats.gpu.memory_total_mb, 0)}` : "—"}
                  unit="MB"
                />
                <MetricRow label="Fan speed" value={stats.gpu.fan_percent !== null ? fmt(stats.gpu.fan_percent) : "—"} unit="%" bar={stats.gpu.fan_percent} barColor="var(--neon-magenta)" />
                <MetricRow label="Power" value={fmt(stats.gpu.power_w)} unit="W" />
              </StatBox>

              {/* RAM */}
              <StatBox title="RAM" icon={<MemoryStick size={13} />} accent="oklch(0.7 0.15 280)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="ram" accent="oklch(0.7 0.15 280)" size={44} />
                </div>
                <MetricRow
                  label="Used"
                  value={
                    stats.ram.used_gb !== null && stats.ram.total_gb !== null
                      ? `${fmt(stats.ram.used_gb)} / ${fmt(stats.ram.total_gb)}`
                      : stats.ram.used_gb !== null
                        ? `${fmt(stats.ram.used_gb)}`
                        : "—"
                  }
                  unit="GB"
                />
                <MetricRow label="Load" value={fmt(stats.ram.usage_percent)} unit="%" bar={stats.ram.usage_percent} barColor="oklch(0.7 0.15 280)" />
                <MetricRow label="Clock" value={stats.ram.frequency_mhz ? fmt(stats.ram.frequency_mhz, 0) : "—"} unit="MHz" />
              </StatBox>

              {/* Disk */}
              <StatBox title="Disk" icon={<HardDrive size={13} />} accent="var(--neon-green)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="disk" accent="var(--neon-green)" size={44} />
                </div>
                <MetricRow label="Read" value={fmt(stats.disk.read_mb_s)} unit="MB/s" />
                <MetricRow label="Write" value={fmt(stats.disk.write_mb_s)} unit="MB/s" />
                <MetricRow label="Load" value={fmt(stats.disk.usage_percent)} unit="%" bar={stats.disk.usage_percent} barColor="var(--neon-green)" />
                <MetricRow label="Temp" value={fmt(stats.disk.temp_c)} unit="°C" />
                {stats.disk.drives.length > 0 && (
                  <div className="mt-1 space-y-1 border-t border-border/30 pt-1">
                    {stats.disk.drives.map((d, i) => (
                      <MetricRow key={i} label={`Drive ${d.letter}`} value={`${fmt(d.used_gb, 0)}/${fmt(d.total_gb, 0)}`} unit="GB" bar={d.percent} barColor="var(--neon-green)" />
                    ))}
                  </div>
                )}
              </StatBox>

              {/* Network */}
              <StatBox title="Network" icon={<Network size={13} />} accent="var(--neon-amber)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="network" accent="var(--neon-amber)" size={44} />
                </div>
                <MetricRow label="IP" value={stats.network.ip || "—"} />
                <MetricRow label="Adapter" value={stats.network.interface || "—"} />
                <MetricRow label="Upload" value={fmt(stats.network.upload_mb_s)} unit="MB/s" bar={stats.network.upload_mb_s ? Math.min(100, stats.network.upload_mb_s * 10) : null} barColor="var(--neon-amber)" />
                <MetricRow label="Download" value={fmt(stats.network.download_mb_s)} unit="MB/s" bar={stats.network.download_mb_s ? Math.min(100, stats.network.download_mb_s * 10) : null} barColor="var(--neon-amber)" />
              </StatBox>

              {/* Motherboard */}
              <StatBox title="Motherboard" icon={<CircuitBoard size={13} />} accent="oklch(0.7 0.15 330)">
                <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                  <HardwarePhoto kind="motherboard" accent="oklch(0.7 0.15 330)" size={44} />
                </div>
                <MetricRow label="Model" value={stats.motherboard.name || "—"} />
                <MetricRow label="Temp" value={fmt(stats.motherboard.temp_c)} unit="°C" bar={stats.motherboard.temp_c ? (stats.motherboard.temp_c / 80) * 100 : null} barColor="oklch(0.7 0.15 330)" />
                {stats.motherboard.case_fans.length > 0 && (
                  <div className="mt-1 flex flex-wrap justify-around gap-1.5 border-t border-border/30 pt-1">
                    {stats.motherboard.case_fans.map((f, i) => (
                      <SpinningFan key={i} rpm={f.rpm} size={40} variant="case" label={f.name} />
                    ))}
                  </div>
                )}
              </StatBox>

              {/* Battery */}
              {stats.battery.present && (
                <StatBox title="Battery" icon={<BatteryCharging size={13} />} accent="oklch(0.7 0.18 130)">
                  <div className="mb-1.5 flex items-center justify-around rounded-md bg-background/30 py-1.5">
                    <HardwarePhoto kind="battery" accent="oklch(0.7 0.18 130)" size={44} />
                  </div>
                  <MetricRow label="Status" value={stats.battery.charging ? "Charging" : "Discharging"} />
                  <MetricRow label="Charge" value={fmt(stats.battery.percent, 0)} unit="%" bar={stats.battery.percent} barColor="oklch(0.7 0.18 130)" />
                  <MetricRow label="Power" value={fmt(stats.battery.power_w)} unit="W" />
                  <MetricRow label="Voltage" value={fmt(stats.battery.voltage_v)} unit="V" />
                </StatBox>
              )}

              {/* Uptime */}
              <div className="flex items-center gap-2 rounded-lg bg-surface/20 px-3 py-2 text-xs text-muted-foreground" dir="ltr">
                <Gauge size={13} />
                <span>System uptime:</span>
                <span className="font-bold text-foreground">{Math.floor(stats.uptime_seconds / 60)} min</span>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
