import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { Wifi, Router, MonitorCog } from "lucide-react";
import {
  DEFAULT_COLOR_RANGE,
  getTierColor,
  loadQosBackend,
  loadQosColorRange,
  loadQosStates,
  pushQos,
  saveQosBackend,
  saveQosColorRange,
  saveQosStates,
  TIER_LABELS,
  TIER_ORDER,
  type QosBackend,
  type QosColorRange,
  type QosState,
  type Tier,
} from "@/lib/qos";

interface Props {
  machines: string[]; // e.g. ["VIP01","VIP02",...]
}

// ── Tier slider ──────────────────────────────────────────────────────────
// One rail, one draggable "ball" — replaces the old 4-box grid. The ball
// snaps to the nearest tooth (tier) as it's dragged; every tooth crossed
// commits immediately (enabled=true, tier=that step), which fires the
// normal update()/pushQos() flow straight to MikroTik/the client agent.
function TierSlider({
  value,
  onChange,
  disabled,
  colors,
}: {
  value: Exclude<Tier, "off">;
  // Fired ONCE, when the pointer is released — not on every tooth crossed
  // mid-drag. Committing on every tooth used to send a real MikroTik
  // GET+PATCH round-trip per tooth, so a single full-rail drag across all
  // 17 tiers could burst up to ~32 REST calls at the router in under two
  // seconds, which is enough to peg a low-power router's CPU. The ball
  // still visually snaps tooth-to-tooth while dragging (see dragIdx) — only
  // the actual network commit is deferred to release.
  onChange: (t: Exclude<Tier, "off">) => void;
  disabled?: boolean;
  colors: QosColorRange;
}) {
  const railRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const n = TIER_ORDER.length;
  const restIdx = TIER_ORDER.indexOf(value);
  const activeIdx = dragging && dragIdx !== null ? dragIdx : restIdx;
  const activeTier = TIER_ORDER[activeIdx];
  const thumbColor = getTierColor(activeTier, colors);

  function idxFromClientX(clientX: number) {
    const rail = railRef.current;
    if (!rail) return activeIdx;
    const rect = rail.getBoundingClientRect();
    const ratio = rect.width <= 0 ? 0 : (clientX - rect.left) / rect.width;
    return Math.min(n - 1, Math.max(0, Math.round(ratio * (n - 1))));
  }

  function handlePointerDown(e: ReactPointerEvent<HTMLDivElement>) {
    if (disabled) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    const i = idxFromClientX(e.clientX);
    setDragging(true);
    setDragIdx(i);
    // Single click (no drag follows) still needs to commit immediately —
    // handlePointerUp will skip re-committing the same value.
  }

  function handlePointerMove(e: ReactPointerEvent<HTMLDivElement>) {
    if (!dragging) return;
    const i = idxFromClientX(e.clientX);
    setDragIdx((prev) => (i === prev ? prev : i)); // visual only, no network call
  }

  function handlePointerUp() {
    setDragging(false);
    if (dragIdx !== null && dragIdx !== restIdx) onChange(TIER_ORDER[dragIdx]);
    setDragIdx(null);
  }

  const pct = n <= 1 ? 0 : (activeIdx / (n - 1)) * 100;

  return (
    <div dir="ltr" className="select-none">
      <div
        ref={railRef}
        className="relative h-8 touch-none px-1"
        style={{ cursor: disabled ? "not-allowed" : "pointer" }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
      >
        {/* the rail itself */}
        <div
          className="pointer-events-none absolute left-1 right-1 top-1/2 h-[3px] -translate-y-1/2 rounded-full transition-opacity"
          style={{
            background: `linear-gradient(90deg, ${colors.low}, ${colors.high} 88%, ${colors.unl})`,
            opacity: disabled ? 0.2 : 0.5,
            boxShadow: disabled ? "none" : `0 0 10px -1px ${thumbColor}88`,
          }}
        />
        {/* teeth — one notch per tier, the ball drops into whichever is nearest */}
        {TIER_ORDER.map((t, i) => {
          const p = n <= 1 ? 0 : (i / (n - 1)) * 100;
          const on = i === activeIdx;
          return (
            <div
              key={t}
              className="pointer-events-none absolute top-1/2 rounded-full transition-all duration-150"
              style={{
                left: `${p}%`,
                width: on ? 3 : 2,
                height: on ? 11 : 6,
                transform: "translate(-50%, -50%)",
                background: on ? thumbColor : "var(--muted-foreground)",
                opacity: disabled ? 0.15 : on ? 0.95 : 0.3,
              }}
            />
          );
        })}
        {/* the draggable ball */}
        <div
          className="pointer-events-none absolute top-1/2 h-4 w-4 rounded-full border-2"
          style={{
            left: `${pct}%`,
            transform: "translate(-50%, -50%)",
            transition: dragging ? "none" : "left 160ms cubic-bezier(.2,.8,.2,1)",
            background: `radial-gradient(circle at 32% 28%, oklch(0.98 0 0), ${thumbColor} 70%)`,
            borderColor: thumbColor,
            boxShadow: disabled ? "none" : `0 0 12px ${thumbColor}, 0 0 3px ${thumbColor} inset`,
            opacity: disabled ? 0.35 : 1,
          }}
        />
      </div>
      <div className="mt-0.5 flex items-center justify-between px-1.5 font-mono text-[8px] uppercase tracking-wider text-muted-foreground">
        <span>500K</span>
        <span
          className="font-en text-[11px] font-bold tracking-normal"
          style={{ color: disabled ? undefined : thumbColor, textShadow: disabled ? "none" : `0 0 8px ${thumbColor}88` }}
        >
          {TIER_LABELS[activeTier]}
        </span>
        <span>∞</span>
      </div>
    </div>
  );
}

export function QosLaunch({ machines }: Props) {
  const [states, setStates] = useState<Record<string, QosState>>(() => loadQosStates());
  const [colors, setColors] = useState<QosColorRange>(() => loadQosColorRange());
  const [openId, setOpenId] = useState<string | null>(null);
  const [colorEdit, setColorEdit] = useState(false);
  const [backend, setBackend] = useState<QosBackend>(() => loadQosBackend());
  const [errorByMachine, setErrorByMachine] = useState<Record<string, string>>({});
  const rootRef = useRef<HTMLDivElement>(null);

  function changeBackend(b: QosBackend) {
    setBackend(b);
    saveQosBackend(b);
  }

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!rootRef.current) return;
      if (!rootRef.current.contains(e.target as Node)) setOpenId(null);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  function update(machine: string, patch: Partial<QosState>) {
    setStates((prev) => {
      const current: QosState = prev[machine] ?? { enabled: false, tier: "off" };
      const merged: QosState = { ...current, ...patch };
      const next = { ...prev, [machine]: merged };
      saveQosStates(next);
      setErrorByMachine((e) => {
        if (!(machine in e)) return e;
        const { [machine]: _drop, ...rest } = e;
        return rest;
      });
      void pushQos(machine, merged).then((res) => {
        if (!res.ok) {
          // Real failure on the target VIP — don't leave the UI showing a
          // tier that never actually applied without any explanation.
          setErrorByMachine((e) => ({ ...e, [machine]: res.error || "apply failed" }));
        }
      });
      return next;
    });
  }

  function updateColorRange(k: keyof QosColorRange, v: string) {
    setColors((prev) => {
      const n = { ...prev, [k]: v };
      saveQosColorRange(n);
      return n;
    });
  }

  return (
    <div ref={rootRef} className="mb-3 rounded-xl p-3 glass-panel">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
          ▸ qos · internet control
        </h3>
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-md border border-border/60 bg-surface/60 p-0.5 font-mono text-[9px] uppercase tracking-wider">
            <button
              onClick={() => changeBackend("mikrotik")}
              title="Apply QoS via MikroTik simple-queue REST API"
              className="flex items-center gap-1 rounded px-1.5 py-0.5 transition"
              style={{
                background: backend === "mikrotik" ? "oklch(0.85 0.18 200 / 0.15)" : "transparent",
                color: backend === "mikrotik" ? "var(--neon-cyan)" : "var(--muted-foreground, #888)",
                boxShadow: backend === "mikrotik" ? "0 0 6px oklch(0.85 0.18 200 / 0.4)" : "none",
              }}
            >
              <Router size={10} /> mikrotik
            </button>
            <button
              onClick={() => changeBackend("netlimiter")}
              title="Apply QoS via NetLimiter Pro 4 on the target VIP (nlq.exe over PsExec)"
              className="flex items-center gap-1 rounded px-1.5 py-0.5 transition"
              style={{
                background: backend === "netlimiter" ? "oklch(0.7 0.25 320 / 0.18)" : "transparent",
                color: backend === "netlimiter" ? "var(--neon-magenta)" : "var(--muted-foreground, #888)",
                boxShadow: backend === "netlimiter" ? "0 0 6px oklch(0.7 0.25 320 / 0.4)" : "none",
              }}
            >
              <MonitorCog size={10} /> netlimiter
            </button>
          </div>
          <button
            onClick={() => setColorEdit((v) => !v)}
            className="rounded border border-border/60 bg-surface/60 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground transition hover:border-cyan-500/50 hover:text-cyan-300"
          >
            {colorEdit ? "done" : "colors"}
          </button>
        </div>
      </div>

      {colorEdit && (
        <div className="mb-2 rounded-lg border border-border/60 bg-surface/50 p-2.5">
          <div className="mb-2 flex flex-wrap items-center gap-x-4 gap-y-1.5">
            {([
              { k: "low" as const, label: "کمترین (500K)" },
              { k: "high" as const, label: "بیشترین (100M)" },
              { k: "unl" as const, label: "∞ نامحدود" },
            ]).map(({ k, label }) => (
              <label key={k} className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                <span
                  className="h-2 w-2 rounded-full"
                  style={{ background: colors[k], boxShadow: `0 0 6px ${colors[k]}` }}
                />
                <span className="normal-case">{label}</span>
                <input
                  type="color"
                  value={colors[k]}
                  onChange={(e) => updateColorRange(k, e.target.value)}
                  className="h-6 w-9 cursor-pointer rounded border border-border/60 bg-transparent"
                />
              </label>
            ))}
            <button
              onClick={() => {
                setColors(DEFAULT_COLOR_RANGE);
                saveQosColorRange(DEFAULT_COLOR_RANGE);
              }}
              className="ml-auto rounded border border-border/50 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-muted-foreground transition hover:border-red-500/40 hover:text-red-300"
            >
              reset
            </button>
          </div>
          {/* live preview of the full gradient the slider will use */}
          <div dir="ltr" className="relative h-2 overflow-hidden rounded-full border border-border/40">
            <div
              className="h-full w-full"
              style={{ background: `linear-gradient(90deg, ${colors.low}, ${colors.high} 88%, ${colors.unl})` }}
            />
          </div>
        </div>
      )}

      <div className="flex flex-nowrap items-start gap-1.5 overflow-x-auto">
        {machines.map((m) => {
          const st: QosState = states[m] ?? { enabled: false, tier: "off" };
          const active = st.enabled && st.tier !== "off";
          const activeColor = active && st.tier !== "off" ? getTierColor(st.tier, colors) : undefined;
          const isOpen = openId === m;
          return (
            <div key={m} className="flex-1 min-w-[46px]">
              <button
                onClick={() => setOpenId(isOpen ? null : m)}
                title={`${m} — ${active ? st.tier : "off"}`}
                className="flex w-full flex-col items-center gap-0.5 rounded-md border bg-surface/60 px-1 py-1 font-mono text-[9px] font-bold uppercase tracking-wider transition hover:scale-105"
                style={{
                  borderColor: activeColor ? `${activeColor}88` : "oklch(0.85 0.18 200 / 0.4)",
                  color: activeColor ?? "var(--neon-cyan)",
                  background: activeColor ? undefined : "oklch(0.85 0.18 200 / 0.05)",
                  boxShadow: activeColor ? `0 0 8px ${activeColor}44` : "none",
                  outline: isOpen ? "1px solid var(--neon-cyan)" : "none",
                }}
              >
                <Wifi size={12} />
                <span>{m.replace("VIP", "")}</span>
                {active && <span className="text-[8px]">{TIER_LABELS[st.tier as Exclude<Tier, "off">]}</span>}
              </button>
            </div>
          );
        })}
      </div>

      {/* Inline control panel — expands in flow so no window scroll is needed */}
      {openId &&
        (() => {
          const m = openId;
          const st: QosState = states[m] ?? { enabled: false, tier: "off" };
          const sliderValue: Exclude<Tier, "off"> = st.tier !== "off" ? st.tier : "500K";
          return (
            <div className="mt-2 rounded-lg border border-border bg-surface/95 p-2">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="font-mono text-[11px] uppercase tracking-widest text-glow-cyan">{m}</span>
                <label className="flex items-center gap-1.5 rounded border border-border/50 px-2 py-1 font-mono text-[10px] uppercase text-muted-foreground">
                  <span>QoS</span>
                  <input
                    type="checkbox"
                    checked={st.enabled}
                    onChange={(e) => update(m, { enabled: e.target.checked, tier: e.target.checked ? sliderValue : st.tier })}
                    className="accent-cyan-400"
                  />
                </label>
              </div>

              <TierSlider
                value={sliderValue}
                disabled={!st.enabled}
                colors={colors}
                onChange={(t) => update(m, { enabled: true, tier: t })}
              />

              {errorByMachine[m] ? (
                <div
                  className="mt-1.5 rounded border border-red-500/40 bg-red-500/10 px-1.5 py-1 text-center font-mono text-[8px] normal-case text-red-400"
                  title={errorByMachine[m]}
                >
                  ⚠ اعمال نشد: {errorByMachine[m]}
                </div>
              ) : (
                <div className="mt-1.5 text-center font-mono text-[8px] uppercase text-muted-foreground">
                  agent → {backend}
                </div>
              )}
            </div>
          );
        })()}
    </div>
  );
}
