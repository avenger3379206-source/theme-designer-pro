import { useEffect, useState } from "react";
import { Gauge, CheckCircle2, Cloud, Download } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { computeToday, fmtBytes, type CacheBucket } from "@/lib/daily-report";

const POLL_MS = 5000;

function bytesToMB(n: number): number {
  return Math.round((n / (1024 * 1024)) * 10) / 10;
}

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { value: number; dataKey: string; color: string }[];
  label?: string;
}) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="rounded-lg border border-border/60 bg-surface/95 px-3 py-2 font-mono text-xs shadow-xl">
      <div className="text-muted-foreground">{label}</div>
      {payload.map((p) => (
        <div key={p.dataKey} className="font-bold" style={{ color: p.color }}>
          {p.dataKey === "hit" ? "HIT" : "MISS"}: {p.value.toFixed(1)} MB
        </div>
      ))}
    </div>
  );
}

function Metric({ label, value, icon, color }: { label: string; value: string; icon: React.ReactNode; color: string }) {
  return (
    <div className="rounded-lg border border-border/60 bg-surface/50 p-2">
      <div className="flex items-center gap-1 font-mono text-[9px] uppercase tracking-widest text-muted-foreground">
        <span style={{ color }}>{icon}</span> {label}
      </div>
      <div className="mt-0.5 font-mono text-lg font-black leading-none" style={{ color, textShadow: `0 0 6px ${color}55` }}>
        {value}
      </div>
    </div>
  );
}

export function BandwidthSavingsPanel() {
  const [snap, setSnap] = useState(() => computeToday());

  useEffect(() => {
    const tick = () => setSnap(computeToday());
    tick();
    const id = setInterval(tick, POLL_MS);
    return () => clearInterval(id);
  }, []);

  const served = snap.hitDown + snap.missDown + snap.otherDown;
  const chartData = snap.buckets.map((b: CacheBucket) => ({
    label: b.bucket,
    hit: bytesToMB(b.hit),
    miss: bytesToMB(b.miss),
  }));

  return (
    <div className="mb-3 rounded-xl p-3 glass-panel">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.3em] text-muted-foreground">
          <Gauge size={12} /> ▸ bandwidth savings · today
        </h3>
        <span className="font-mono text-[10px] text-muted-foreground">
          {snap.buckets.length} bucket{snap.buckets.length === 1 ? "" : "s"} · 15m resolution
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        <Metric
          label="Saved"
          value={`${snap.savedPct}%`}
          icon={<Gauge size={12} />}
          color="var(--neon-green)"
        />
        <Metric
          label="Hit · saved"
          value={fmtBytes(snap.hitDown)}
          icon={<CheckCircle2 size={12} />}
          color="var(--neon-green)"
        />
        <Metric
          label="Miss · from internet"
          value={fmtBytes(snap.missDown)}
          icon={<Cloud size={12} />}
          color="var(--neon-red)"
        />
        <Metric
          label="Total served"
          value={fmtBytes(served)}
          icon={<Download size={12} />}
          color="var(--neon-cyan)"
        />
      </div>

      <div className="mt-3 rounded-lg border border-border/50 bg-background/30 p-3">
        <div className="mb-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          HIT (سبز) در برابر MISS (قرمز) — امروز، بازه‌های ۱۵ دقیقه‌ای
        </div>
        {chartData.length === 0 ? (
          <div className="flex h-40 items-center justify-center font-mono text-xs text-muted-foreground">
            هنوز داده‌ای جمع نشده — به‌محض اولین دانلود از یکی از سرویس‌های کش‌شونده، نمودار پر میشه
          </div>
        ) : (
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -12, bottom: 0 }}>
                <defs>
                  <linearGradient id="exirHitFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--neon-green)" stopOpacity={0.55} />
                    <stop offset="100%" stopColor="var(--neon-green)" stopOpacity={0.03} />
                  </linearGradient>
                  <linearGradient id="exirMissFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--neon-red)" stopOpacity={0.55} />
                    <stop offset="100%" stopColor="var(--neon-red)" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="oklch(1 0 0 / 0.08)" />
                <XAxis
                  dataKey="label"
                  interval={Math.max(0, Math.floor(chartData.length / 8) - 1)}
                  tick={{ fontSize: 10, fill: "oklch(0.7 0.02 250)" }}
                  axisLine={{ stroke: "oklch(1 0 0 / 0.1)" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: "oklch(0.7 0.02 250)" }}
                  axisLine={false}
                  tickLine={false}
                  width={40}
                  label={{ value: "MB", angle: -90, position: "insideLeft", fontSize: 10, fill: "oklch(0.7 0.02 250)" }}
                />
                <Tooltip cursor={{ stroke: "oklch(1 0 0 / 0.15)" }} content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="hit"
                  stackId="1"
                  stroke="var(--neon-green)"
                  strokeWidth={1.5}
                  fill="url(#exirHitFill)"
                />
                <Area
                  type="monotone"
                  dataKey="miss"
                  stackId="1"
                  stroke="var(--neon-red)"
                  strokeWidth={1.5}
                  fill="url(#exirMissFill)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
}
