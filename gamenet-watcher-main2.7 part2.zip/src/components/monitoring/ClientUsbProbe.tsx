// Background poller that asks every online VIP's exir-client-agent for its
// current USB device list. Mounted once in the Dashboard route — renders
// nothing.

import { useEffect, useRef } from "react";
import type { ClientStatus } from "@/lib/monitoring-types";
import { ipFromMachine } from "@/lib/cache-activity";
import { fetchUsbDevices, publishUsbDevices, type UsbSnapshot } from "@/lib/usb-monitor";
import { getMachine, loadVncConfig } from "@/lib/vnc-config";
import { isComposing } from "@/lib/compose-lock";

// New-device detection benefits from being a bit snappier than the general
// peripheral poll, but there's no need to hammer it either.
const POLL_MS = 15_000;

interface Props {
  clients: ClientStatus[];
}

export function ClientUsbProbe({ clients }: Props) {
  const clientsRef = useRef<ClientStatus[]>(clients);
  useEffect(() => {
    clientsRef.current = clients;
  }, [clients]);

  useEffect(() => {
    const state: Record<string, UsbSnapshot> = {};
    let alive = true;

    async function tick() {
      if (isComposing()) return;
      const cfg = loadVncConfig();
      const list = clientsRef.current.filter((c) => c.online !== false);
      if (!list.length) return;

      const jobs = list
        .map((c) => {
          const mapped = getMachine(cfg, c.machine);
          const ip = mapped?.host || ipFromMachine(c.machine) || "";
          return ip ? { machine: c.machine, ip } : null;
        })
        .filter((j): j is { machine: string; ip: string } => j !== null);
      if (!jobs.length) return;

      const results = await Promise.all(jobs.map((j) => fetchUsbDevices(j.machine, j.ip)));
      if (!alive) return;
      for (const r of results) state[r.machine] = r;
      publishUsbDevices({ ...state });
    }

    tick();
    const id = setInterval(tick, POLL_MS);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  return null;
}
