import { useEffect, useRef, useState } from "react";
import {
  Usb,
  Plus,
  Trash2,
  Settings2,
  FlipHorizontal2,
  FlipVertical2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Maximize2,
  RefreshCw,
} from "lucide-react";
import {
  loadUsbCameras,
  saveUsbCameras,
  addUsbCamera,
  updateUsbCamera,
  removeUsbCamera,
  openUsbCameraWindow,
  clampZoom,
  USB_CAM_EVT,
  type UsbCameraSlot,
  type UsbCameraState,
} from "@/lib/usb-camera";

// ── One live USB camera tile: owns its own MediaStream ─────────────────
function UsbCameraTile({
  slot,
  devices,
  onSave,
  onDelete,
}: {
  slot: UsbCameraSlot;
  devices: MediaDeviceInfo[];
  onSave: (patch: Partial<UsbCameraSlot>) => void;
  onDelete: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState("");
  const [editOpen, setEditOpen] = useState(false);

  // (Re)acquire the stream whenever the chosen device changes.
  useEffect(() => {
    let stream: MediaStream | null = null;
    let cancelled = false;
    setError("");
    if (!slot.deviceId) return;
    navigator.mediaDevices
      .getUserMedia({ video: { deviceId: { exact: slot.deviceId } }, audio: false })
      .then((s) => {
        if (cancelled) {
          s.getTracks().forEach((t) => t.stop());
          return;
        }
        stream = s;
        if (videoRef.current) videoRef.current.srcObject = s;
      })
      .catch((e: Error) => setError(e.message || "اتصال به دوربین ناموفق بود"));
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [slot.deviceId]);

  const transform = `scaleX(${slot.mirrorX ? -1 : 1}) scaleY(${slot.mirrorY ? -1 : 1}) scale(${slot.zoom})`;

  return (
    <div className="overflow-hidden rounded-lg border border-border/50 bg-black/40">
      <div className="relative aspect-video w-full overflow-hidden bg-black">
        {slot.deviceId ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="h-full w-full object-cover transition-transform duration-100"
            style={{ transform }}
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-1.5 text-center">
            <Usb size={20} className="text-muted-foreground/50" />
            <span className="font-mono text-[11px] text-muted-foreground">
              دستگاهی انتخاب نشده — از تنظیمات پایین انتخاب کن
            </span>
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-1.5 bg-black/80 px-3 text-center">
            <span className="font-mono text-[11px] text-red-300">{error}</span>
          </div>
        )}

        {/* Overlay: name */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent px-2 py-1.5">
          <span className="font-mono text-xs font-bold text-white drop-shadow">{slot.name}</span>
        </div>

        {/* Overlay: quick controls */}
        {slot.deviceId && !error && (
          <div className="absolute inset-x-1.5 bottom-1.5 flex items-center justify-center gap-1 rounded-full border border-border/50 bg-black/60 px-1.5 py-1 backdrop-blur">
            <button
              onClick={() => onSave({ mirrorX: !slot.mirrorX })}
              title="قرینه افقی (چپ به راست)"
              className={`flex size-6 items-center justify-center rounded-full ${slot.mirrorX ? "bg-cyan-500/40 text-cyan-100" : "text-muted-foreground hover:text-foreground"}`}
            >
              <FlipHorizontal2 size={12} />
            </button>
            <button
              onClick={() => onSave({ mirrorY: !slot.mirrorY })}
              title="قرینه عمودی (بالا به پایین)"
              className={`flex size-6 items-center justify-center rounded-full ${slot.mirrorY ? "bg-cyan-500/40 text-cyan-100" : "text-muted-foreground hover:text-foreground"}`}
            >
              <FlipVertical2 size={12} />
            </button>
            <div className="mx-0.5 h-4 w-px bg-border/60" />
            <button
              onClick={() => onSave({ zoom: clampZoom(slot.zoom - 0.25) })}
              title="کوچک‌نمایی"
              className="flex size-6 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <ZoomOut size={12} />
            </button>
            <span className="min-w-8 text-center font-mono text-[10px] text-muted-foreground">
              {Math.round(slot.zoom * 100)}%
            </span>
            <button
              onClick={() => onSave({ zoom: clampZoom(slot.zoom + 0.25) })}
              title="بزرگ‌نمایی"
              className="flex size-6 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <ZoomIn size={12} />
            </button>
            <button
              onClick={() => onSave({ zoom: 1, mirrorX: false, mirrorY: false })}
              title="ریست"
              className="flex size-6 items-center justify-center rounded-full text-muted-foreground hover:text-foreground"
            >
              <RotateCcw size={12} />
            </button>
            <div className="mx-0.5 h-4 w-px bg-border/60" />
            <button
              onClick={() => openUsbCameraWindow(slot)}
              title="باز کردن در صفحه جدید (بزرگ‌نمایی کامل)"
              className="flex size-6 items-center justify-center rounded-full text-cyan-300 hover:bg-cyan-500/20"
            >
              <Maximize2 size={12} />
            </button>
          </div>
        )}
      </div>

      {/* Settings row */}
      <div className="border-t border-border/40 bg-background/30 p-2">
        <button
          onClick={() => setEditOpen((v) => !v)}
          className="flex w-full items-center justify-between font-mono text-[10px] text-muted-foreground hover:text-foreground"
        >
          <span className="flex items-center gap-1.5">
            <Settings2 size={11} /> تنظیمات
          </span>
          <span>{editOpen ? "▲" : "▼"}</span>
        </button>
        {editOpen && (
          <div className="mt-2 space-y-1.5">
            <input
              value={slot.name}
              onChange={(e) => onSave({ name: e.target.value })}
              placeholder="اسم دوربین (مثلاً دوربین تعمیراتی)"
              className="w-full rounded-lg border border-border/60 bg-background/40 px-2.5 py-1.5 font-mono text-xs text-foreground"
            />
            <select
              value={slot.deviceId}
              onChange={(e) => {
                const d = devices.find((x) => x.deviceId === e.target.value);
                onSave({ deviceId: e.target.value, deviceLabel: d?.label || "" });
              }}
              className="w-full rounded-lg border border-border/60 bg-background/40 px-2 py-1.5 font-mono text-xs text-foreground"
            >
              <option value="">— انتخاب دستگاه —</option>
              {devices.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || "دوربین بدون‌نام"}
                </option>
              ))}
              {slot.deviceId && !devices.some((d) => d.deviceId === slot.deviceId) && (
                <option value={slot.deviceId}>
                  {slot.deviceLabel || "دستگاه قبلی (یافت نشد — دوباره وصل کن)"}
                </option>
              )}
            </select>
            <button
              onClick={onDelete}
              className="flex items-center gap-1.5 rounded-lg border border-red-500/50 px-2.5 py-1 font-mono text-[11px] text-red-300 hover:bg-red-500/10"
            >
              <Trash2 size={11} /> حذف این دوربین
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Panel: list of USB camera slots + "grant access" + "add" ───────────
export function UsbCameraPanel() {
  const [state, setState] = useState<UsbCameraState>(() => loadUsbCameras());
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [permission, setPermission] = useState<"unknown" | "granted" | "denied">("unknown");

  useEffect(() => {
    const refresh = () => setState(loadUsbCameras());
    window.addEventListener(USB_CAM_EVT, refresh);
    return () => window.removeEventListener(USB_CAM_EVT, refresh);
  }, []);

  async function refreshDevices() {
    try {
      const list = await navigator.mediaDevices.enumerateDevices();
      setDevices(list.filter((d) => d.kind === "videoinput"));
    } catch {
      /* ignore */
    }
  }

  // Device labels are blank until permission is granted at least once —
  // try a silent enumerate on mount (works if permission was already
  // granted in an earlier session), no popup if not.
  useEffect(() => {
    refreshDevices();
    navigator.mediaDevices?.addEventListener?.("devicechange", refreshDevices);
    return () => navigator.mediaDevices?.removeEventListener?.("devicechange", refreshDevices);
  }, []);

  async function grantAccess() {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: true });
      s.getTracks().forEach((t) => t.stop()); // only needed it to unlock device labels
      setPermission("granted");
      await refreshDevices();
    } catch {
      setPermission("denied");
    }
  }

  function handleChange(next: UsbCameraState) {
    saveUsbCameras(next);
    setState(next);
  }

  return (
    <div className="mt-4 border-t border-border/40 pt-3">
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <h4 className="flex items-center gap-2 font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">
          <Usb size={13} /> <span className="font-fa" lang="fa">دوربین‌های USB / وبکم</span>
        </h4>
        <div className="flex items-center gap-1.5">
          <button
            onClick={grantAccess}
            className="flex items-center gap-1.5 rounded-lg border border-border/60 px-2.5 py-1 font-mono text-[11px] text-muted-foreground hover:text-foreground"
            title="اگه اسم دستگاه‌ها خالیه، یه بار این رو بزن تا مرورگر اجازه بده"
          >
            <RefreshCw size={11} /> دسترسی / بروزرسانی دستگاه‌ها
          </button>
          <button
            onClick={() => handleChange(addUsbCamera(state))}
            className="flex items-center gap-1.5 rounded-lg border border-cyan-400/60 bg-cyan-500/10 px-2.5 py-1 font-mono text-xs text-cyan-200 hover:bg-cyan-500/20"
          >
            <Plus size={13} /> افزودن دوربین USB
          </button>
        </div>
      </div>

      {permission === "denied" && (
        <p className="mb-2 font-mono text-[11px] text-red-300">
          دسترسی به دوربین رد شد — از تنظیمات مرورگر (کنار آدرس بار) اجازه بده.
        </p>
      )}

      {state.cameras.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border/50 py-8 text-center">
          <Usb size={22} className="text-muted-foreground/40" />
          <p className="font-mono text-[11px] text-muted-foreground">
            دوربین USB/وبکم اضافه نشده — با «افزودن دوربین USB» شروع کن (برای دوربین تعمیراتی هم همینجا اضافه کن).
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {state.cameras.map((slot) => (
            <UsbCameraTile
              key={slot.id}
              slot={slot}
              devices={devices}
              onSave={(patch) => handleChange(updateUsbCamera(state, slot.id, patch))}
              onDelete={() => handleChange(removeUsbCamera(state, slot.id))}
            />
          ))}
        </div>
      )}
    </div>
  );
}
