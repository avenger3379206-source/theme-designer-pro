import { useEffect, useState } from "react";
import type { PingTarget } from "@/lib/monitoring-types";
import { colorFor, gradientColorAt, loadSettings, type GaugeSettings } from "@/lib/gauge-settings";
import { isPingAgentActive } from "@/lib/ping";

// Selectable AVG/LOSS windows. Values are ms; `short` is the compact label
// shown in the pill next to each target (kept short so the grid stays tidy).
const WINDOW_OPTIONS: { ms: number; label: string; short: string }[] = [
  { ms: 30_000, label: "30 ثانیه", short: "30s" },
  { ms: 60_000, label: "1 دقیقه", short: "1m" },
  { ms: 120_000, label: "2 دقیقه", short: "2m" },
  { ms: 300_000, label: "5 دقیقه", short: "5m" },
];
// Default bumped from 30s → 1m: a single bad tick (one dropped packet) was
// swinging the loss% too hard over just 30s; 1m smooths that out while still
// reacting quickly. User can change this any time via the dropdown below —
// the choice is remembered in localStorage.
const DEFAULT_WINDOW_MS = 60_000;
const WINDOW_STORAGE_KEY = "exir.ping.avgWindowMs.v1";

function loadWindowMs(): number {
  try {
    const raw = localStorage.getItem(WINDOW_STORAGE_KEY);
    const n = raw ? Number(raw) : NaN;
    if (WINDOW_OPTIONS.some((o) => o.ms === n)) return n;
  } catch {
    /* ignore */
  }
  return DEFAULT_WINDOW_MS;
}

function saveWindowMs(ms: number) {
  try {
    localStorage.setItem(WINDOW_STORAGE_KEY, String(ms));
  } catch {
    /* ignore */
  }
}

function useGaugeSettings(): GaugeSettings {
  const [s, setS] = useState<GaugeSettings>(() => loadSettings());
  useEffect(() => {
    const h = () => setS(loadSettings());
    window.addEventListener("exir:gauge-settings", h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener("exir:gauge-settings", h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return s;
}

interface Props {
  targets: PingTarget[];
  onEdit: (index: number, next: { label: string; host: string }) => void;
}

export function PingPanel({ targets, onEdit }: Props) {
  const settings = useGaugeSettings();
  const [editing, setEditing] = useState<number | null>(null);
  const [draftLabel, setDraftLabel] = useState("");
  const [draftHost, setDraftHost] = useState("");
  const [agentActive, setAgentActive] = useState<boolean | null>(() => isPingAgentActive());
  const [avgWindowMs, setAvgWindowMs] = useState<number>(() => loadWindowMs());

  useEffect(() => {
    const id = setInterval(() => setAgentActive(isPingAgentActive()), 2000);
    return () => clearInterval(id);
  }, []);

  function handleWindowChange(ms: number) {
    setAvgWindowMs(ms);
    saveWindowMs(ms);
  }

  function startEdit(i: number, t: PingTarget) {
    setEditing(i);
    setDraftLabel(t.label);
    setDraftHost(t.host);
  }
  function commit() {
    if (editing === null) return;
    const host = draftHost.trim();
    const label = draftLabel.trim() || host;
    if (host) onEdit(editing, { label, host });
    setEditing(null);
  }

  const now = Date.now();
  const activeWindow = WINDOW_OPTIONS.find((o) => o.ms === avgWindowMs) ?? WINDOW_OPTIONS[1];

  return (
    <div className="rounded-xl p-4 glass-panel">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">network · ping</h3>
        <div className="flex items-center gap-2">
          {agentActive === false && (
            <span
              title="ping-agent.mjs در دسترس نیست — اعداد از طریق تخمین مرورگر محاسبه می‌شن و دقیق نیستن. مطمئن شو با npm run dev اجرا شده و همین سیستمی هستی که روش اجرا شده."
              className="rounded-full border border-amber-400/60 bg-amber-500/10 px-2 py-0.5 font-mono text-[10px] text-amber-300"
            >
              ⚠ حالت تخمینی (agent در دسترس نیست)
            </span>
          )}
          <label className="flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground">
            avg window:
            <select
              value={avgWindowMs}
              onChange={(e) => handleWindowChange(Number(e.target.value))}
              title="بازه‌ی زمانی محاسبه‌ی میانگین پینگ و درصد پکت‌لاس"
              className="rounded border border-border/60 bg-background/60 px-1.5 py-0.5 font-mono text-[10px] text-foreground outline-none focus:border-cyan-500"
            >
              {WINDOW_OPTIONS.map((o) => (
                <option key={o.ms} value={o.ms}>
                  {o.short}
                </option>
              ))}
            </select>
          </label>
          <span className="font-mono text-[10px] text-muted-foreground">click to edit</span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-6">
        {targets.map((t, i) => {
          // Rolling window (user-selectable, default 1m) for avg/loss
          const windowed = t.history.filter((s) => now - s.t <= avgWindowMs);
          const valid = windowed.filter((s) => s.v >= 0);
          const avg = valid.length ? valid.reduce((a, b) => a + b.v, 0) / valid.length : 0;
          const loss = windowed.length
            ? Math.round(((windowed.length - valid.length) / windowed.length) * 100)
            : 0;
          const lastSample = t.history[t.history.length - 1];
          const last = lastSample?.v;
          const colorBasis = last !== undefined && last >= 0 ? last : avg;
          const color = loss > 30 ? "#ef4444" : (settings.colorMode === "gradient" || settings.colorMode === "gradientFill") ? gradientColorAt(settings.gradient, colorBasis / 300) : colorFor(settings.ping, colorBasis);
          // last 6 samples for sparkline
          const spark = t.history.slice(-6);
          const isEditing = editing === i;

          return (
            <div
              key={i}
              onClick={() => !isEditing && startEdit(i, t)}
              className="cursor-pointer rounded-md border border-border/60 bg-surface/40 p-2.5 transition hover:border-cyan-500/60 hover:bg-surface/60"
            >
              {isEditing ? (
                <div onClick={(e) => e.stopPropagation()} className="space-y-1.5">
                  <input
                    autoFocus
                    value={draftLabel}
                    onChange={(e) => setDraftLabel(e.target.value)}
                    placeholder="label"
                    className="w-full rounded border border-border bg-background/60 px-2 py-1 font-mono text-[11px] text-foreground outline-none focus:border-cyan-500"
                  />
                  <input
                    value={draftHost}
                    onChange={(e) => setDraftHost(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") commit();
                      if (e.key === "Escape") setEditing(null);
                    }}
                    placeholder="host or ip"
                    className="w-full rounded border border-border bg-background/60 px-2 py-1 font-mono text-[11px] text-foreground outline-none focus:border-cyan-500"
                  />
                  <div className="flex gap-1">
                    <button
                      onClick={commit}
                      className="flex-1 rounded border border-green-500/50 bg-green-500/10 py-1 font-mono text-[10px] uppercase text-green-300 hover:bg-green-500/20"
                    >
                      save
                    </button>
                    <button
                      onClick={() => setEditing(null)}
                      className="flex-1 rounded border border-border py-1 font-mono text-[10px] uppercase text-muted-foreground hover:text-foreground"
                    >
                      cancel
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <span className="truncate font-mono text-[11px] font-semibold uppercase">{t.label}</span>
                    <span className="size-1.5 shrink-0 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
                  </div>
                  <div className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground">{t.host}</div>

                  <div className="mt-1.5 flex items-baseline gap-1">
                    <span className="font-mono text-lg font-bold leading-none" style={{ color: last !== undefined && last < 0 ? "var(--neon-red)" : color, textShadow: `0 0 8px ${last !== undefined && last < 0 ? "var(--neon-red)" : color}` }}>
                      {last === undefined ? "—" : last < 0 ? "✕" : last}
                    </span>
                    <span className="font-mono text-[9px] uppercase text-muted-foreground">{last !== undefined && last >= 0 ? "ms" : "loss"}</span>
                  </div>

                  <div className="mt-1.5 flex h-7 items-end gap-0.5">
                    {Array.from({ length: 6 }).map((_, idx) => {
                      const s = spark[idx];
                      if (!s) {
                        return <div key={idx} className="flex-1 rounded-sm bg-border/40" style={{ height: 3 }} />;
                      }
                      const v = s.v;
                      return (
                        <div
                          key={idx}
                          title={v < 0 ? "loss" : `${v}ms`}
                          className="flex-1 rounded-sm"
                          style={{
                            height: v < 0 ? 4 : Math.max(4, Math.min(28, v / 5)),
                            background: v < 0 ? "var(--neon-red)" : color,
                            opacity: v < 0 ? 0.7 : 0.9,
                          }}
                        />
                      );
                    })}
                  </div>

                  <div className="mt-1.5 flex justify-between font-mono text-[10px]">
                    <span className="text-muted-foreground">AVG <span style={{ color }}>{valid.length ? avg.toFixed(0) : "—"}{valid.length ? "ms" : ""}</span></span>
                    <span className="text-muted-foreground">LOSS ({activeWindow.short}) <span style={{ color: loss > 0 ? "var(--neon-red)" : "var(--foreground)" }}>{loss}%</span></span>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
