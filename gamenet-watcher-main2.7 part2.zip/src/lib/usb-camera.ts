// USB / webcam configuration — separate from camera-config.ts (which is for
// network/NVR cameras reached over a URL). These are cameras plugged
// directly into THIS pc's USB port and read via the browser's own
// getUserMedia() API — no NVR, no network address, just a device picked
// from the list Windows/Chrome already sees. Meant for things like a
// handheld repair/inspection camera as well as ordinary USB webcams.
//
// deviceId is only stable for the current browser session in some browsers
// (it can rotate after a reboot/replug), so deviceLabel is kept alongside
// it purely to help a human re-pick the right device from the dropdown if
// deviceId ever goes stale — it's not used for automatic matching.

export interface UsbCameraSlot {
  id: string;
  name: string; // e.g. "دوربین تعمیراتی"
  deviceId: string; // MediaDeviceInfo.deviceId — "" until a device is picked
  deviceLabel: string; // last-known label, for reference only
  mirrorX: boolean; // flip left/right
  mirrorY: boolean; // flip up/down
  zoom: number; // 1..4, digital zoom
}

export interface UsbCameraState {
  cameras: UsbCameraSlot[];
}

const STORAGE_KEY = "exir.usbcam.config.v1";
export const USB_CAM_EVT = "exir:usbcam-config";

function genId(): string {
  return `usbcam_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function defaultUsbCameraState(): UsbCameraState {
  return { cameras: [] };
}

export function loadUsbCameras(): UsbCameraState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultUsbCameraState();
    const parsed = JSON.parse(raw) as Partial<UsbCameraState>;
    if (!Array.isArray(parsed.cameras)) return defaultUsbCameraState();
    return {
      cameras: parsed.cameras.map((c) => ({
        id: c.id || genId(),
        name: c.name || "دوربین USB",
        deviceId: c.deviceId || "",
        deviceLabel: c.deviceLabel || "",
        mirrorX: !!c.mirrorX,
        mirrorY: !!c.mirrorY,
        zoom: typeof c.zoom === "number" && c.zoom >= 1 ? c.zoom : 1,
      })),
    };
  } catch {
    return defaultUsbCameraState();
  }
}

export function saveUsbCameras(state: UsbCameraState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    window.dispatchEvent(new Event(USB_CAM_EVT));
  } catch {
    /* ignore quota errors */
  }
}

export function addUsbCamera(state: UsbCameraState, name = "دوربین USB جدید"): UsbCameraState {
  const cam: UsbCameraSlot = {
    id: genId(),
    name,
    deviceId: "",
    deviceLabel: "",
    mirrorX: false,
    mirrorY: false,
    zoom: 1,
  };
  const next = { cameras: [...state.cameras, cam] };
  saveUsbCameras(next);
  return next;
}

export function updateUsbCamera(state: UsbCameraState, id: string, patch: Partial<UsbCameraSlot>): UsbCameraState {
  const next = { cameras: state.cameras.map((c) => (c.id === id ? { ...c, ...patch } : c)) };
  saveUsbCameras(next);
  return next;
}

export function removeUsbCamera(state: UsbCameraState, id: string): UsbCameraState {
  const next = { cameras: state.cameras.filter((c) => c.id !== id) };
  saveUsbCameras(next);
  return next;
}

export const ZOOM_MIN = 1;
export const ZOOM_MAX = 4;
export const ZOOM_STEP = 0.25;

export function clampZoom(z: number): number {
  return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(z / ZOOM_STEP) * ZOOM_STEP));
}

/** Opens a standalone, same-origin popup window showing just this camera,
 * full-size, with its own zoom/mirror controls — handy for using a USB
 * inspection/repair camera as a dedicated magnifier while working, without
 * the rest of the dashboard in the way. Self-contained: builds its DOM and
 * requests the camera stream itself, so it keeps working even if the main
 * dashboard tab is later closed. */
export function openUsbCameraWindow(slot: UsbCameraSlot) {
  const win = window.open("", "_blank", "width=1000,height=760");
  if (!win) return; // popup blocked

  win.document.title = slot.name || "دوربین USB";
  win.document.head.innerHTML = `<meta charset="utf-8"><style>
    html,body{margin:0;height:100%;background:#000;overflow:hidden;font-family:ui-monospace,monospace}
    #wrap{position:relative;width:100vw;height:100vh;display:flex;align-items:center;justify-content:center;background:#000}
    video{max-width:100%;max-height:100%;transition:transform .1s ease-out}
    #bar{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);display:flex;gap:8px;
      background:rgba(0,0,0,.55);backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.15);
      border-radius:999px;padding:8px 12px}
    #bar button{all:unset;cursor:pointer;color:#e5faff;font-size:12px;padding:6px 10px;border-radius:999px}
    #bar button:hover{background:rgba(255,255,255,.12)}
    #bar button.active{background:rgba(56,189,248,.35);color:#fff}
    #msg{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#889;font-size:13px}
  </style>`;

  const body = win.document.body;
  body.innerHTML = `
    <div id="wrap">
      <div id="msg">در حال اتصال به دوربین…</div>
      <video id="v" autoplay playsinline muted></video>
      <div id="bar" style="display:none">
        <button id="fx" title="قرینه افقی">⇋</button>
        <button id="fy" title="قرینه عمودی">⇵</button>
        <button id="zo">−</button>
        <span id="zl" style="align-self:center;color:#889;font-size:11px;min-width:34px;text-align:center">100%</span>
        <button id="zi">+</button>
        <button id="rs">ریست</button>
      </div>
    </div>`;

  const script = win.document.createElement("script");
  script.textContent = `
    (function(){
      var state = { mx: ${slot.mirrorX ? "true" : "false"}, my: ${slot.mirrorY ? "true" : "false"}, zoom: ${slot.zoom || 1} };
      var v = document.getElementById('v');
      var msg = document.getElementById('msg');
      var bar = document.getElementById('bar');
      var zl = document.getElementById('zl');
      function apply() {
        v.style.transform = 'scaleX(' + (state.mx ? -1 : 1) + ') scaleY(' + (state.my ? -1 : 1) + ') scale(' + state.zoom + ')';
        zl.textContent = Math.round(state.zoom * 100) + '%';
        document.getElementById('fx').className = state.mx ? 'active' : '';
        document.getElementById('fy').className = state.my ? 'active' : '';
      }
      document.getElementById('fx').onclick = function(){ state.mx = !state.mx; apply(); };
      document.getElementById('fy').onclick = function(){ state.my = !state.my; apply(); };
      document.getElementById('zi').onclick = function(){ state.zoom = Math.min(4, Math.round((state.zoom + 0.25) * 100) / 100); apply(); };
      document.getElementById('zo').onclick = function(){ state.zoom = Math.max(1, Math.round((state.zoom - 0.25) * 100) / 100); apply(); };
      document.getElementById('rs').onclick = function(){ state.zoom = 1; state.mx = false; state.my = false; apply(); };
      window.addEventListener('wheel', function(e){
        e.preventDefault();
        state.zoom = Math.min(4, Math.max(1, Math.round((state.zoom + (e.deltaY < 0 ? 0.15 : -0.15)) * 100) / 100));
        apply();
      }, { passive: false });
      apply();
      var constraints = { video: ${slot.deviceId ? `{ deviceId: { exact: ${JSON.stringify(slot.deviceId)} } }` : "true"}, audio: false };
      navigator.mediaDevices.getUserMedia(constraints).then(function(stream){
        v.srcObject = stream;
        msg.style.display = 'none';
        bar.style.display = 'flex';
        window.addEventListener('beforeunload', function(){ stream.getTracks().forEach(function(t){ t.stop(); }); });
      }).catch(function(err){
        msg.textContent = 'اتصال به دوربین ناموفق بود: ' + (err && err.message ? err.message : err);
      });
    })();
  `;
  win.document.body.appendChild(script);
}
