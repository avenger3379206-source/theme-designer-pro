import type { ClientStatus, ServerStatus, LiveHardwareStats } from "./monitoring-types";

// ---------- Persistent directory handle in IndexedDB ----------

const DB_NAME = "exir-monitor";
const STORE = "handles";
const KEY = "statusDir";

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 2);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      if (!db.objectStoreNames.contains("branding")) db.createObjectStore("branding");
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveDirHandle(handle: FileSystemDirectoryHandle) {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(handle, KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function loadDirHandle(): Promise<FileSystemDirectoryHandle | null> {
  try {
    const db = await openDB();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(KEY);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function clearDirHandle() {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// ---------- Permission helpers ----------

export async function ensurePermission(handle: FileSystemDirectoryHandle): Promise<boolean> {
  // @ts-expect-error - queryPermission isn't in default lib
  const q = await handle.queryPermission?.({ mode: "read" });
  if (q === "granted") return true;
  // @ts-expect-error - requestPermission isn't in default lib
  const r = await handle.requestPermission?.({ mode: "read" });
  return r === "granted";
}

export function isFileSystemAccessSupported(): boolean {
  return typeof window !== "undefined" && "showDirectoryPicker" in window;
}

export async function pickStatusDirectory(): Promise<FileSystemDirectoryHandle | null> {
  if (!isFileSystemAccessSupported()) return null;
  try {
    // @ts-expect-error - showDirectoryPicker isn't in default lib
    const handle: FileSystemDirectoryHandle = await window.showDirectoryPicker({
      id: "exir-status",
      mode: "read",
      startIn: "documents",
    });
    await saveDirHandle(handle);
    return handle;
  } catch {
    return null; // user cancelled
  }
}

// ---------- Reading JSON files ----------

async function readJsonFile(
  dir: FileSystemDirectoryHandle,
  name: string,
): Promise<{ data: unknown; lastModified: number } | null> {
  try {
    // try both as-given and uppercase/lowercase extension
    const candidates = [name, name.replace(/\.json$/i, ".JSON"), name.replace(/\.JSON$/i, ".json")];
    for (const candidate of candidates) {
      try {
        const fileHandle = await dir.getFileHandle(candidate);
        const file = await fileHandle.getFile();
        const text = await file.text();
        return { data: JSON.parse(text), lastModified: file.lastModified };
      } catch {
        /* try next */
      }
    }
    return null;
  } catch {
    return null;
  }
}

/** Formats a seconds count as "00h 00m 00s", for agents that only report
 * uptime_seconds (no pre-formatted uptime string). */
function formatUptime(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m ${String(sec).padStart(2, "0")}s`;
}

function normalizeClient(raw: Record<string, unknown>, fallbackMachine: string): ClientStatus {
  const num = (v: unknown, d = 0) => (typeof v === "number" && isFinite(v) ? v : d);
  // The C# agent writes a richer nested format; extract flat fields for
  // backwards compatibility, but also keep the nested payload for the live panel.
  const cpu = raw.cpu as Record<string, unknown> | undefined;
  const gpu = raw.gpu as Record<string, unknown> | undefined;
  const ram = raw.ram as Record<string, unknown> | undefined;
  return {
    machine: typeof raw.machine === "string" ? raw.machine : fallbackMachine,
    gpuTemp: num(raw.gpuTemp ?? gpu?.temp_c),
    gpuUsage: num(raw.gpuUsage ?? gpu?.usage_percent),
    cpuTemp: num(raw.cpuTemp ?? cpu?.temp_c),
    cpuUsage: typeof (raw.cpuUsage ?? cpu?.usage_percent) === "number" ? (raw.cpuUsage ?? cpu?.usage_percent) as number : undefined,
    ram: num(raw.ram ?? ram?.usage_percent),
    fps: num(raw.fps),
    gpuName: typeof raw.gpuName === "string" ? raw.gpuName : (typeof gpu?.name === "string" ? gpu.name : "Unknown GPU"),
    topProcess: typeof raw.topProcess === "string" ? raw.topProcess : "—",
    thermalLevel: num(raw.thermalLevel, 1),
    profile: num(raw.profile, 1),
    timestamp: typeof raw.timestamp === "string" ? raw.timestamp : new Date().toISOString(),
    online: true,
  };
}

/** Extract the full nested live payload from a raw JSON record, if present. */
export function extractLiveStats(raw: Record<string, unknown>): LiveHardwareStats | null {
  if (!raw.cpu || !raw.gpu || !raw.ram) return null;
  const n = (v: unknown): number | null => (typeof v === "number" && isFinite(v) ? v : null);
  const s = (v: unknown): string => (typeof v === "string" ? v : "");
  const cpu = raw.cpu as Record<string, unknown>;
  const gpu = raw.gpu as Record<string, unknown>;
  const ram = raw.ram as Record<string, unknown>;
  const disk = (raw.disk as Record<string, unknown>) || {};
  const network = (raw.network as Record<string, unknown>) || {};
  const motherboard = (raw.motherboard as Record<string, unknown>) || {};
  const battery = (raw.battery as Record<string, unknown>) || {};
  return {
    timestamp: s(raw.timestamp) || new Date().toISOString(),
    hostname: s(raw.hostname ?? raw.machine),
    uptime_seconds: n(raw.uptime_seconds) ?? 0,
    cpu: {
      name: s(cpu.name),
      usage_percent: n(cpu.usage_percent),
      temp_c: n(cpu.temp_c),
      frequency_mhz: n(cpu.frequency_mhz),
      power_w: n(cpu.power_w),
      fan_rpm: n(cpu.fan_rpm),
      pump_rpm: n(cpu.pump_rpm),
      cores: n(cpu.cores) ?? 0,
    },
    gpu: {
      name: s(gpu.name),
      usage_percent: n(gpu.usage_percent),
      temp_c: n(gpu.temp_c),
      memory_used_mb: n(gpu.memory_used_mb),
      memory_total_mb: n(gpu.memory_total_mb),
      fan_rpm: n(gpu.fan_rpm),
      fan_percent: n(gpu.fan_percent),
      power_w: n(gpu.power_w),
      frequency_mhz: n(gpu.frequency_mhz),
    },
    ram: {
      used_gb: n(ram.used_gb),
      total_gb: n(ram.total_gb),
      usage_percent: n(ram.usage_percent),
      frequency_mhz: n(ram.frequency_mhz),
    },
    disk: {
      read_mb_s: n(disk.read_mb_s),
      write_mb_s: n(disk.write_mb_s),
      usage_percent: n(disk.usage_percent),
      temp_c: n(disk.temp_c),
      drives: Array.isArray(disk.drives) ? (disk.drives as any[]) : [],
    },
    network: {
      upload_mb_s: n(network.upload_mb_s),
      download_mb_s: n(network.download_mb_s),
      ip: s(network.ip),
      interface: s(network.interface),
    },
    motherboard: {
      name: s(motherboard.name),
      temp_c: n(motherboard.temp_c),
      case_fans: Array.isArray(motherboard.case_fans) ? (motherboard.case_fans as any[]) : [],
    },
    battery: {
      present: !!battery.present,
      charging: !!battery.charging,
      percent: n(battery.percent),
      power_w: n(battery.power_w),
      voltage_v: n(battery.voltage_v),
    },
  };
}




export async function readAllClients(dir: FileSystemDirectoryHandle): Promise<ClientStatus[]> {
  const STALE_MS = 30_000;
  const now = Date.now();
  const results = await Promise.all(
    Array.from({ length: 12 }, async (_, i) => {
      const id = String(i + 1).padStart(2, "0");
      const machine = `VIP${id}`;
      const result = await readJsonFile(dir, `${machine}.json`);
      if (!result || typeof result.data !== "object" || result.data === null) return null; // file missing → hide from grid
      const raw = result.data as Record<string, unknown>;
      const c = normalizeClient(raw, machine);
      c.liveStats = extractLiveStats(raw);
      // Use the FILE's actual filesystem mtime, not the timestamp field the
      // client itself wrote — a client whose system clock is wrong (this is
      // what caused VIP08 to look "always online" before, via a hardcoded
      // override) still writes the file at the real current instant as far
      // as the OS is concerned, so this is immune to that class of bug for
      // every machine, not just one hardcoded exception.
      if (now - result.lastModified > STALE_MS) c.online = false;
      return c;
    }),
  );
  return results.filter((c): c is ClientStatus => c !== null);
}

export async function readServer(dir: FileSystemDirectoryHandle): Promise<ServerStatus | null> {
  try {
    // New layout: EXIR-SERVER.json sits right next to the VIPxx.json files
    // inside the selected status/Info folder — try that first.
    let result = await readJsonFile(dir, "EXIR-SERVER.json");
    if (!result) {
      // Back-compat: older agent builds wrote it into a Server/ subfolder.
      try {
        const serverDir = await dir.getDirectoryHandle("Server").catch(() => dir.getDirectoryHandle("server"));
        result = await readJsonFile(serverDir, "Exir-Server.json");
      } catch {
        /* no Server subfolder either — fall through to null below */
      }
    }
    if (!result || typeof result.data !== "object" || result.data === null) return null;
    const raw = result.data as Record<string, unknown>;
    const num = (v: unknown, d = 0) => (typeof v === "number" && isFinite(v) ? v : d);
    // The C# agent writes the rich nested format (cpu.temp_c, gpu.usage_percent,
    // ram.used_gb, ...) — same shape as normalizeClient() uses for VIP clients.
    // Fall back to those nested fields whenever the flat legacy field is absent,
    // otherwise every server-card number silently reads as 0.
    const cpu = raw.cpu as Record<string, unknown> | undefined;
    const gpu = raw.gpu as Record<string, unknown> | undefined;
    const ram = raw.ram as Record<string, unknown> | undefined;
    const uptimeSeconds = num(raw.uptime_seconds, NaN);
    return {
      name: typeof raw.name === "string" ? raw.name : (typeof raw.hostname === "string" ? raw.hostname : (typeof raw.machine === "string" ? raw.machine : "EXIR-SERVER")),
      gpuTemp: num(raw.gpuTemp ?? gpu?.temp_c),
      gpuUsage: num(raw.gpuUsage ?? gpu?.usage_percent),
      cpuTemp: num(raw.cpuTemp ?? cpu?.temp_c),
      cpuUsage: num(raw.cpuUsage ?? raw.cpuLoad ?? cpu?.usage_percent),
      ramUsed: num(raw.ramUsed ?? raw.ram ?? ram?.used_gb),
      ramTotal: num(raw.ramTotal ?? ram?.total_gb, 32),
      fps: num(raw.fps),
      uptime: typeof raw.uptime === "string" ? raw.uptime : (isFinite(uptimeSeconds) ? formatUptime(uptimeSeconds) : "—"),
      timestamp: typeof raw.timestamp === "string" ? raw.timestamp : new Date().toISOString(),
      online: Date.now() - result.lastModified <= 30_000,
      liveStats: extractLiveStats(raw) ?? undefined,
    };
  } catch {
    return null;
  }
}
