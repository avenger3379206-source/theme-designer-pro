export interface ClientStatus {
  machine: string;
  gpuTemp: number;
  gpuUsage: number;
  cpuTemp: number;
  cpuUsage?: number;
  ram: number;
  fps: number;
  gpuName: string;
  topProcess: string;
  thermalLevel: number;
  profile: number;
  timestamp: string;
  online?: boolean;
  /** Rich nested payload from the C# agent, if present. */
  liveStats?: LiveHardwareStats;
}

/** Rich live hardware stats from the C# agent (LibreHardwareMonitor). */
export interface LiveHardwareStats {
  timestamp: string;
  hostname: string;
  uptime_seconds: number;
  cpu: {
    name: string;
    usage_percent: number | null;
    temp_c: number | null;
    frequency_mhz: number | null;
    power_w: number | null;
    fan_rpm: number | null;
    pump_rpm?: number | null;
    cores: number;
  };
  gpu: {
    name: string;
    usage_percent: number | null;
    temp_c: number | null;
    memory_used_mb: number | null;
    memory_total_mb: number | null;
    fan_rpm: number | null;
    fan_percent: number | null;
    power_w: number | null;
    frequency_mhz: number | null;
  };
  ram: {
    used_gb: number | null;
    total_gb: number | null;
    usage_percent: number | null;
    frequency_mhz: number | null;
  };
  disk: {
    read_mb_s: number | null;
    write_mb_s: number | null;
    usage_percent: number | null;
    temp_c: number | null;
    drives: { letter: string; used_gb: number; total_gb: number; percent: number }[];
  };
  network: {
    upload_mb_s: number | null;
    download_mb_s: number | null;
    ip: string;
    interface: string;
  };
  motherboard: {
    name: string;
    temp_c: number | null;
    case_fans: { name: string; rpm: number | null }[];
  };
  battery: {
    present: boolean;
    charging: boolean;
    percent: number | null;
    power_w: number | null;
    voltage_v: number | null;
  };
}

export interface ServerStatus {
  name: string;
  gpuTemp: number;
  gpuUsage: number;
  cpuTemp: number;
  cpuUsage: number;
  ramUsed: number;
  ramTotal: number;
  fps: number;
  uptime: string;
  timestamp: string;
  online?: boolean;
  liveStats?: LiveHardwareStats;
}

export interface PingSample {
  t: number; // epoch ms
  v: number; // ms latency, -1 = loss
}

export interface PingTarget {
  label: string;
  host: string;
  history: PingSample[];
}
