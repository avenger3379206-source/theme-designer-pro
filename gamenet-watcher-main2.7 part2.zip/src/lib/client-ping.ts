// Live per-client ping state.
//
// The ping-agent's /ping endpoint (localhost:8765) is used to probe every VIP
// station's LAN IP. When a known game is running, the VIP-side client agent is
// asked for the active remote game connection and pings that exact remote IP.
// Results are published to window.__exirClientPing
// and dispatched as a CustomEvent so every ClientCard can subscribe without
// prop-drilling (same pattern as CacheActivityPanel).

export interface RegionPing {
  label: string;   // e.g. "UAE", "EU", "RU", "Asia"
  host: string;    // host that was pinged
  ms: number;      // -1 = loss
}

export interface ClientPing {
  machine: string;
  ip: string;
  lanMs: number;        // ping to LAN IP of the client, -1 = loss
  gameName: string | null;   // detected human-readable game name
  gameHost: string | null;   // actual remote IP/host found on the client
  gamePort?: number | null;  // actual remote port when Windows exposes it
  gameMs: number | null;     // ping to gameHost, -1 = loss, null = no game
  regions: RegionPing[];     // per-region pings for the detected game's servers
  history: number[];    // last 20 lan samples for blink/avg (ms, -1 = loss)
  updatedAt: number;
}

export const CLIENT_PING_EVT = "exir:client-ping";

declare global {
  interface Window {
    __exirClientPing?: Record<string, ClientPing>;
  }
}

// ── Game detection ────────────────────────────────────────────────────
// The game endpoint is discovered on the VIP itself. There are NO hard-coded
// websites here: steamcommunity.com/playvalorant.com/etc. are not match servers.
export const GAME_MAP: Record<string, { name: string }> = {
  cs2: { name: "CS2" }, csgo: { name: "CS:GO" }, dota2: { name: "Dota 2" },
  "valorant-win64-shipping": { name: "Valorant" }, valorant: { name: "Valorant" },
  leagueclient: { name: "LoL" }, "league of legends": { name: "LoL" },
  "fortniteclient-win64-shipping": { name: "Fortnite" }, fortnite: { name: "Fortnite" },
  fallguys_client_game: { name: "Fall Guys" }, fallguys: { name: "Fall Guys" },
  r5apex: { name: "Apex" }, apex: { name: "Apex" }, pubg: { name: "PUBG" }, tslgame: { name: "PUBG" },
  modernwarfare: { name: "COD MW" }, cod: { name: "COD" }, gta5: { name: "GTA V" }, gtav: { name: "GTA V" },
  rainbowsix: { name: "R6" }, rocketleague: { name: "Rocket League" }, minecraft: { name: "Minecraft" },
  overwatch: { name: "Overwatch" }, wow: { name: "WoW" },
};

const IGNORE = new Set([
  "explorer", "dwm", "searchhost", "searchapp", "startmenuexperiencehost",
  "shellexperiencehost", "applicationframehost", "runtimebroker", "taskhostw",
  "sihost", "ctfmon", "conhost", "svchost", "services", "lsass", "winlogon",
  "csrss", "smss", "system", "registry", "idle", "steam", "steamwebhelper",
  "discord", "chrome", "firefox", "brave", "msedge", "msedgewebview2",
]);

function prettyName(key: string) {
  return key.replace(/-win64-shipping$/i, "").replace(/[_-]+/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

export function detectGame(topProcess: string): { name: string } | null {
  const key = String(topProcess || "").toLowerCase().replace(/\.exe$/, "").trim();
  if (!key || IGNORE.has(key)) return null;
  if (GAME_MAP[key]) return GAME_MAP[key];
  for (const [k, v] of Object.entries(GAME_MAP)) {
    if (key.includes(k) || k.includes(key)) return v;
  }
  // Unknown foreground applications are allowed. The VIP agent will only
  // return a ping when it can associate a real remote UDP/TCP endpoint with it.
  return { name: prettyName(key) };
}

const AGENT_URL = "http://localhost:8765";

export interface ActualGamePingResult {
  ok: boolean;
  ms: number | null;
  remoteAddress?: string;
  remotePort?: number | null;
  error?: string;
}

/** Pings a list of hosts via the local ping-agent. Returns -1 for loss. */
export async function pingHosts(hosts: string[]): Promise<number[]> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3000);
    const r = await fetch(`${AGENT_URL}/ping`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ hosts }),
      signal: ctrl.signal,
    }).finally(() => clearTimeout(t));
    if (!r.ok) return hosts.map(() => -1);
    const j = (await r.json()) as { results?: number[] };
    return Array.isArray(j.results) ? j.results : hosts.map(() => -1);
  } catch {
    return hosts.map(() => -1);
  }
}

/** Ask the VIP-side client agent for the live game connection and ping it there. */
export async function fetchActualGamePing(host: string, processName: string): Promise<ActualGamePingResult> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3500);
    const r = await fetch(`http://${host}:8766/game/ping`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ processName }),
      signal: ctrl.signal,
    }).finally(() => clearTimeout(t));
    const j = (await r.json().catch(() => ({}))) as ActualGamePingResult;
    return {
      ok: !!j.ok,
      ms: typeof j.ms === "number" ? j.ms : null,
      remoteAddress: j.remoteAddress,
      remotePort: typeof j.remotePort === "number" ? j.remotePort : null,
      error: j.error || (!r.ok ? `client-agent HTTP ${r.status}` : undefined),
    };
  } catch (e) {
    return { ok: false, ms: null, error: `client-agent unreachable: ${(e as Error).message}` };
  }
}


export interface FpsSnapshot {
  ok: boolean;
  fps: number | null;
  processName: string | null;
  pid: number | null;
  source?: string;
  error?: string;
  updatedAt?: string;
}

/** Reads the real frame-present FPS from the VIP-side PresentMon/ETW collector. */
export async function fetchClientFps(host: string): Promise<FpsSnapshot> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 1800);
    const r = await fetch(`http://${host}:8766/fps`, {
      method: "GET",
      signal: ctrl.signal,
    }).finally(() => clearTimeout(t));
    const j = (await r.json().catch(() => ({}))) as Partial<FpsSnapshot>;
    return {
      ok: !!j.ok,
      fps: typeof j.fps === "number" && Number.isFinite(j.fps) ? j.fps : null,
      processName: typeof j.processName === "string" ? j.processName : null,
      pid: typeof j.pid === "number" ? j.pid : null,
      source: typeof j.source === "string" ? j.source : undefined,
      error: typeof j.error === "string" ? j.error : (!r.ok ? `client-agent HTTP ${r.status}` : undefined),
      updatedAt: typeof j.updatedAt === "string" ? j.updatedAt : undefined,
    };
  } catch (e) {
    return {
      ok: false,
      fps: null,
      processName: null,
      pid: null,
      error: `client-agent unreachable: ${(e as Error).message}`,
    };
  }
}

export function publishClientPing(map: Record<string, ClientPing>) {
  if (typeof window === "undefined") return;
  window.__exirClientPing = map;
  window.dispatchEvent(new Event(CLIENT_PING_EVT));
}
