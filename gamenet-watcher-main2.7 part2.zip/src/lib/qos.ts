// QoS state per client + an editable color *range* for the tier slider,
// persisted to localStorage.
import { loadMikrotikConfig } from "./mikrotik-config";

export type Tier =
  | "off"
  | "500K"
  | "1M"
  | "1.5M"
  | "2M"
  | "2.5M"
  | "3M"
  | "3.5M"
  | "4M"
  | "4.5M"
  | "5M"
  | "10M"
  | "20M"
  | "30M"
  | "40M"
  | "50M"
  | "100M"
  | "UNL";

export interface QosState {
  enabled: boolean;
  tier: Tier;
}

// Ordered slowest → fastest, "UNL" (∞) last. This array IS the slider: its
// index is the "tooth" position the drag handle snaps to, so the step
// count and labels everywhere (UI + backend rate table) come from this one
// list — add/remove a tier here and the slider, colors, and pushed value
// all follow automatically.
export const TIER_ORDER: Exclude<Tier, "off">[] = [
  "500K",
  "1M",
  "1.5M",
  "2M",
  "2.5M",
  "3M",
  "3.5M",
  "4M",
  "4.5M",
  "5M",
  "10M",
  "20M",
  "30M",
  "40M",
  "50M",
  "100M",
  "UNL",
];

export const TIER_LABELS: Record<Exclude<Tier, "off">, string> = {
  "500K": "500K",
  "1M": "1M",
  "1.5M": "1.5M",
  "2M": "2M",
  "2.5M": "2.5M",
  "3M": "3M",
  "3.5M": "3.5M",
  "4M": "4M",
  "4.5M": "4.5M",
  "5M": "5M",
  "10M": "10M",
  "20M": "20M",
  "30M": "30M",
  "40M": "40M",
  "50M": "50M",
  "100M": "100M",
  UNL: "∞",
};

const STATE_KEY = "exir.qos.state.v1";
const COLOR_RANGE_KEY = "exir.qos.colorRange.v1";
const BACKEND_KEY = "exir.qos.backend.v1";

export type QosBackend = "mikrotik" | "netlimiter";

export function loadQosBackend(): QosBackend {
  try {
    const v = localStorage.getItem(BACKEND_KEY);
    if (v === "netlimiter" || v === "mikrotik") return v;
  } catch {
    /* ignore */
  }
  return "mikrotik";
}

export function saveQosBackend(b: QosBackend) {
  localStorage.setItem(BACKEND_KEY, b);
  window.dispatchEvent(new Event("exir:qos-backend"));
}

// A "range" instead of one color per tier: pick the color at the slow end
// of the rail, the color at the fast end, and a dedicated color for ∞ —
// every tier in between is interpolated automatically (see getTierColor).
export interface QosColorRange {
  low: string; // color at the "500K" end of the rail
  high: string; // color at the "100M" end of the rail
  unl: string; // dedicated color for the ∞ / unlimited tooth
}

export const DEFAULT_COLOR_RANGE: QosColorRange = {
  low: "#22c55e", // tight limit — green
  high: "#f97316", // high limit — amber
  unl: "#ef4444", // unlimited — red
};

export function loadQosStates(): Record<string, QosState> {
  try {
    const raw = localStorage.getItem(STATE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return {};
}

export function saveQosStates(s: Record<string, QosState>) {
  localStorage.setItem(STATE_KEY, JSON.stringify(s));
}

export function loadQosColorRange(): QosColorRange {
  try {
    const raw = localStorage.getItem(COLOR_RANGE_KEY);
    if (raw) return { ...DEFAULT_COLOR_RANGE, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return DEFAULT_COLOR_RANGE;
}

export function saveQosColorRange(c: QosColorRange) {
  localStorage.setItem(COLOR_RANGE_KEY, JSON.stringify(c));
}

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const full = h.length === 3
    ? h.split("").map((c) => c + c).join("")
    : h.padEnd(6, "0").slice(0, 6);
  const int = parseInt(full, 16) || 0;
  return [(int >> 16) & 255, (int >> 8) & 255, int & 255];
}

function rgbToHex(r: number, g: number, b: number): string {
  return (
    "#" +
    [r, g, b]
      .map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0"))
      .join("")
  );
}

function mixHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  return rgbToHex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t);
}

// Interpolates a color for any tier across the low→high range, so all 17
// tiers share one continuous gradient edited via just two color pickers
// instead of needing one picker per tier.
export function getTierColor(tier: Exclude<Tier, "off">, range: QosColorRange): string {
  if (tier === "UNL") return range.unl;
  const limited = TIER_ORDER.filter((t) => t !== "UNL");
  const idx = limited.indexOf(tier);
  const t = limited.length <= 1 ? 0 : idx / (limited.length - 1);
  return mixHex(range.low, range.high, t);
}

export interface QosPushResult {
  ok: boolean;
  error?: string;
  via?: string; // "client-agent" | "psexec" | mikrotik path, when applicable
}

// Two rapid UI actions on the same machine (e.g. flipping the "enabled"
// checkbox and then immediately dragging the tier slider) previously fired
// two overlapping requests to the same VIP — NetLimiter's optimistic-
// concurrency check would then reject the second UpdateRule with "already
// newer revision of the rule". Serializing per-machine (queueing the next
// push behind the previous one's response) removes the race at the source
// instead of just retrying around it. This also naturally throttles a fast
// slider drag: each tooth crossed queues behind the last, so only the
// latest one lands the moment the agent is free.
const inFlight = new Map<string, Promise<unknown>>();

async function doPushQos(machine: string, state: QosState): Promise<QosPushResult> {
  try {
    const backend = loadQosBackend();
    const r = await fetch("http://localhost:8765/qos", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ machine, backend, ...state, ...loadMikrotikConfig() }),
    });
    const j = (await r.json().catch(() => ({}))) as { ok?: boolean; error?: string; via?: string };
    if (!r.ok || !j.ok) {
      return { ok: false, error: j.error || `agent HTTP ${r.status}` };
    }
    return { ok: true, via: j.via };
  } catch (e) {
    return { ok: false, error: `agent unreachable: ${String((e as Error)?.message || e)}` };
  }
}

// Try to push change to local agent (which will apply via MikroTik REST or
// NetLimiter on the target VIP). Returns the *actual* backend result — the
// HTTP call succeeding just means the agent responded, not that the tier
// was really applied on the client, so callers must check `.ok`.
export async function pushQos(machine: string, state: QosState): Promise<QosPushResult> {
  const prev = inFlight.get(machine) ?? Promise.resolve();
  const chained = prev.catch(() => {}).then(() => doPushQos(machine, state));
  // Store a promise that always settles (never rejects) so later callers'
  // chaining doesn't break if this particular push fails.
  inFlight.set(machine, chained.catch(() => {}));
  return chained;
}
