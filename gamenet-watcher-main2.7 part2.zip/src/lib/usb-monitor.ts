// Live per-client USB device list — polls each VIP's exir-client-agent
// (http://<ip>:8766/usb-devices) and diffs the result against a persisted
// "last seen" baseline per machine, so the dashboard can flag "someone just
// plugged something into USB" (flash drive, phone, unknown dongle, etc.),
// not just the known peripheral types peripheral-monitor.ts already tracks.
//
// Same publish/subscribe shape as peripheral-monitor.ts: results go on
// window.__exirUsbDevices and a CustomEvent fires so the alert engine and
// any panel can react without prop-drilling.

export interface UsbDevice {
  id: string;
  name: string;
  class: string;
}

export interface UsbSnapshot {
  machine: string;
  ok: boolean;
  devices: UsbDevice[];
  newDevices: UsbDevice[]; // present now, weren't in the previous poll's baseline
  error?: string;
  updatedAt: number;
}

export const USB_EVT = "exir:usb-devices";

declare global {
  interface Window {
    __exirUsbDevices?: Record<string, UsbSnapshot>;
  }
}

export function publishUsbDevices(map: Record<string, UsbSnapshot>) {
  if (typeof window === "undefined") return;
  window.__exirUsbDevices = map;
  window.dispatchEvent(new Event(USB_EVT));
}

// ── Persisted "known devices" baseline per machine ─────────────────────
const BASELINE_KEY = "exir.usb.baseline.v1";

function loadBaseline(): Record<string, string[]> {
  try {
    const raw = localStorage.getItem(BASELINE_KEY);
    return raw ? (JSON.parse(raw) as Record<string, string[]>) : {};
  } catch {
    return {};
  }
}

function saveBaseline(b: Record<string, string[]>) {
  try {
    localStorage.setItem(BASELINE_KEY, JSON.stringify(b));
  } catch {
    /* ignore quota errors */
  }
}

/** Forgets what USB devices were "known" for a machine — the next poll's
 * current set becomes the new baseline without flagging anything as new.
 * Useful after intentionally plugging something in permanently. */
export function resetUsbBaseline(machine: string) {
  const b = loadBaseline();
  delete b[machine];
  saveBaseline(b);
}

/** Fetches one client's current USB device list and diffs it against the
 * stored baseline. Never throws — network errors come back as
 * `{ ok: false, error }` so one unreachable station doesn't break polling
 * for everyone else. The very first successful poll for a machine only
 * establishes the baseline (nothing already plugged in counts as "new"). */
export async function fetchUsbDevices(machine: string, host: string, timeoutMs = 6000): Promise<UsbSnapshot> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    const r = await fetch(`http://${host}:8766/usb-devices`, { signal: ctrl.signal }).finally(() =>
      clearTimeout(t),
    );
    const j = (await r.json().catch(() => ({}))) as { ok?: boolean; devices?: UsbDevice[]; error?: string };
    const devices = Array.isArray(j.devices) ? j.devices : [];

    const baseline = loadBaseline();
    const prevIds = baseline[machine];
    let newDevices: UsbDevice[] = [];
    if (prevIds) {
      const prevSet = new Set(prevIds);
      newDevices = devices.filter((d) => !prevSet.has(d.id));
    }
    baseline[machine] = devices.map((d) => d.id);
    saveBaseline(baseline);

    return {
      machine,
      ok: !!j.ok,
      devices,
      newDevices,
      error: j.error || (!r.ok ? `client-agent HTTP ${r.status}` : undefined),
      updatedAt: Date.now(),
    };
  } catch (e) {
    return {
      machine,
      ok: false,
      devices: [],
      newDevices: [],
      error: `client-agent unreachable: ${(e as Error).message}`,
      updatedAt: Date.now(),
    };
  }
}
