// Editable "قالب‌های آماده" (ready-made message templates) for Send Message.
// Persisted to localStorage so operators can add/edit/delete their own
// templates with no fixed limit — this replaces what used to be a hardcoded
// array. Import { MESSAGE_PRESETS } for a synchronous snapshot (kept in sync
// via a tiny pub/sub so components re-render when the list changes), and
// the CRUD helpers below to mutate it.

export interface MessagePreset {
  id: string;
  label: string; // short chip text, e.g. "پایان زمان"
  text: string; // full message body
  countdownOn: boolean;
  countdownMin: number;
  countdownLabel: string;
  autoCloseOn: boolean;
  autoCloseSec: number;
  btn1: string;
  secondBtnOn: boolean;
  btn2: string;
}

const STORAGE_KEY = "exir.message-presets.v1";

const DEFAULT_PRESETS: MessagePreset[] = [
  {
    id: "time-warning",
    label: "پایان زمان",
    text: "زمان شما رو به پایان است. لطفاً برای تمدید به کانتر مراجعه کنید.",
    countdownOn: true,
    countdownMin: 5,
    countdownLabel: "تا خاموش شدن سیستم",
    autoCloseOn: false,
    autoCloseSec: 10,
    btn1: "باشه",
    secondBtnOn: true,
    btn2: "بعداً یادآوری کن",
  },
  {
    id: "rule-warning",
    label: "تذکر قوانین",
    text: "لطفاً قوانین گیم‌نت را رعایت کنید. در صورت تکرار سیستم قفل می‌شود.",
    countdownOn: false,
    countdownMin: 5,
    countdownLabel: "تا خاموش شدن سیستم",
    autoCloseOn: false,
    autoCloseSec: 10,
    btn1: "متوجه شدم",
    secondBtnOn: false,
    btn2: "",
  },
  {
    id: "payment",
    label: "تسویه حساب",
    text: "لطفاً جهت تسویه یا شارژ حساب به کانتر مراجعه کنید.",
    countdownOn: false,
    countdownMin: 5,
    countdownLabel: "تا خاموش شدن سیستم",
    autoCloseOn: false,
    autoCloseSec: 10,
    btn1: "باشه",
    secondBtnOn: false,
    btn2: "",
  },
];

function genId(): string {
  return `p_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

function readRaw(): MessagePreset[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PRESETS.slice();
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.length) return DEFAULT_PRESETS.slice();
    return parsed;
  } catch {
    return DEFAULT_PRESETS.slice();
  }
}

function writeRaw(list: MessagePreset[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    /* ignore quota errors */
  }
}

// Mutable live snapshot + tiny pub/sub so `MESSAGE_PRESETS` can be imported
// directly (matches the old hardcoded-array call sites) while still updating
// when add/update/delete run elsewhere.
export let MESSAGE_PRESETS: MessagePreset[] = readRaw();
const listeners = new Set<() => void>();

function commit(list: MessagePreset[]) {
  MESSAGE_PRESETS = list;
  writeRaw(list);
  listeners.forEach((fn) => fn());
}

/** Subscribe to preset-list changes (e.g. from a React useEffect/useSyncExternalStore). Returns an unsubscribe fn. */
export function subscribePresets(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function addPreset(preset: Omit<MessagePreset, "id">): MessagePreset {
  const withId: MessagePreset = { ...preset, id: genId() };
  commit([...MESSAGE_PRESETS, withId]);
  return withId;
}

export function updatePreset(id: string, patch: Partial<Omit<MessagePreset, "id">>) {
  commit(MESSAGE_PRESETS.map((p) => (p.id === id ? { ...p, ...patch } : p)));
}

export function deletePreset(id: string) {
  commit(MESSAGE_PRESETS.filter((p) => p.id !== id));
}

export function resetPresetsToDefaults() {
  commit(DEFAULT_PRESETS.map((p) => ({ ...p })));
}
