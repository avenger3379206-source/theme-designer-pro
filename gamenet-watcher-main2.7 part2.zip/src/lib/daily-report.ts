// Rolling persisted today-tallies for the daily report. The "day" rolls over
// at 00:00 (midnight) local time, matching the gamenet close/open cycle.
//
// v3: now also tracks per-machine download bytes and per-service (game
// category) bytes — sourced from LanCache access.log via CacheActivityPanel.
// Every parsed line is fed here via `recordBytes(machine, service, bytes)`.
//
// v4: adds LanCache HIT/MISS/OTHER byte totals plus a 15-minute-bucketed
// history of the day, so a bandwidth-savings chart can be drawn without
// re-reading the whole access.log — see `recordCacheBytes` / `computeToday().buckets`.

const TODAY_KEY = "exir.daily.today.v4";
const TODAY_KEY_V3 = "exir.daily.today.v3";
const YESTERDAY_KEY = "exir.daily.snapshot.v2";

export interface MachineBytes { machine: string; down: number; up: number }
export interface CategoryBytes { service: string; down: number }
export interface CacheBucket { bucket: string; hit: number; miss: number; other: number }

export interface DailySnapshot {
  date: string;
  wan1Uptime: number;
  wan2Uptime: number;
  steamDownMinutes: number;
  topConsumer: string;
  perMachine: MachineBytes[];     // sorted desc by down+up
  perCategory: CategoryBytes[];   // sorted desc by down
  totalDown: number;
  totalUp: number;
  hitDown: number;                // bytes served from cache (saved bandwidth)
  missDown: number;                // bytes actually pulled from the internet
  otherDown: number;               // bytes with no clear HIT/MISS status
  savedPct: number;                // hitDown / (hitDown+missDown+otherDown) * 100
  buckets: CacheBucket[];          // chronological, 15-min resolution, today only
}

interface Counters {
  date: string;
  startedAt: number;
  wan1Ok: number; wan1Total: number;
  wan2Ok: number; wan2Total: number;
  steamDown: number;
  perMachine: Record<string, number>;              // usage score
  perMachineDown: Record<string, number>;          // bytes
  perMachineUp: Record<string, number>;            // bytes
  perCategoryDown: Record<string, number>;         // bytes by service
  hitDown: number;
  missDown: number;
  otherDown: number;
  buckets: Record<string, { hit: number; miss: number; other: number }>; // keyed by "HH:MM" (bucket start)
}

function hasStorage() {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

// The rollover must happen at real midnight in Iran, regardless of what
// timezone the PC/server's operating system clock is actually set to.
// Relying on d.getFullYear()/getDate() uses the OS's configured timezone —
// if that machine's clock is set to UTC (very common on servers) or anything
// other than Asia/Tehran, "midnight" in the code fires hours late (or looks
// like it never fires from the user's point of view), which is exactly the
// "still shows yesterday's data" symptom. Intl.DateTimeFormat with an
// explicit timeZone sidesteps the OS setting entirely.
const TEHRAN_TZ = "Asia/Tehran";

function tehranParts(d: Date) {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: TEHRAN_TZ,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const parts = fmt.formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  return {
    year: get("year"),
    month: get("month"),
    day: get("day"),
    hour: Number(get("hour")),
    minute: Number(get("minute")),
    second: Number(get("second")),
  };
}

function businessDate(d = new Date()): string {
  // Rollover is midnight (Iran local time) — the business day is just the
  // Tehran calendar day, computed independent of the OS's own timezone.
  const { year, month, day } = tehranParts(d);
  return `${year}-${month}-${day}`;
}

// Milliseconds remaining until the next real midnight in Tehran.
function msUntilNextTehranMidnight(d = new Date()): number {
  const { hour, minute, second } = tehranParts(d);
  const elapsedMs = (hour * 3600 + minute * 60 + second) * 1000 + d.getMilliseconds();
  return 24 * 60 * 60 * 1000 - elapsedMs;
}

let counters: Counters = fresh();

function fresh(): Counters {
  return {
    date: businessDate(),
    startedAt: Date.now(),
    wan1Ok: 0, wan1Total: 0,
    wan2Ok: 0, wan2Total: 0,
    steamDown: 0,
    perMachine: {},
    perMachineDown: {},
    perMachineUp: {},
    perCategoryDown: {},
    hitDown: 0,
    missDown: 0,
    otherDown: 0,
    buckets: {},
  };
}

// Bucket key for "now", rounded down to the 15-minute grid, e.g. "14:15".
function currentBucketKey(d = new Date()): string {
  const { hour, minute } = tehranParts(d);
  const roundedMin = Math.floor(minute / 15) * 15;
  return `${String(hour).padStart(2, "0")}:${String(roundedMin).padStart(2, "0")}`;
}

function loadCounters(): Counters {
  if (!hasStorage()) return counters;
  try {
    const raw = localStorage.getItem(TODAY_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<Counters>;
      if (parsed.date === businessDate()) {
        counters = {
          date: parsed.date,
          startedAt: Number(parsed.startedAt) || Date.now(),
          wan1Ok: Number(parsed.wan1Ok) || 0,
          wan1Total: Number(parsed.wan1Total) || 0,
          wan2Ok: Number(parsed.wan2Ok) || 0,
          wan2Total: Number(parsed.wan2Total) || 0,
          steamDown: Number(parsed.steamDown) || 0,
          perMachine: obj(parsed.perMachine),
          perMachineDown: obj(parsed.perMachineDown),
          perMachineUp: obj(parsed.perMachineUp),
          perCategoryDown: obj(parsed.perCategoryDown),
          hitDown: Number(parsed.hitDown) || 0,
          missDown: Number(parsed.missDown) || 0,
          otherDown: Number(parsed.otherDown) || 0,
          buckets: bucketsObj(parsed.buckets),
        };
        return counters;
      }
      if (parsed.date) localStorage.setItem(YESTERDAY_KEY, JSON.stringify(snapshotFrom(parsed)));
    } else {
      // No v4 record yet — if today's v3 record exists (pre-upgrade), carry
      // its totals forward instead of silently zeroing today's numbers.
      const rawV3 = localStorage.getItem(TODAY_KEY_V3);
      if (rawV3) {
        const v3 = JSON.parse(rawV3) as Partial<Counters>;
        if (v3.date === businessDate()) {
          counters = {
            date: v3.date,
            startedAt: Number(v3.startedAt) || Date.now(),
            wan1Ok: Number(v3.wan1Ok) || 0,
            wan1Total: Number(v3.wan1Total) || 0,
            wan2Ok: Number(v3.wan2Ok) || 0,
            wan2Total: Number(v3.wan2Total) || 0,
            steamDown: Number(v3.steamDown) || 0,
            perMachine: obj(v3.perMachine),
            perMachineDown: obj(v3.perMachineDown),
            perMachineUp: obj(v3.perMachineUp),
            perCategoryDown: obj(v3.perCategoryDown),
            hitDown: 0,
            missDown: 0,
            otherDown: 0,
            buckets: {},
          };
          saveCounters();
          return counters;
        }
      }
    }
  } catch { /* ignore */ }
  counters = fresh();
  saveCounters();
  return counters;
}

function obj(v: unknown): Record<string, number> {
  return v && typeof v === "object" ? (v as Record<string, number>) : {};
}

function bucketsObj(v: unknown): Record<string, { hit: number; miss: number; other: number }> {
  if (!v || typeof v !== "object") return {};
  const out: Record<string, { hit: number; miss: number; other: number }> = {};
  for (const [k, val] of Object.entries(v as Record<string, unknown>)) {
    const r = val as Partial<{ hit: number; miss: number; other: number }>;
    out[k] = { hit: Number(r?.hit) || 0, miss: Number(r?.miss) || 0, other: Number(r?.other) || 0 };
  }
  return out;
}

function saveCounters() {
  if (!hasStorage()) return;
  try { localStorage.setItem(TODAY_KEY, JSON.stringify(counters)); } catch { /* ignore */ }
}

function ensureToday() {
  const current = loadCounters();
  if (current.date !== businessDate()) rollover();
}

function snapshotFrom(c: Partial<Counters>): DailySnapshot {
  const perMachineScore = obj(c.perMachine);
  const perMachineDown = obj(c.perMachineDown);
  const perMachineUp = obj(c.perMachineUp);
  const perCategoryDown = obj(c.perCategoryDown);

  const topScore = Object.entries(perMachineScore).sort((a, b) => Number(b[1]) - Number(a[1]))[0];
  const topBytes = Object.entries(perMachineDown).sort((a, b) => Number(b[1]) - Number(a[1]))[0];

  const machines = new Set([
    ...Object.keys(perMachineDown),
    ...Object.keys(perMachineUp),
  ]);
  const perMachine: MachineBytes[] = Array.from(machines)
    .map((m) => ({ machine: m, down: perMachineDown[m] || 0, up: perMachineUp[m] || 0 }))
    .sort((a, b) => (b.down + b.up) - (a.down + a.up));

  const perCategory: CategoryBytes[] = Object.entries(perCategoryDown)
    .map(([service, down]) => ({ service, down: Number(down) || 0 }))
    .sort((a, b) => b.down - a.down);

  const hitDown = Number(c.hitDown) || 0;
  const missDown = Number(c.missDown) || 0;
  const otherDown = Number(c.otherDown) || 0;
  const cacheTotal = hitDown + missDown + otherDown;
  const savedPct = cacheTotal ? Math.round((hitDown / cacheTotal) * 100) : 0;

  const buckets: CacheBucket[] = Object.entries(bucketsObj(c.buckets))
    .map(([bucket, v]) => ({ bucket, hit: v.hit, miss: v.miss, other: v.other }))
    .sort((a, b) => a.bucket.localeCompare(b.bucket));

  const wan1Total = Number(c.wan1Total) || 0;
  const wan2Total = Number(c.wan2Total) || 0;
  return {
    date: c.date || businessDate(),
    wan1Uptime: wan1Total ? ((Number(c.wan1Ok) || 0) / wan1Total) * 100 : 0,
    wan2Uptime: wan2Total ? ((Number(c.wan2Ok) || 0) / wan2Total) * 100 : 0,
    steamDownMinutes: Math.round((Number(c.steamDown) || 0) / 60),
    topConsumer: topBytes?.[0] ?? topScore?.[0] ?? "—",
    hitDown,
    missDown,
    otherDown,
    savedPct,
    buckets,
    perMachine,
    perCategory,
    totalDown: perMachine.reduce((s, m) => s + m.down, 0),
    totalUp: perMachine.reduce((s, m) => s + m.up, 0),
  };
}

export function recordPing(target: "wan1" | "wan2", ok: boolean) {
  ensureToday();
  if (target === "wan1") { counters.wan1Total++; if (ok) counters.wan1Ok++; }
  else { counters.wan2Total++; if (ok) counters.wan2Ok++; }
  saveCounters();
}

export function recordSteamDown(seconds: number) {
  ensureToday();
  counters.steamDown += seconds;
  saveCounters();
}

export function recordUsage(machine: string, score: number) {
  ensureToday();
  counters.perMachine[machine] = (counters.perMachine[machine] || 0) + score;
  saveCounters();
}

// New: called by CacheActivityPanel for every parsed access.log line.
// direction defaults to "down" (LanCache logs downloads to clients).
export function recordBytes(machine: string, service: string, bytes: number, direction: "down" | "up" = "down") {
  if (!machine || !bytes || bytes <= 0) return;
  ensureToday();
  const svc = (service || "other").toLowerCase();
  if (direction === "down") {
    counters.perMachineDown[machine] = (counters.perMachineDown[machine] || 0) + bytes;
    counters.perCategoryDown[svc] = (counters.perCategoryDown[svc] || 0) + bytes;
  } else {
    counters.perMachineUp[machine] = (counters.perMachineUp[machine] || 0) + bytes;
  }
  saveCounters();
}

// New: called once per CacheActivityPanel poll tick with that tick's
// aggregated HIT/MISS/OTHER byte deltas (not per log line — the panel
// already sums these per tick, so we just fold the sums in here).
export function recordCacheBytes(hitBytes: number, missBytes: number, otherBytes: number) {
  if (!hitBytes && !missBytes && !otherBytes) return;
  ensureToday();
  counters.hitDown += hitBytes;
  counters.missDown += missBytes;
  counters.otherDown += otherBytes;
  const key = currentBucketKey();
  const b = counters.buckets[key] || (counters.buckets[key] = { hit: 0, miss: 0, other: 0 });
  b.hit += hitBytes;
  b.miss += missBytes;
  b.other += otherBytes;
  saveCounters();
}

export function computeToday(): DailySnapshot {
  ensureToday();
  return snapshotFrom(counters);
}

export function loadYesterday(): DailySnapshot | null {
  try {
    const raw = localStorage.getItem(YESTERDAY_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

export function rollover() {
  const snap = snapshotFrom(counters);
  if (hasStorage()) localStorage.setItem(YESTERDAY_KEY, JSON.stringify(snap));
  counters = fresh();
  saveCounters();
}

// Format bytes as human string.
export function fmtBytes(n: number): string {
  if (!n || n < 1024) return `${n | 0} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

// Schedule a rollover for the next real midnight in Tehran, then every 24h after.
export function startDailyScheduler() {
  ensureToday();
  const delay = msUntilNextTehranMidnight();
  setTimeout(() => {
    rollover();
    setInterval(rollover, 24 * 60 * 60 * 1000);
  }, delay);
}
