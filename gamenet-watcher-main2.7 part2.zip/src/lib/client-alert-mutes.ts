// Per-client notification mutes — lets you silence a specific alert type
// (overheat, offline, peripheral, disk health) for just ONE client station,
// without turning it off everywhere via the global Alerts settings. Handy
// for a station you already know is being worked on, or one with a known
// quirk you don't want to keep hearing about.
//
// Separate from alert-settings.ts (global on/off per condition, applies to
// every client) — this is a second, per-machine filter layered on top. An
// alert only fires when BOTH the global condition is enabled AND the
// specific client isn't muted for that condition.

export type MutableAlertKind =
  | "overheat"
  | "offline"
  | "diskHealth"
  | "keyboard"
  | "mouse"
  | "monitor"
  | "headset"
  | "controller"
  | "usb";

export const MUTABLE_ALERT_KINDS: { key: MutableAlertKind; label: string }[] = [
  { key: "overheat", label: "دمای بحرانی GPU/CPU" },
  { key: "offline", label: "آفلاین شدن" },
  { key: "diskHealth", label: "سلامت دیسک" },
  { key: "keyboard", label: "قطع کیبورد" },
  { key: "mouse", label: "قطع ماوس" },
  { key: "monitor", label: "قطع مانیتور" },
  { key: "headset", label: "قطع هدست" },
  { key: "controller", label: "قطع دسته" },
  { key: "usb", label: "اتصال USB جدید" },
];

const KEY = "exir.client-alert-mutes.v1";
export const CLIENT_ALERT_MUTES_EVT = "exir:client-alert-mutes";

export type ClientMuteMap = Record<string, MutableAlertKind[]>;

export function loadClientAlertMutes(): ClientMuteMap {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") return parsed as ClientMuteMap;
  } catch {
    /* ignore */
  }
  return {};
}

function saveClientAlertMutes(map: ClientMuteMap) {
  try {
    localStorage.setItem(KEY, JSON.stringify(map));
    window.dispatchEvent(new Event(CLIENT_ALERT_MUTES_EVT));
  } catch {
    /* ignore quota errors */
  }
}

export function isClientAlertMuted(machine: string, kind: MutableAlertKind): boolean {
  const map = loadClientAlertMutes();
  return (map[machine] || []).includes(kind);
}

export function toggleClientAlertMute(machine: string, kind: MutableAlertKind): ClientMuteMap {
  const map = loadClientAlertMutes();
  const current = map[machine] || [];
  const next = current.includes(kind) ? current.filter((k) => k !== kind) : [...current, kind];
  const nextMap: ClientMuteMap = { ...map, [machine]: next };
  if (next.length === 0) delete nextMap[machine];
  saveClientAlertMutes(nextMap);
  return nextMap;
}
