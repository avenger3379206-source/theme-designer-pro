// ─────────────────────────────────────────────────────────────────────────
// Phase 7 — Per-client "what ran, for how long" log.
//
// One row per distinct process for the whole online session — NOT one row
// per time it happened to be in the foreground. Alt-tabbing back and forth
// to Steam/Discord/a launcher a dozen times while playing a game should
// still show a single "steam" row with its total accumulated time, the
// same way it used to before this log started tracking every individual
// foreground switch.
//
// Every dashboard tick (see routes/index.tsx) calls recordTick(clients) with
// the freshest ClientStatus[]. We diff each client's `topProcess` against
// what we saw last tick:
//   - process changed → only commits (stops the old row's timer, starts/
//     resumes the new row's timer) once the new process has held the
//     foreground for at least DEBOUNCE_MS straight — a momentary flicker
//     (Steam overlay/update toast, a launcher splash, a notification
//     stealing focus) is folded back into whatever was already running
//     instead of creating noise
//   - same process reappears later → resumes the SAME row (adds to its
//     total) instead of creating a duplicate
//   - client went offline → the whole log for that machine is wiped
//     (per the requirement: stats must zero out the moment a station drops)
//   - client came back online → starts a brand-new, empty log
//
// This is intentionally a live/session log, not a permanent database: it
// lives in memory + localStorage (survives an accidental page refresh, but
// not an offline blip), matching the "reset when offline" requirement.
// ─────────────────────────────────────────────────────────────────────────

import type { ClientStatus } from "./monitoring-types";

export interface ProcessLogEntry {
  process: string;
  startedAt: number; // first time this process was ever seen this session
  endedAt: number | null; // last time it left the foreground; null while it's currently running
  totalMs: number; // accumulated foreground time from completed segments (add live delta below if running now)
  runningSince: number | null; // when the CURRENT foreground segment began, or null if not running now
}

const EVT = "exir:process-history";
const KEY = (machine: string) => `exir.process-history.${machine}`;
const STATE_KEY = (machine: string) => `exir.process-history-state.${machine}`;

// A process must hold the foreground for at least this long before we
// commit a switch. Anything shorter (a Steam overlay/update toast, a
// launcher splash, a notification stealing focus for a couple seconds) is
// treated as noise and folded back into whatever was already running.
const DEBOUNCE_MS = 5000;

const store: Record<string, ProcessLogEntry[]> = {};
const lastState: Record<
  string,
  { online: boolean; process: string; pendingProcess: string; pendingSince: number }
> = {};

// Values that mean "nothing meaningful running" — never logged as a row.
const IGNORE = new Set(["", "-", "—", "idle", "none", "explorer.exe", "explorer"]);

function normalize(p: string | undefined): string {
  const v = (p || "").trim();
  return IGNORE.has(v.toLowerCase()) ? "" : v;
}

function load(machine: string): ProcessLogEntry[] {
  if (store[machine]) return store[machine];
  try {
    const raw = localStorage.getItem(KEY(machine));
    const parsed = raw ? (JSON.parse(raw) as unknown[]) : [];
    // Guard against a stale/older-schema cache (missing totalMs/runningSince)
    // — loading those as-is produced `undefined` arithmetic → NaN durations,
    // and `undefined !== null` made every row look like it was running.
    const valid =
      Array.isArray(parsed) &&
      parsed.every(
        (e): e is ProcessLogEntry =>
          !!e &&
          typeof e === "object" &&
          typeof (e as ProcessLogEntry).process === "string" &&
          typeof (e as ProcessLogEntry).totalMs === "number" &&
          ("runningSince" in (e as object)),
      );
    store[machine] = valid ? (parsed as ProcessLogEntry[]) : [];
  } catch {
    store[machine] = [];
  }
  return store[machine];
}

function persist(machine: string) {
  try {
    localStorage.setItem(KEY(machine), JSON.stringify(store[machine] || []));
  } catch {
    /* ignore quota errors */
  }
  try {
    window.dispatchEvent(new CustomEvent(EVT, { detail: { machine } }));
  } catch {
    /* ignore (non-browser context) */
  }
}

/** Reads the last-known online/process state for a machine, falling back to
 * localStorage on the first call after a fresh page load. Without this, a
 * plain page refresh (e.g. leaving and returning from the shop) would look
 * identical to "client just came online" and wipe the log every time. */
function readLastState(
  machine: string,
): { online: boolean; process: string; pendingProcess: string; pendingSince: number } | undefined {
  if (lastState[machine]) return lastState[machine];
  try {
    const raw = localStorage.getItem(STATE_KEY(machine));
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<{
        online: boolean;
        process: string;
        pendingProcess: string;
        pendingSince: number;
      }>;
      lastState[machine] = {
        online: parsed.online ?? false,
        process: parsed.process ?? "",
        pendingProcess: parsed.pendingProcess ?? "",
        pendingSince: parsed.pendingSince ?? 0,
      };
      return lastState[machine];
    }
  } catch {
    /* ignore */
  }
  return undefined;
}

function writeLastState(
  machine: string,
  state: { online: boolean; process: string; pendingProcess: string; pendingSince: number },
) {
  lastState[machine] = state;
  try {
    localStorage.setItem(STATE_KEY(machine), JSON.stringify(state));
  } catch {
    /* ignore quota errors */
  }
}

/** Stops the currently-running segment of `process`'s row (if any),
 * folding the elapsed time into totalMs. */
function stopRow(list: ProcessLogEntry[], process: string, at: number) {
  if (!process) return;
  const row = list.find((e) => e.process === process);
  if (row && row.runningSince !== null) {
    row.totalMs += Math.max(0, at - row.runningSince);
    row.runningSince = null;
    row.endedAt = at;
  }
}

/** Starts (or resumes) `process`'s row at time `at`. */
function startRow(list: ProcessLogEntry[], process: string, at: number) {
  if (!process) return;
  const row = list.find((e) => e.process === process);
  if (row) {
    row.runningSince = at;
    row.endedAt = null;
  } else {
    list.push({ process, startedAt: at, endedAt: null, totalMs: 0, runningSince: at });
  }
}

/** Call once per poll tick with the latest client list (mock or live). */
export function recordTick(clients: ClientStatus[]): void {
  const now = Date.now();
  for (const c of clients) {
    const machine = c.machine;
    const online = c.online !== false;
    const prev = readLastState(machine);
    const list = load(machine);

    if (!online) {
      // Reset the log the moment a station drops offline — but only do the
      // (relatively expensive) clear+persist once, not on every tick while
      // it stays offline.
      if (!prev || prev.online !== false) {
        store[machine] = [];
        writeLastState(machine, { online: false, process: "", pendingProcess: "", pendingSince: 0 });
        persist(machine);
      }
      continue;
    }

    const proc = normalize(c.topProcess);

    if (!prev || prev.online === false) {
      // First tick ever for this machine, or genuinely went offline→online
      // — start a clean log immediately (no debounce on session start).
      store[machine] = [];
      startRow(store[machine], proc, now);
      writeLastState(machine, { online: true, process: proc, pendingProcess: "", pendingSince: 0 });
      persist(machine);
      continue;
    }

    if (proc === prev.process) {
      // Back to (or still) whatever's already the committed/running
      // process — cancel any pending switch, nothing to log.
      if (prev.pendingProcess) {
        writeLastState(machine, { ...prev, pendingProcess: "", pendingSince: 0 });
      }
      continue;
    }

    if (proc !== prev.pendingProcess) {
      // A different candidate than what we were already timing — restart
      // the debounce window for this new candidate.
      writeLastState(machine, { ...prev, pendingProcess: proc, pendingSince: now });
      continue;
    }

    // Same candidate as last tick — check if it's held long enough to commit.
    if (now - prev.pendingSince < DEBOUNCE_MS) continue;

    stopRow(list, prev.process, now);
    startRow(list, proc, now);
    writeLastState(machine, { online: true, process: proc, pendingProcess: "", pendingSince: 0 });
    persist(machine);
  }
}

/** Newest-first (by first appearance) list of everything logged for this
 * machine since it last came online — one row per distinct process. */
export function getHistory(machine: string): ProcessLogEntry[] {
  return load(machine).slice().reverse();
}

/** Fires cb() whenever this machine's log changes (new entry / reset). */
export function subscribeProcessHistory(machine: string, cb: () => void): () => void {
  const h = (e: Event) => {
    const detail = (e as CustomEvent<{ machine: string }>).detail;
    if (detail?.machine === machine) cb();
  };
  window.addEventListener(EVT, h);
  return () => window.removeEventListener(EVT, h);
}

/** Total time spent per process (currently-running row counts up to "now"), sorted by most time spent. */
export function totalsByProcess(machine: string): { process: string; ms: number }[] {
  const now = Date.now();
  return load(machine)
    .map((e) => ({ process: e.process, ms: e.totalMs + (e.runningSince !== null ? now - e.runningSince : 0) }))
    .sort((a, b) => b.ms - a.ms);
}
