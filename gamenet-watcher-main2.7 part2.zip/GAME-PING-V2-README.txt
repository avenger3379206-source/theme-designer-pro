Game Ping v2
============

Replace the files while preserving their paths:

- exir-client-agent.mjs
- src/lib/client-ping.ts
- src/components/monitoring/ClientPingProbe.tsx
- src/components/monitoring/ClientCard.tsx

Important:
- The dashboard no longer displays the client's LAN 1ms as the game ping.
- It no longer uses hard-coded websites such as steamcommunity.com as a fake game server.
- Unknown foreground processes are allowed dynamically.
- If Windows does not expose a remote endpoint for a UDP game (CS2 commonly does
  this), the UI shows "—" rather than a fake 1ms or LOSS.

For a true UDP in-game RTT such as CS2, the next layer is packet/ETW capture
(or a game-provided telemetry source) because Get-NetUDPEndpoint/netstat do not
expose the remote endpoint for an unconnected UDP socket.
