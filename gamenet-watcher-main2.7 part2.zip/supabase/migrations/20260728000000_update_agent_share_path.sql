/*
# Update default agent share path

The client agents now write their status JSON files into an `Info`
subfolder of the share (\\192.168.3.100\GameNet-Monitor\status\Info)
instead of directly into \\192.168.3.100\GameNet-Monitor\status.
Update the column default so any new agent_settings rows pick up the
new path, and backfill existing rows that still have the old default.
*/

ALTER TABLE agent_settings
  ALTER COLUMN server_share_path
  SET DEFAULT '\\192.168.3.100\GameNet-Monitor\status\Info';

UPDATE agent_settings
SET server_share_path = '\\192.168.3.100\GameNet-Monitor\status\Info'
WHERE server_share_path = '\\192.168.3.100\GameNet-Monitor\status';
