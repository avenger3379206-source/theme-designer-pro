/*
# Create client live stats tables (single-tenant, no auth)

1. New Tables
- `clients`: registry of monitored client stations (name, group, online status).
- `client_stats`: latest live hardware stats per client (CPU/GPU/RAM/disk/network/fans/temps).
  Uses a `client_name` unique key so the agent can upsert its latest snapshot.
- `agent_settings`: per-client agent configuration (refresh interval, enabled metrics,
  server share path, etc.) editable from the dashboard Settings panel.

2. Security
- Enable RLS on all tables.
- Single-tenant / no-auth app: allow anon + authenticated full CRUD on all tables
  because the data is intentionally shared across the LAN monitoring dashboard.
*/

CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  group_name text,
  is_online boolean NOT NULL DEFAULT false,
  last_seen timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS client_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text NOT NULL UNIQUE REFERENCES clients(name) ON DELETE CASCADE,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text NOT NULL UNIQUE REFERENCES clients(name) ON DELETE CASCADE,
  refresh_ms integer NOT NULL DEFAULT 1000,
  enabled_metrics jsonb NOT NULL DEFAULT '["cpu","gpu","ram","disk","network","motherboard","battery","fans"]'::jsonb,
  server_share_path text NOT NULL DEFAULT '\\\\192.168.3.100\\GameNet-Monitor\\status',
  use_winring0 boolean NOT NULL DEFAULT true,
  upload_to_supabase boolean NOT NULL DEFAULT true,
  save_local_json boolean NOT NULL DEFAULT true,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_clients" ON clients;
CREATE POLICY "anon_select_clients" ON clients FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_clients" ON clients;
CREATE POLICY "anon_insert_clients" ON clients FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_clients" ON clients;
CREATE POLICY "anon_update_clients" ON clients FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_clients" ON clients;
CREATE POLICY "anon_delete_clients" ON clients FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_client_stats" ON client_stats;
CREATE POLICY "anon_select_client_stats" ON client_stats FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_client_stats" ON client_stats;
CREATE POLICY "anon_insert_client_stats" ON client_stats FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_client_stats" ON client_stats;
CREATE POLICY "anon_update_client_stats" ON client_stats FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_client_stats" ON client_stats;
CREATE POLICY "anon_delete_client_stats" ON client_stats FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_agent_settings" ON agent_settings;
CREATE POLICY "anon_select_agent_settings" ON agent_settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_agent_settings" ON agent_settings;
CREATE POLICY "anon_insert_agent_settings" ON agent_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_agent_settings" ON agent_settings;
CREATE POLICY "anon_update_agent_settings" ON agent_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_agent_settings" ON agent_settings;
CREATE POLICY "anon_delete_agent_settings" ON agent_settings FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_client_stats_updated ON client_stats(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_clients_online ON clients(is_online);
