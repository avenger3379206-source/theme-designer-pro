// ─────────────────────────────────────────────────────────────────────────
// Exir Client Agent — runs on EACH VIP client PC (not the operator).
// Purpose: replace PsExec / WMIC entirely.
//
// The operator's ping-agent (on the server) posts JSON to
//   http://<client-ip>:8766/message   → shows a message window locally
//   http://<client-ip>:8766/punish    → same, with kbd lock + Alt+F4 block
//   http://<client-ip>:8766/netlimiter/apply → set/re-apply NetLimiter tier
//                                               body: { tier, bytes }
//   http://<client-ip>:8766/peripherals → GET, { keyboard, mouse, headset,
//                                               controller, monitorCount }
//   http://<client-ip>:8766/disk-health → GET, { disks: [{ name, health,
//                                               wearPercent, temperature, ... }] }
//   http://<client-ip>:8766/health    → { ok:true, machine, version }
//
// Everything runs in the interactive user session because the agent itself
// runs there (see install-service.ps1: uses "Run at logon" scheduled task,
// NOT a session-0 service). No PsExec, no SMB shares, no admin creds.
// Zero npm dependencies — just Node.js 18+.
//
// This is now the PREFERRED path for every QoS change (ping-agent.mjs tries
// this first, and only falls back to PsExec + netlimiter-qos.ps1 over SMB if
// this agent is unreachable). Since this agent already runs locally on the
// VIP, applying QoS through it never touches SMB at all, so it can't collide
// with SmartLaunch's or UVNC's own SMB sessions to the same host — that
// collision (Windows error 5 "Access is denied" / 1219 "Multiple
// connections...") was the actual cause of QoS silently failing to apply
// while UVNC/SmartLaunch held a session open.
// ─────────────────────────────────────────────────────────────────────────

import { createServer } from "node:http";
import { execFile, spawn } from "node:child_process";
import { writeFileSync, mkdirSync, existsSync } from "node:fs";
import { tmpdir, hostname } from "node:os";
import { join, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";

const VERSION = "1.10.0";
const PORT = Number(process.env.EXIR_CLIENT_PORT || 8766);
const MACHINE = (process.env.EXIR_MACHINE_ID || hostname()).toUpperCase();
// NOTE: nlq.exe does NOT exist in NetLimiter 4.1.13 (it was a CLI tool from
// older NetLimiter versions — see ping-agent.mjs comments). The working
// approach talks to NetLimiter.dll directly via .NET reflection, which is
// what netlimiter-qos.ps1 (deployed on every VIP by Setup-NetLimiter-VIP.ps1)
// already does. This agent just runs that same script locally — since this
// agent runs IN the interactive user session already, no PsExec/SMB call is
// needed at all, which is exactly what sidesteps the SmartLaunch/UVNC SMB
// session conflicts.
const NETLIMITER_QOS_SCRIPT = process.env.NETLIMITER_QOS_SCRIPT ||
  "C:\\GameNet-Monitor\\netlimiter-qos.ps1";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Exir-Filename",
};

const TMP = join(tmpdir(), "exir-agent");
try { mkdirSync(TMP, { recursive: true }); } catch { /* ignore */ }

function pingOne(host) {
  return new Promise((resolve) => {
    if (!/^[a-zA-Z0-9._-]+$/.test(host)) return resolve(-1);
    execFile("ping", ["-n", "1", "-w", "1500", host], { timeout: 2200, windowsHide: true }, (err, stdout) => {
      if (err && !stdout) return resolve(-1);
      const text = String(stdout || "");
      let m = text.match(/time[=<]\s*([\d.]+)\s*ms/i);
      if (!m) m = text.match(/Average\s*=\s*([\d.]+)\s*ms/i);
      resolve(m ? Math.round(parseFloat(m[1])) : -1);
    });
  });
}

function readBody(req, limit = 4_000_000) {
  return new Promise((resolve, reject) => {
    let b = "";
    req.on("data", (c) => {
      b += c;
      if (b.length > limit) { req.destroy(); reject(new Error("payload too large")); }
    });
    req.on("end", () => resolve(b));
    req.on("error", reject);
  });
}

// Same as readBody but returns a raw Buffer instead of string-concatenating
// chunks (which corrupts binary data like video/image bytes via implicit
// utf8 decoding). Used for the /message/video upload below.
function readBodyBuffer(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) { req.destroy(); reject(new Error("payload too large")); return; }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function json(res, status, obj) {
  res.writeHead(status, { ...CORS, "Content-Type": "application/json" });
  res.end(JSON.stringify(obj));
}

function normalizeProcName(s) {
  return String(s || "").toLowerCase().replace(/\.exe$/, "").trim();
}

const AGENT_DIR = dirname(fileURLToPath(import.meta.url));
const GAME_PING_DIR = process.env.EXIR_GAME_PING_DIR || join(AGENT_DIR, "tools", "game-ping");
const FLOW_WATCHER = process.env.EXIR_GAME_FLOW_WATCHER || join(GAME_PING_DIR, "windivert-flow-watcher.ps1");
const FPS_DIR = process.env.EXIR_FPS_DIR || join(AGENT_DIR, "tools", "fps");
const PRESENTMON_EXE = process.env.EXIR_PRESENTMON_EXE || join(FPS_DIR, "PresentMon.exe");
const FPS_IGNORE = new Set([
  "explorer", "dwm", "searchhost", "searchapp", "startmenuexperiencehost",
  "shellexperiencehost", "applicationframehost", "runtimebroker", "taskhostw",
  "sihost", "ctfmon", "conhost", "svchost", "services", "lsass", "winlogon",
  "csrss", "smss", "system", "registry", "idle", "steam", "steamwebhelper",
  "discord", "chrome", "firefox", "brave", "msedge", "msedgewebview2",
  "code", "powershell", "pwsh", "node", "cmd", "searchprotocolhost",
]);
const FLOW_CACHE_TTL_MS = 30_000;
const flowCache = new Map();
let flowWatcher = null;
let flowWatcherRestart = null;

function rememberGameFlow(evt) {
  if (!evt?.ok || !evt.processName || !evt.remoteAddress) return;
  const key = normalizeProcName(evt.processName);
  const now = Date.now();
  const list = flowCache.get(key) || [];
  const next = [
    { remoteAddress: evt.remoteAddress, remotePort: Number(evt.remotePort) || 0, localPort: Number(evt.localPort) || 0, seenAt: now },
    ...list.filter((x) => !(x.remoteAddress === evt.remoteAddress && x.remotePort === Number(evt.remotePort))),
  ].slice(0, 12);
  flowCache.set(key, next);
}

function startGameFlowWatcher() {
  if (flowWatcher || !existsSync(FLOW_WATCHER)) return;
  try {
    flowWatcher = spawn("powershell", [
      "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", FLOW_WATCHER,
    ], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    let buffer = "";
    flowWatcher.stdout.setEncoding("utf8");
    flowWatcher.stderr.setEncoding("utf8");
    flowWatcher.stderr.on("data", (chunk) => {
      const msg = String(chunk || "").trim();
      if (msg) console.warn(`[GamePing] ${msg}`);
    });
    flowWatcher.stdout.on("data", (chunk) => {
      buffer += chunk;
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";
      for (const line of lines) {
        const t = line.trim();
        if (!t) continue;
        try { rememberGameFlow(JSON.parse(t)); } catch { /* ignore non-JSON diagnostics */ }
      }
    });
    flowWatcher.on("exit", () => {
      flowWatcher = null;
      clearTimeout(flowWatcherRestart);
      flowWatcherRestart = setTimeout(startGameFlowWatcher, 5000);
    });
  } catch {
    flowWatcher = null;
  }
}

function getCachedGameRemote(processName) {
  const key = normalizeProcName(processName);
  const list = (flowCache.get(key) || []).filter((x) => Date.now() - x.seenAt <= FLOW_CACHE_TTL_MS);
  flowCache.set(key, list);
  const servicePorts = new Set([53, 67, 68, 80, 123, 443, 500, 3478, 3479, 3480, 4500, 5353, 5355]);
  return list.filter((x) => x.remoteAddress && !servicePorts.has(Number(x.remotePort)))
    .sort((a, b) => (b.seenAt || 0) - (a.seenAt || 0))[0] || null;
}


// ── Real FPS capture (PresentMon / Windows ETW) ───────────────────────────
// PresentMon counts actual frame-present events from Windows ETW. Nothing is
// injected into the game and no game-specific whitelist is required.
// Install tools/fps/PresentMon.exe once on the client with Install-FpsMonitor.ps1.
let fpsMonitor = null;
let fpsRestartTimer = null;

// ── Foreground-window watcher (persistent, event-driven) ──────────────────
// The previous version spawned a brand new `powershell.exe` and re-compiled
// an inline C# type (Add-Type) on *every* poll — both the process spawn and
// the C# compile are slow (often 1-3s+), and this was called every 500ms by
// the background loop AND again on every /fps request from the dashboard.
// That's why FPS never showed up: the dashboard's fetch has a 1.8s timeout
// (see fetchClientFps in client-ping.ts) and the lookup routinely took
// longer than that, so every request just came back empty.
//
// Fix: compile the C# type ONCE in a single long-lived PowerShell process
// (same pattern as startGameFlowWatcher() above) that prints one JSON line
// per foreground-window *change*. Node just keeps the latest line in memory
// — reading it back out (fpsSnapshot / the /fps route) is instant.
let foregroundWatcher = null;
let foregroundWatcherRestart = null;
let currentForeground = { ok: false };

const FOREGROUND_WATCHER_SCRIPT = `
try {
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class ExirFg {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
}
"@
} catch {
  [Console]::Error.WriteLine("ADD-TYPE-FAILED: " + $_.Exception.Message)
  exit 1
}
$writer = [Console]::Out
$lastPid = -1
while ($true) {
  try {
    $hwnd = [ExirFg]::GetForegroundWindow()
    [uint32]$fgPid = 0
    if ($hwnd -ne [IntPtr]::Zero) { [void][ExirFg]::GetWindowThreadProcessId($hwnd, [ref]$fgPid) }
    if ($fgPid -gt 0 -and $fgPid -ne $lastPid) {
      $lastPid = $fgPid
      $p = Get-Process -Id $fgPid -ErrorAction SilentlyContinue
      if ($p) {
        $json = [PSCustomObject]@{ ok = $true; pid = [int]$p.Id; processName = $p.ProcessName } | ConvertTo-Json -Compress
        $writer.WriteLine($json)
        $writer.Flush()
      }
    } elseif ($fgPid -eq 0 -and $lastPid -ne 0) {
      $lastPid = 0
      $writer.WriteLine('{"ok":false}')
      $writer.Flush()
    }
  } catch {
    [Console]::Error.WriteLine("LOOP-ERROR: " + $_.Exception.Message)
  }
  Start-Sleep -Milliseconds 400
}
`.trim();

// Writing this to a real .ps1 file and running it with -File (instead of
// stuffing the whole quote-heavy script into a single -Command argument) is
// the same pattern startGameFlowWatcher() above already uses successfully.
// A -Command string this size, full of embedded double-quotes (the Add-Type
// heredoc, the P/Invoke string literals), is a known way for Windows'
// command-line argument quoting to silently mangle the script — which
// matches exactly what we saw: no crash, no stderr, just zero output ever.
const FOREGROUND_WATCHER_PS1 = join(tmpdir(), "exir-fg-watcher.ps1");

function onForegroundChange(evt) {
  currentForeground = evt && typeof evt === "object" ? evt : { ok: false };
  if (currentForeground.ok && currentForeground.pid && currentForeground.processName) {
    console.log(`[FPS] foreground -> ${currentForeground.processName} (pid ${currentForeground.pid})`);
    startFpsMonitor({ ok: true, pid: currentForeground.pid, processName: currentForeground.processName });
  } else {
    stopFpsMonitor();
  }
}

function startForegroundWatcher() {
  if (foregroundWatcher) return;
  try {
    writeFileSync(FOREGROUND_WATCHER_PS1, FOREGROUND_WATCHER_SCRIPT, "utf8");
    foregroundWatcher = spawn("powershell", [
      "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", FOREGROUND_WATCHER_PS1,
    ], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    console.log(`[FPS] foreground watcher started (pid ${foregroundWatcher.pid}, script ${FOREGROUND_WATCHER_PS1})`);
    let buffer = "";
    foregroundWatcher.stdout.setEncoding("utf8");
    foregroundWatcher.stderr.setEncoding("utf8");
    foregroundWatcher.stderr.on("data", (chunk) => {
      const msg = String(chunk || "").trim();
      if (msg) console.warn(`[FPS-fg] ${msg}`);
    });
    foregroundWatcher.stdout.on("data", (chunk) => {
      buffer += chunk;
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || "";
      for (const line of lines) {
        const t = line.trim();
        if (!t) continue;
        try { onForegroundChange(JSON.parse(t)); } catch { /* ignore stray/non-JSON output */ }
      }
    });
    foregroundWatcher.on("exit", (code) => {
      console.warn(`[FPS] foreground watcher exited (code ${code}) — restarting in 3s`);
      foregroundWatcher = null;
      clearTimeout(foregroundWatcherRestart);
      foregroundWatcherRestart = setTimeout(startForegroundWatcher, 3000);
    });
  } catch (e) {
    console.warn(`[FPS] foreground watcher failed to start: ${e?.message || e}`);
    foregroundWatcher = null;
  }
}

function stopFpsMonitor() {
  if (fpsMonitor?.proc) {
    try { fpsMonitor.proc.kill(); } catch {}
  }
  fpsMonitor = null;
  if (fpsRestartTimer) {
    clearTimeout(fpsRestartTimer);
    fpsRestartTimer = null;
  }
}

function startFpsMonitor(target) {
  if (!existsSync(PRESENTMON_EXE)) {
    console.warn(`[FPS] PresentMon.exe not found at ${PRESENTMON_EXE} — run Install-FpsMonitor.ps1`);
    stopFpsMonitor();
    return;
  }
  if (!target?.ok || !target.pid || !target.processName) {
    stopFpsMonitor();
    return;
  }
  const name = normalizeProcName(target.processName);
  if (!name || FPS_IGNORE.has(name)) {
    console.log(`[FPS] ignoring "${target.processName}" (shell/system/browser process)`);
    stopFpsMonitor();
    return;
  }
  if (fpsMonitor?.pid === Number(target.pid) && fpsMonitor?.proc && !fpsMonitor.proc.killed) return;

  stopFpsMonitor();
  try {
    console.log(`[FPS] starting PresentMon for ${target.processName} (pid ${target.pid})`);
    const child = spawn(PRESENTMON_EXE, [
      "--process_id", String(target.pid),
      "--output_stdout",
      "--no_console_stats",
      "--no_track_gpu",
      "--no_track_input",
      "--no_track_display",
      "--qpc_time",
      "--stop_existing_session",
      "--terminate_on_proc_exit",
    ], { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });

    const state = {
      proc: child,
      pid: Number(target.pid),
      processName: target.processName,
      frames: [],
      fps: 0,
      lastFrameAt: 0,
      buffer: "",
      sawAnyOutput: false,
    };
    fpsMonitor = state;
    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk) => {
      state.sawAnyOutput = true;
      state.buffer += String(chunk || "");
      const rows = state.buffer.split(/\r?\n/);
      state.buffer = rows.pop() || "";
      const now = Date.now();
      let frameCount = 0;
      for (const row of rows) {
        const line = row.trim();
        if (!line || line.startsWith("Application,") || line.startsWith("Error")) continue;
        if (line.includes(",")) {
          state.frames.push(now);
          state.lastFrameAt = now;
          frameCount++;
        }
      }
      if (frameCount) {
        const cutoff = now - 2000;
        state.frames = state.frames.filter((t) => t >= cutoff);
        const oneSec = state.frames.filter((t) => t >= now - 1000).length;
        state.fps = Math.round(oneSec);
      }
    });
    child.stderr.setEncoding("utf8");
    child.stderr.on("data", (chunk) => {
      const msg = String(chunk || "").trim();
      if (msg) console.warn(`[FPS] PresentMon stderr: ${msg.slice(0, 300)}`);
    });
    child.on("exit", (code) => {
      if (!state.sawAnyOutput) {
        console.warn(`[FPS] PresentMon exited (code ${code}) for pid ${target.pid} without producing any CSV rows — it likely never started capturing (needs Administrator, or this app doesn't present frames via DXGI/D3D).`);
      } else {
        console.warn(`[FPS] PresentMon exited (code ${code}) for pid ${target.pid}`);
      }
      if (fpsMonitor?.proc === child) {
        fpsMonitor = null;
        if (target.pid) {
          clearTimeout(fpsRestartTimer);
          fpsRestartTimer = setTimeout(() => startFpsMonitor(target), 800);
        }
      }
    });
  } catch (e) {
    console.warn(`[FPS] PresentMon start failed: ${e?.message || e}`);
    stopFpsMonitor();
  }
}

// Synchronous — just reads the state the watcher/PresentMon already
// maintain in memory, so /fps responds instantly instead of waiting on a
// fresh PowerShell spawn.
function fpsSnapshot() {
  if (!existsSync(PRESENTMON_EXE)) {
    return {
      ok: false,
      fps: null,
      processName: null,
      pid: null,
      source: "presentmon-missing",
      error: "PresentMon.exe not installed",
    };
  }

  const fg = currentForeground;
  if (!fg?.ok || !fg.pid || !fg.processName) {
    return { ok: true, fps: null, processName: null, pid: null, source: "presentmon" };
  }

  const name = normalizeProcName(fg.processName);
  if (FPS_IGNORE.has(name)) {
    return { ok: true, fps: null, processName: null, pid: null, source: "presentmon" };
  }

  const state = fpsMonitor;
  const now = Date.now();
  if (!state || state.pid !== Number(fg.pid)) {
    return { ok: true, fps: null, processName: fg.processName, pid: Number(fg.pid), source: "presentmon" };
  }

  // If no presents arrived for 1.5s, don't show a stale FPS value.
  const fps = state.lastFrameAt && now - state.lastFrameAt <= 1500 ? Math.max(0, Math.round(state.fps)) : null;
  return {
    ok: true,
    fps,
    processName: fg.processName,
    pid: Number(fg.pid),
    source: "presentmon",
    updatedAt: new Date().toISOString(),
  };
}

// The watcher is cheap (one persistent process, event-driven) so it's
// always started — it only matters once PresentMon.exe is also installed,
// but starting it early means FPS capture kicks in immediately the moment
// PresentMon.exe shows up without needing to restart the agent again.
console.log(existsSync(PRESENTMON_EXE)
  ? `[FPS] PresentMon.exe found at ${PRESENTMON_EXE}`
  : `[FPS] PresentMon.exe NOT found at ${PRESENTMON_EXE} — run tools\\fps\\Install-FpsMonitor.ps1 as Administrator`);
startForegroundWatcher();

function findGameRemote(processName) {
  const cached = getCachedGameRemote(processName);
  if (cached) return Promise.resolve({ ok: true, ...cached, source: "windivert-flow" });
  return findTcpRemote(processName);
}

function findTcpRemote(processName) {
  const wanted = normalizeProcName(processName);
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
$wanted = '${wanted.replace(/'/g, "''")}'
$pids = @(Get-Process | Where-Object { $_.ProcessName.ToLower() -eq $wanted -or $_.ProcessName.ToLower().Contains($wanted) -or $wanted.Contains($_.ProcessName.ToLower()) } | ForEach-Object { [int]$_.Id })
if (-not $pids -or $pids.Count -eq 0) { '{"ok":false,"error":"process not found"}'; exit }
$private = '^(127\\.|0\\.|10\\.|192\\.168\\.|169\\.254\\.|172\\.(1[6-9]|2[0-9]|3[0-1])\\.|::1|::|fe80:)'
$rows = @()
foreach ($line in (netstat -ano)) {
  $cols = $line.Trim() -split '\\s+'
  if ($cols.Count -lt 5) { continue }
  if ($cols[0] -ne 'TCP' -or $cols[3] -ne 'ESTABLISHED') { continue }
  $remote = $cols[2]; $pid = [int]($cols[4] -as [int])
  if ($pids -notcontains $pid) { continue }
  if (-not $remote -or $remote -match ':0$') { continue }
  if ($remote -match '^\\[(.+)\\]:(\\d+)$') { $addr=$Matches[1]; $port=[int]$Matches[2] } elseif ($remote -match '^(.+):(\\d+)$') { $addr=$Matches[1]; $port=[int]$Matches[2] } else { continue }
  if ($addr -match $private) { continue }
  if (@(80,443,53,88,123,389,445,500,3478,3479,3480,4500,1900,5353,5355,67,68) -contains $port) { continue }
  $rows += [PSCustomObject]@{ proto='tcp'; remoteAddress=$addr; remotePort=$port; pid=$pid }
}
$pick = $rows | Sort-Object @{Expression='remotePort';Descending=$true} | Select-Object -First 1
if ($pick) { $pick | Add-Member -NotePropertyName ok -NotePropertyValue $true -Force; $pick | ConvertTo-Json -Compress } else { '{"ok":false,"error":"no remote game connection"}' }
`.trim();
  return new Promise((resolve) => {
    execFile("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], { timeout: 5000, windowsHide: true }, (err, stdout, stderr) => {
      const jsonLine = String(stdout || "").split(/\r?\n/).map((l) => l.trim()).find((l) => l.startsWith("{") && l.endsWith("}"));
      if (jsonLine) { try { return resolve(JSON.parse(jsonLine)); } catch {} }
      resolve({ ok: false, error: (stderr || err?.message || "no remote connection").toString().slice(0, 300) });
    });
  });
}

async function gamePing(processName) {
  const remote = await findGameRemote(processName);
  if (!remote.ok || !remote.remoteAddress) {
    return { ok: false, ms: null, error: remote.error || "real game endpoint not found" };
  }
  const ms = await pingOne(remote.remoteAddress);
  return {
    ok: ms >= 0,
    ms: ms >= 0 ? ms : null,
    remoteAddress: remote.remoteAddress,
    remotePort: remote.remotePort || null,
    source: remote.source || "tcp-fallback",
    error: ms >= 0 ? undefined : "game endpoint does not answer ICMP",
  };
}

startGameFlowWatcher();

// ── Local popup launcher (uses mshta.exe, always available on Windows) ──
//
// mshta.exe opens a perfectly normal top-level window — Windows gives it no
// special z-order priority, so if the customer is in a fullscreen/borderless
// game or any other app, the popup can silently open *behind* it. The
// customer never sees it, and staff have no idea the message didn't land.
// Fix: right after spawning mshta, run a short-lived, fire-and-forget
// PowerShell snippet (same Add-Type/P-Invoke pattern netlimiter-qos.ps1
// already uses) that finds the new window by PID and forces it topmost +
// foreground. It re-asserts a few times over ~2s in case a game/app fights
// back for focus immediately after opening (some do).
function forceTopmostAndFocus(pid) {
  const script = `
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class ExirWin {
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
}
"@
$HWND_TOPMOST = [IntPtr](-1)
$SWP_NOMOVE = 0x2; $SWP_NOSIZE = 0x1; $SWP_SHOWWINDOW = 0x40
$SW_RESTORE = 9
$deadline = (Get-Date).AddSeconds(5)
$hwnd = [IntPtr]::Zero
while ((Get-Date) -lt $deadline -and $hwnd -eq [IntPtr]::Zero) {
  Start-Sleep -Milliseconds 120
  try {
    $p = Get-Process -Id ${pid} -ErrorAction SilentlyContinue
    if ($p -and $p.MainWindowHandle -ne [IntPtr]::Zero) { $hwnd = $p.MainWindowHandle }
  } catch {}
}
if ($hwnd -ne [IntPtr]::Zero) {
  for ($i = 0; $i -lt 6; $i++) {
    [ExirWin]::ShowWindow($hwnd, $SW_RESTORE) | Out-Null
    [ExirWin]::SetWindowPos($hwnd, $HWND_TOPMOST, 0, 0, 0, 0, ($SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_SHOWWINDOW)) | Out-Null
    [ExirWin]::BringWindowToTop($hwnd) | Out-Null
    [ExirWin]::SetForegroundWindow($hwnd) | Out-Null
    Start-Sleep -Milliseconds 350
  }
}
`.trim();
  // Fire-and-forget: detached + unref'd, exactly like the mshta launch
  // itself — the HTTP response to the dashboard doesn't wait on this.
  const child = spawn(
    "powershell",
    ["-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-Command", script],
    { detached: true, stdio: "ignore", windowsHide: true },
  );
  child.on("error", (e) => console.error("[exir-agent] topmost helper failed:", e.message));
  child.unref();
}

function launchHta(html, { punish = false } = {}) {
  const fname = `exir_${punish ? "punish" : "msg"}_${Date.now()}.hta`;
  const path = join(TMP, fname);
  // If punish, inject a small kill-guard <script> so Alt+F4 / Esc close is
  // blocked for the countdown duration — the HTML template already does this
  // for punish payloads; we don't need to modify it here.
  writeFileSync(path, html, "utf8");
  const child = spawn("mshta.exe", [path], {
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.on("error", (e) => console.error("[exir-agent] mshta launch failed:", e.message));
  child.unref();
  if (child.pid) forceTopmostAndFocus(child.pid);
  return { path };
}

// ── NetLimiter re-apply (called after UVNC/SmartLaunch drops the rule state,
// or directly by the server as the PREFERRED path for every QoS change) ──
//
// Runs netlimiter-qos.ps1 locally (no PsExec, no SMB — this agent already
// lives in the interactive session on the VIP). $Bytes is computed centrally
// by ping-agent.mjs (QOS_TIER_KBYTES in .env) and just passed straight
// through, same contract as the PsExec fallback path.
function runQosScript(tier, bytes) {
  return new Promise((resolve) => {
    const args = [
      "-ExecutionPolicy", "Bypass",
      "-File", NETLIMITER_QOS_SCRIPT,
      "-Tier", tier,
      ...(bytes > 0 ? ["-Bytes", String(bytes)] : []),
    ];
    execFile("powershell", args, { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
      // netlimiter-qos.ps1 prints exactly one JSON line on stdout.
      const text = String(stdout || "");
      const jsonLine = text
        .split(/\r?\n/)
        .map((l) => l.trim())
        .find((l) => l.startsWith("{") && l.endsWith("}"));
      if (jsonLine) {
        try { return resolve(JSON.parse(jsonLine)); } catch { /* fall through */ }
      }
      resolve({
        ok: false,
        error: (stderr || err?.message || "no JSON output from netlimiter-qos.ps1").toString().slice(0, 300),
      });
    });
  });
}

async function applyNetLimiter(tier, bytes) {
  const t = tier && tier !== "off" ? tier : "UNL";
  const b = Number(bytes) || 0;
  const r = await runQosScript(t, b);
  return {
    ok: !!r.ok,
    tier: t,
    ...(r.ok
      ? { limitBytesPerSec: r.limitBytesPerSec ?? (t !== "UNL" ? b : "unlimited") }
      : { error: r.error || "unknown error" }),
  };
}

// ── Network tools (Phase 6) ───────────────────────────────────────────────
// All of these run locally on the VIP under the interactive user session, no
// PsExec / SMB needed. The agent runs from a Scheduled Task at logon, but the
// network commands themselves (ipconfig /flushdns, netsh interface ip set,
// registry writes to WinINET) need admin. Install the scheduled task with
// "Run with highest privileges" (install-service.ps1 sets that flag) — then
// these all work without any UAC prompt.

function runPs(script, timeout = 12000) {
  return new Promise((resolve) => {
    execFile(
      "powershell",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
      { timeout, windowsHide: true },
      (err, stdout, stderr) => {
        if (err) {
          resolve({ ok: false, error: (stderr || err.message || "").toString().slice(0, 400) });
        } else {
          resolve({ ok: true, output: String(stdout || "").slice(0, 800) });
        }
      },
    );
  });
}

function flushDns() {
  return new Promise((resolve) => {
    execFile("ipconfig", ["/flushdns"], { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
      if (err) return resolve({ ok: false, error: (stderr || err.message || "").toString().slice(0, 300) });
      resolve({ ok: true, output: String(stdout || "").slice(0, 400) });
    });
  });
}

function disableProxy() {
  // Clears WinINET (IE/Edge/most apps) proxy state. DOES NOT touch DNS or IP.
  const script = [
    "$k='HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings';",
    "Set-ItemProperty -Path $k -Name ProxyEnable -Value 0 -Type DWord -Force;",
    "Remove-ItemProperty -Path $k -Name ProxyServer -ErrorAction SilentlyContinue;",
    "Remove-ItemProperty -Path $k -Name AutoConfigURL -ErrorAction SilentlyContinue;",
    "Remove-ItemProperty -Path $k -Name ProxyOverride -ErrorAction SilentlyContinue;",
    // Also clear WinHTTP (background services). Requires admin — Scheduled Task
    // runs with highest privileges so this succeeds.
    "netsh winhttp reset proxy | Out-Null;",
    "'ok'",
  ].join(" ");
  return runPs(script);
}

// Picks the primary Ethernet/Wi-Fi adapter (the one with a default gateway).
// Returns its InterfaceAlias — that's what `netsh interface ip set` needs.
async function primaryAdapter() {
  const r = await runPs(
    "(Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -ne $null } | Select-Object -First 1 -ExpandProperty InterfaceAlias)",
    6000,
  );
  return r.ok ? (r.output || "").trim() : "";
}

async function setIp({ ip, mask, gateway, dns1, dns2, adapter }) {
  const iface = (adapter && String(adapter).trim()) || (await primaryAdapter());
  if (!iface) return { ok: false, error: "could not detect network adapter" };
  const prefix = maskToPrefix(mask) || 24;
  // Reset then set — same pattern netsh docs recommend.
  const parts = [
    `netsh interface ipv4 set address name="${iface}" source=static addr=${ip} mask=${mask} gateway=${gateway} | Out-Null`,
    `netsh interface ipv4 set dnsservers name="${iface}" source=static addr=${dns1} register=primary validate=no | Out-Null`,
  ];
  if (dns2) parts.push(`netsh interface ipv4 add dnsservers name="${iface}" addr=${dns2} index=2 validate=no | Out-Null`);
  parts.push(`'ok · ${iface} · ${ip}/${prefix} gw=${gateway} dns=${dns1}${dns2 ? "," + dns2 : ""}'`);
  return runPs(parts.join("; "), 15000);
}

function maskToPrefix(mask) {
  if (!mask) return null;
  return String(mask).split(".").reduce((a, b) => a + ((Number(b) >>> 0).toString(2).match(/1/g)?.length || 0), 0);
}

// Reads the client's actual, currently-configured IPv4 settings straight
// from the OS. This backs the dashboard's "ip settings" box (live/green vs
// last-saved/yellow) — that UI already existed and expects this exact
// contract ({ ok, ip, mask, gateway, dns1, dns2 }); this route was simply
// never implemented on the agent, so every request 404'd and the dashboard
// always fell back to showing the last-saved value.
function getNetInfo() {
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
function PrefixToMask($p) {
  if (-not $p) { return '' }
  $bits = ('1' * [int]$p).PadRight(32,'0')
  $bytes = @()
  for ($i = 0; $i -lt 4; $i++) { $bytes += [Convert]::ToInt32($bits.Substring($i * 8, 8), 2) }
  return ($bytes -join '.')
}
$cfgs = @(Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway })
if (-not $cfgs -or $cfgs.Count -eq 0) { $cfgs = @(Get-NetIPConfiguration | Where-Object { $_.IPv4Address }) }
$c = $cfgs | Select-Object -First 1
if (-not $c) { '{"ok":false,"error":"no active IPv4 adapter found"}'; exit }
$ipObj = $c.IPv4Address | Select-Object -First 1
$ip = $ipObj.IPAddress
$mask = PrefixToMask $ipObj.PrefixLength
$gwObj = $c.IPv4DefaultGateway | Select-Object -First 1
$gateway = if ($gwObj) { $gwObj.NextHop } else { '' }
$dnsAddrs = @($c.DNSServer | Where-Object { $_.AddressFamily -eq 2 } | Select-Object -ExpandProperty ServerAddresses)
$dns1 = if ($dnsAddrs.Count -ge 1) { $dnsAddrs[0] } else { '' }
$dns2 = if ($dnsAddrs.Count -ge 2) { $dnsAddrs[1] } else { '' }
$out = [PSCustomObject]@{ ok = $true; ip = $ip; mask = $mask; gateway = $gateway; dns1 = $dns1; dns2 = $dns2; adapter = $c.InterfaceAlias }
$out | ConvertTo-Json -Compress
`.trim();
  return new Promise((resolve) => {
    execFile("powershell", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], { timeout: 8000, windowsHide: true }, (err, stdout, stderr) => {
      const jsonLine = String(stdout || "").split(/\r?\n/).map((l) => l.trim()).find((l) => l.startsWith("{") && l.endsWith("}"));
      if (jsonLine) {
        try {
          const parsed = JSON.parse(jsonLine);
          return resolve({ ok: !!parsed.ok, ip: parsed.ip || "", mask: parsed.mask || "", gateway: parsed.gateway || "", dns1: parsed.dns1 || "", dns2: parsed.dns2 || "", error: parsed.error });
        } catch { /* fall through */ }
      }
      resolve({ ok: false, ip: "", mask: "", gateway: "", dns1: "", dns2: "", error: (stderr || err?.message || "no output from Get-NetIPConfiguration").toString().slice(0, 300) });
    });
  });
}

// ── Peripheral disconnect detection (Phase 7) ─────────────────────────────
// Detects whether a station's keyboard, mouse, headset/audio, controller,
// and monitor are actually present RIGHT NOW — separate from MSI Afterburner
// (which only reports GPU/CPU sensors, nothing about peripherals or the
// display signal). Runs a single PowerShell query on request; the dashboard
// polls this every ~20-30s per client (see src/lib/peripheral-monitor.ts).
//
// Notes on reliability, so nobody's surprised later:
//  - keyboard: read from Get-PnpDevice, so this reflects what Windows
//    currently sees enumerated — a real unplug (or a dead USB port)
//    reliably flips this to false within a couple seconds.
//  - mouse: PREVIOUSLY only matched Get-PnpDevice friendly names containing
//    the literal word "mouse" — missed plenty of real mice branded things
//    like "HID-compliant mouse" in other languages, or gaming mice whose
//    PnP name is just the model number. Now backed primarily by
//    Win32_PointingDevice (a CIM class Windows populates for ANY detected
//    pointing device regardless of name/brand), with the old name-matched
//    HIDClass check kept as a secondary OR so nothing that used to work
//    stops working.
//  - headset: PREVIOUSLY only matched PnP AudioEndpoint friendly names
//    containing "headset"/"headphone"/"earphone" — missed most real-world
//    USB headsets, since gaming headset brands (HyperX, Razer, Logitech G,
//    Redragon, Corsair HS, etc.) don't put any of those words in their PnP
//    name; they show up as e.g. "HyperX Cloud II" or plain "USB Audio
//    Device". Now backed primarily by Win32_SoundDevice filtered to
//    PNPDeviceID starting with "USB" — this reliably flags ANY USB audio
//    hardware present and enabled, independent of brand/model naming, which
//    is what actually distinguishes "a USB headset is plugged in" from
//    onboard/HDAUDIO speakers. The old name-matched check is kept as a
//    secondary OR. Analog (3.5mm) headsets on onboard audio still won't be
//    detected unless the motherboard exposes jack-sense — a missing reading
//    means "no USB headset found", not "definitely unplugged" for
//    analog-only setups.
//  - monitorCount: WmiMonitorBasicDisplayParams (root\wmi) only lists
//    displays currently receiving a live EDID signal, so cable-unplugged /
//    powered-off monitors drop out of this list reliably. Compare against
//    however many monitors that station is supposed to have (usually 1).
function checkPeripherals() {
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
function AnyPresent($class, $pattern) {
  $devs = @(Get-PnpDevice -Class $class -PresentOnly -ErrorAction SilentlyContinue)
  if ($pattern) { $devs = @($devs | Where-Object { $_.FriendlyName -match $pattern }) }
  return ($devs | Where-Object { $_.Status -eq 'OK' }).Count -gt 0
}
$keyboard = AnyPresent 'Keyboard' $null

$mouse = $false
try {
  $pointing = @(Get-CimInstance -ClassName Win32_PointingDevice -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'OK' -or [string]::IsNullOrEmpty($_.Status) })
  $mouse = $pointing.Count -gt 0
} catch { $mouse = $false }
if (-not $mouse) { $mouse = AnyPresent 'Mouse' $null }
if (-not $mouse) { $mouse = AnyPresent 'HIDClass' '(?i)mouse' }

$headset = $false
try {
  $usbAudio = @(Get-CimInstance -ClassName Win32_SoundDevice -ErrorAction SilentlyContinue | Where-Object { $_.PNPDeviceID -match '^USB' -and ($_.Status -eq 'OK' -or [string]::IsNullOrEmpty($_.Status)) })
  $headset = $usbAudio.Count -gt 0
} catch { $headset = $false }
if (-not $headset) { $headset = AnyPresent 'AudioEndpoint' '(?i)headset|headphone|earphone|usb audio|usb sound' }
$controller = AnyPresent 'HIDClass' '(?i)xbox|controller|gamepad|dualshock|dualsense|joystick'
if (-not $controller) { $controller = AnyPresent 'XnaComposite' $null }
try {
  $monitors = @(Get-CimInstance -Namespace root\\wmi -ClassName WmiMonitorBasicDisplayParams -ErrorAction SilentlyContinue)
  $monitorCount = $monitors.Count
} catch { $monitorCount = -1 }
$out = [PSCustomObject]@{
  ok = $true
  keyboard = $keyboard
  mouse = $mouse
  headset = $headset
  controller = $controller
  monitorCount = $monitorCount
}
$out | ConvertTo-Json -Compress
`.trim();
  return new Promise((resolve) => {
    execFile(
      "powershell",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
      { timeout: 8000, windowsHide: true },
      (err, stdout, stderr) => {
        const jsonLine = String(stdout || "")
          .split(/\r?\n/)
          .map((l) => l.trim())
          .find((l) => l.startsWith("{") && l.endsWith("}"));
        if (jsonLine) {
          try {
            const p = JSON.parse(jsonLine);
            return resolve({
              ok: true,
              keyboard: !!p.keyboard,
              mouse: !!p.mouse,
              headset: !!p.headset,
              controller: !!p.controller,
              monitorCount: typeof p.monitorCount === "number" ? p.monitorCount : -1,
              checkedAt: new Date().toISOString(),
            });
          } catch { /* fall through */ }
        }
        resolve({
          ok: false,
          error: (stderr || err?.message || "no output from Get-PnpDevice").toString().slice(0, 300),
          checkedAt: new Date().toISOString(),
        });
      },
    );
  });
}

// ── USB device enumeration (Phase 9) ──────────────────────────────────────
// Lists every USB-attached PnP device Windows currently sees present — not
// just the known peripheral types (keyboard/mouse/headset/controller)
// checkPeripherals() already tracks, but ANYTHING on a USB port: flash
// drives, phones, external HDDs, unknown dongles, etc. The dashboard polls
// this and diffs against what it saw last time (per client, in
// localStorage) to flag "a new USB device just showed up" — deliberately
// snapshot-only here; no baseline/diffing state lives on the client agent
// itself, so restarting this agent never loses or resets alarm state.
function checkUsbDevices() {
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
$devs = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -like 'USB\\*' -and $_.Status -eq 'OK' })
$list = @($devs | ForEach-Object { [PSCustomObject]@{ id = $_.InstanceId; name = $_.FriendlyName; class = $_.Class } })
$out = [PSCustomObject]@{ ok = $true; devices = $list; count = $list.Count }
$out | ConvertTo-Json -Compress -Depth 4
`.trim();
  return new Promise((resolve) => {
    execFile(
      "powershell",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
      { timeout: 8000, windowsHide: true },
      (err, stdout, stderr) => {
        const jsonLine = String(stdout || "")
          .split(/\r?\n/)
          .map((l) => l.trim())
          .find((l) => l.startsWith("{") && l.endsWith("}"));
        if (jsonLine) {
          try {
            const p = JSON.parse(jsonLine);
            // PowerShell 5.1's ConvertTo-Json collapses a 1-element array to
            // a bare object — normalize back to an array either way.
            const rawDevices = p.devices;
            const devices = Array.isArray(rawDevices) ? rawDevices : rawDevices ? [rawDevices] : [];
            return resolve({
              ok: true,
              devices: devices
                .filter((d) => d && typeof d === "object")
                .map((d) => ({
                  id: String(d.id || ""),
                  name: String(d.name || "Unknown USB device"),
                  class: String(d.class || ""),
                })),
              checkedAt: new Date().toISOString(),
            });
          } catch { /* fall through */ }
        }
        resolve({
          ok: false,
          error: (stderr || err?.message || "no output from Get-PnpDevice").toString().slice(0, 300),
          checkedAt: new Date().toISOString(),
        });
      },
    );
  });
}

// ── Disk health / SMART (Phase 8) ─────────────────────────────────────────
// Uses Get-PhysicalDisk (Windows Storage Management, built in since Win8/
// Server 2012 — no extra software) for the OS's own SMART-derived
// HealthStatus, plus Get-StorageReliabilityCounter for temperature, wear
// level, and uncorrected read errors where the drive/controller exposes them.
//
// Deliberately NOT included: fan RPM and PSU readouts. There's no universal
// Windows API for either — real values require a vendor-specific tool per
// motherboard (which is exactly why GPU/CPU temps here come from MSI
// Afterburner instead of us reinventing that). Faking those numbers would be
// worse than not showing them.
function checkDiskHealth() {
  const script = `
$ErrorActionPreference = 'SilentlyContinue'
$disks = @(Get-PhysicalDisk -ErrorAction SilentlyContinue | ForEach-Object {
  $d = $_
  $rel = $d | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
  [PSCustomObject]@{
    name = $d.FriendlyName
    health = $d.HealthStatus.ToString()
    operational = ($d.OperationalStatus -join ',')
    mediaType = $d.MediaType.ToString()
    sizeGB = [math]::Round($d.Size/1GB,1)
    temperature = if ($rel.Temperature) { $rel.Temperature } else { $null }
    wearPercent = if ($null -ne $rel.Wear) { $rel.Wear } else { $null }
    readErrorsUncorrected = if ($null -ne $rel.ReadErrorsUncorrected) { $rel.ReadErrorsUncorrected } else { $null }
    powerOnHours = if ($rel.PowerOnHours) { $rel.PowerOnHours } else { $null }
  }
})
$out = [PSCustomObject]@{ ok = $true; disks = $disks }
$out | ConvertTo-Json -Compress -Depth 4
`.trim();
  return new Promise((resolve) => {
    execFile(
      "powershell",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
      { timeout: 10000, windowsHide: true },
      (err, stdout, stderr) => {
        const jsonLine = String(stdout || "")
          .split(/\r?\n/)
          .map((l) => l.trim())
          .find((l) => l.startsWith("{") && l.endsWith("}"));
        if (jsonLine) {
          try {
            const p = JSON.parse(jsonLine);
            let disks = Array.isArray(p.disks) ? p.disks : p.disks ? [p.disks] : [];
            disks = disks.map((d) => ({
              name: d.name || "Disk",
              health: d.health || "Unknown",
              operational: d.operational || "",
              mediaType: d.mediaType || "Unknown",
              sizeGB: typeof d.sizeGB === "number" ? d.sizeGB : null,
              temperature: typeof d.temperature === "number" ? d.temperature : null,
              wearPercent: typeof d.wearPercent === "number" ? d.wearPercent : null,
              readErrorsUncorrected:
                typeof d.readErrorsUncorrected === "number" ? d.readErrorsUncorrected : null,
              powerOnHours: typeof d.powerOnHours === "number" ? d.powerOnHours : null,
            }));
            return resolve({ ok: true, disks, checkedAt: new Date().toISOString() });
          } catch { /* fall through */ }
        }
        resolve({
          ok: false,
          disks: [],
          error: (stderr || err?.message || "no output from Get-PhysicalDisk").toString().slice(0, 300),
          checkedAt: new Date().toISOString(),
        });
      },
    );
  });
}

// ── Server ──────────────────────────────────────────────────────────────
const server = createServer(async (req, res) => {
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }

  try {
    if (req.method === "GET" && (req.url === "/" || req.url === "/health")) {
      return json(res, 200, { ok: true, agent: "exir-client", machine: MACHINE, version: VERSION });
    }

    if (req.method === "POST" && (req.url === "/message" || req.url === "/punish")) {
      const body = await readBody(req, 40_000_000); // was 4MB — a logo + Vazirmatn fonts alone can pass that
      const { html } = JSON.parse(body || "{}");
      if (!html || typeof html !== "string") return json(res, 400, { ok: false, error: "html required" });
      const { path } = launchHta(html, { punish: req.url === "/punish" });
      return json(res, 200, { ok: true, note: `mshta local (${MACHINE})`, path });
    }

    if (req.method === "POST" && req.url === "/message/video") {
      const MAX_VIDEO_BYTES = 300 * 1024 * 1024; // 300MB, matches the dashboard's client-side check
      let buf;
      try {
        buf = await readBodyBuffer(req, MAX_VIDEO_BYTES);
      } catch (e) {
        return json(res, 413, { ok: false, error: `video too large (max 300MB): ${e.message}` });
      }
      if (!buf.length) return json(res, 400, { ok: false, error: "empty video body" });
      const rawName = String(req.headers["x-exir-filename"] || "video.mp4");
      const ext = (extname(rawName) || ".mp4").toLowerCase().replace(/[^a-z0-9.]/g, "") || ".mp4";
      if (!existsSync(TMP)) mkdirSync(TMP, { recursive: true });
      const fname = `exir_video_${Date.now()}${ext}`;
      const fullPath = join(TMP, fname);
      try {
        writeFileSync(fullPath, buf);
      } catch (e) {
        return json(res, 500, { ok: false, error: `write failed: ${e.message}` });
      }
      // file:// URL for use as a <video src> inside the .hta — forward
      // slashes + the file:/// prefix are required, backslashes are not.
      const fileUrl = "file:///" + fullPath.replace(/\\/g, "/");
      return json(res, 200, { ok: true, path: fullPath, url: fileUrl, bytes: buf.length });
    }

    if (req.method === "POST" && req.url === "/netlimiter/apply") {
      const body = await readBody(req);
      // tier: "500K" | "1M" | "2M" | "UNL" | null. bytes: precomputed B/s for
      // the tier (ignored for UNL) — server centralizes the tier→bytes table.
      const { tier, bytes } = JSON.parse(body || "{}");
      const r = await applyNetLimiter(tier, bytes);
      return json(res, 200, r);
    }

    if (req.method === "GET" && req.url === "/fps") {
      return json(res, 200, await fpsSnapshot());
    }

    if (req.method === "GET" && req.url.startsWith("/game/flows")) {
      const u = new URL(req.url, `http://${req.headers.host || "localhost"}`);
      const processName = u.searchParams.get("processName") || "";
      return json(res, 200, { ok: true, processName, flows: flowCache.get(normalizeProcName(processName)) || [] });
    }

    if (req.method === "POST" && req.url === "/game/ping") {
      const body = await readBody(req, 20_000);
      const { processName } = JSON.parse(body || "{}");
      return json(res, 200, await gamePing(processName || ""));
    }

    // ── Phase 6 network tools ──────────────────────────────────────────
    if (req.method === "POST" && req.url === "/net/flush-dns") {
      return json(res, 200, await flushDns());
    }
    if (req.method === "POST" && req.url === "/net/disable-proxy") {
      return json(res, 200, await disableProxy());
    }
    if (req.method === "POST" && req.url === "/net/set-ip") {
      const body = await readBody(req);
      const p = JSON.parse(body || "{}");
      if (!p.ip || !p.mask || !p.gateway || !p.dns1) {
        return json(res, 400, { ok: false, error: "ip, mask, gateway, dns1 required" });
      }
      return json(res, 200, await setIp(p));
    }
    if (req.method === "GET" && req.url === "/net/info") {
      return json(res, 200, await getNetInfo());
    }

    // ── Phase 7 peripheral check ────────────────────────────────────────
    if (req.method === "GET" && req.url === "/peripherals") {
      return json(res, 200, await checkPeripherals());
    }

    // ── Phase 8 disk health / SMART ──────────────────────────────────────
    if (req.method === "GET" && req.url === "/disk-health") {
      return json(res, 200, await checkDiskHealth());
    }

    // ── Phase 9 USB device list ───────────────────────────────────────────
    if (req.method === "GET" && req.url === "/usb-devices") {
      return json(res, 200, await checkUsbDevices());
    }

    json(res, 404, { ok: false, error: "not found" });
  } catch (e) {
    json(res, 500, { ok: false, error: String(e?.message || e) });
  }
});

server.requestTimeout = 15 * 60 * 1000; // 15min — enough for a 300MB video on a slow LAN
server.listen(PORT, "0.0.0.0", () => {
  console.log(`[exir-client-agent] v${VERSION} · ${MACHINE} · listening on 0.0.0.0:${PORT}`);
});
