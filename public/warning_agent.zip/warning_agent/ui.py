import os

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap, QFont
from PySide6.QtWidgets import (
    QWidget,
    QLabel,
    QFrame,
    QVBoxLayout,
    QProgressBar,
)


class WarningWindow(QWidget):

    def __init__(self, reason, seconds):
        super().__init__()

        self.seconds = seconds

        self.setWindowFlags(
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint |
            Qt.Tool
        )

        self.showFullScreen()

        self.background = QLabel(self)
        self.background.setGeometry(self.rect())

        path = os.path.join(
            os.path.dirname(__file__),
            "assets",
            "background.png"
        )

        pix = QPixmap(path)

        if not pix.isNull():
            self.background.setPixmap(pix)

        self.background.setScaledContents(True)
        self.background.lower()

        self.panel = QFrame(self)
        self.panel.resize(760, 430)

        self.panel.setStyleSheet("""
        QFrame{
            background-color:rgba(25,25,35,220);
            border:2px solid #3FA9F5;
            border-radius:25px;
        }
        """)

        layout = QVBoxLayout(self.panel)
        layout.setContentsMargins(
            40,
            40,
            40,
            40
        )
        layout.setSpacing(20)
        layout.setAlignment(Qt.AlignCenter)

        self.icon = QLabel("🚨")
        self.icon.setAlignment(Qt.AlignCenter)
        self.icon.setFont(
            QFont(
                "Segoe UI Emoji",
                100
            )
        )

        self.title = QLabel(reason)
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setWordWrap(True)
        self.title.setStyleSheet(
            "color:white;"
        )
        self.title.setFont(
            QFont(
                "Segoe UI",
                28,
                QFont.Bold
            )
        )

        self.bar = QProgressBar()
        self.bar.setFixedSize(
            620,
            18
        )
        self.bar.setRange(
            0,
            seconds
        )
        self.bar.setValue(seconds)

        self.bar.setStyleSheet("""
        QProgressBar{
            border:2px solid #3FA9F5;
            border-radius:9px;
            background-color:#1B1F2A;
            text-align:center;
        }

        QProgressBar::chunk{
            background-color:#3FA9F5;
            border-radius:7px;
        }
        """)
        self.timerLabel = QLabel(str(seconds))
        self.timerLabel.setAlignment(Qt.AlignCenter)
        self.timerLabel.setStyleSheet(
            "color:#FFD54F;"
        )
        self.timerLabel.setFont(
            QFont(
                "Segoe UI",
                62,
                QFont.Bold
            )
        )

        layout.addWidget(self.icon)
        layout.addWidget(self.title)
        layout.addSpacing(15)

        layout.addWidget(
            self.bar,
            alignment=Qt.AlignCenter
        )

        layout.addWidget(
            self.timerLabel
        )

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(1000)

        self.center_panel()

        self.raise_()
        self.panel.raise_()
        self.activateWindow()

    def center_panel(self):
        self.panel.move(
            (self.width() - self.panel.width()) // 2,
            (self.height() - self.panel.height()) // 2
        )

    def resizeEvent(self, event):
        super().resizeEvent(event)

        self.background.setGeometry(self.rect())
        self.background.lower()

        self.center_panel()
        self.panel.raise_()

    def keyPressEvent(self, event):
        event.ignore()

    def closeEvent(self, event):
        event.accept()

    def tick(self):
        self.seconds -= 1

        if self.seconds < 0:
            self.timer.stop()
            self.close()
            return

        self.bar.setValue(self.seconds)
        self.timerLabel.setText(str(self.seconds))
        