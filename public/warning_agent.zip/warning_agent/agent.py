import asyncio
import json
import logging
import sys
import threading

import customtkinter as ctk
import websockets
from PIL import Image, ImageDraw
from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication
from pystray import Icon, Menu, MenuItem

from ui import WarningWindow

SERVER_IP = "192.168.3.100"
SERVER_PORT = 8765

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s"
)


class GuiSignals(QObject):
    show_warning = Signal(str, int)


class WarningAgent:

    def __init__(self):
        ctk.set_appearance_mode("dark")

        self.warning_open = False

        self.app = QApplication(sys.argv)

        self.signals = GuiSignals()
        self.signals.show_warning.connect(self.show_warning)

        self.create_tray()

        threading.Thread(
            target=self.websocket_thread,
            daemon=True
        ).start()

        sys.exit(self.app.exec())

    def create_tray(self):
        image = Image.new("RGB", (64, 64), (35, 35, 35))

        draw = ImageDraw.Draw(image)
        draw.ellipse(
            (14, 14, 50, 50),
            fill=(220, 0, 0)
        )

        menu = Menu(
            MenuItem(
                "Exit",
                self.exit_program
            )
        )

        self.tray = Icon(
            "WarningAgent",
            image,
            "Warning Agent",
            menu
        )

        threading.Thread(
            target=self.tray.run,
            daemon=True
        ).start()

    def exit_program(self):
        try:
            self.tray.stop()
        except Exception:
            pass

        self.app.quit()
        sys.exit(0)

    def websocket_thread(self):

        async def connect():

            uri = f"ws://{SERVER_IP}:{SERVER_PORT}"

            while True:

                try:
                    async with websockets.connect(
                        uri,
                        ping_interval=20,
                        ping_timeout=20,
                    ) as ws:

                        logging.info("Connected to server")

                        async for packet in ws:

                            try:
                                data = json.loads(packet)
                            except json.JSONDecodeError:
                                logging.warning("Invalid JSON received")
                                continue

                            if data.get("command") == "show_warning":

                                self.signals.show_warning.emit(
                                    data.get("reason", "Warning"),
                                    int(data.get("seconds", 30))
                                )

                except Exception as e:
                    logging.error(e)
                    await asyncio.sleep(3)

                asyncio.run(connect())

    def show_warning(self, reason, seconds):
        logging.info(
            "Showing warning: %s (%s sec)",
            reason,
            seconds
        )

        if self.warning_open:
            return

        self.warning_open = True

        self.window = WarningWindow(
            reason,
            seconds
        )

        self.window.destroyed.connect(
            self.on_window_closed
        )

        self.window.show()
        self.window.raise_()
        self.window.activateWindow()

    def on_window_closed(self):
        self.warning_open = False


if __name__ == "__main__":
    WarningAgent()