import asyncio
import json
import websockets

HOST = "0.0.0.0"
PORT = 8765

clients = set()


async def handler(websocket):
    clients.add(websocket)
    ip = websocket.remote_address[0] if websocket.remote_address else "Unknown"
    print(f"[+] Client Connected : {ip} | Total : {len(clients)}")

    try:
        async for _ in websocket:
            pass
    except websockets.ConnectionClosed:
        pass
    finally:
        if websocket in clients:
            clients.remove(websocket)
        print(f"[-] Client Disconnected : {ip} | Total : {len(clients)}")


async def send_warning(reason, seconds):
    if not clients:
        print("No Clients Connected.")
        return

    packet = json.dumps({
        "command": "show_warning",
        "reason": reason,
        "seconds": seconds
    })

    dead = []

    for client in list(clients):
        try:
            await client.send(packet)
        except Exception:
            dead.append(client)

    for d in dead:
        clients.discard(d)


async def console():
    while True:
        try:
            reason = await asyncio.to_thread(input, "\nReason : ")
            sec = await asyncio.to_thread(input, "Seconds : ")

            try:
                sec = int(sec)
            except:
                sec = 30

            await send_warning(reason, sec)

        except KeyboardInterrupt:
            break


async def main():
    async with websockets.serve(
        handler,
        HOST,
        PORT,
        ping_interval=20,
        ping_timeout=20,
    ):
        print(f"Warning Server Started : {HOST}:{PORT}")
        await console()


if __name__ == "__main__":
    asyncio.run(main())